import{_ as v}from"./index-QvyJPtVs.js";import{d as M,z as e,k as w,w as m,E as A,o as n,j as c,G as T,H as j,I as K,B as p,C as b,A as N}from"./vue.esm-bundler-8nJxs6wk.js";import"./el-button-V1zn0bod.js";/* empty css                   */import{E as u}from"./index-C554dqMN.js";import{_ as B}from"./_plugin-vue_export-helper-C6RzJgyC.js";import"./el-popper-B-PjlTAE.js";import"./index-BFAKzmXR.js";import"./pick-BkEcKBb1.js";import"./_basePickBy-Co_IC_Gu.js";import"./hasIn-Bi7gSSs4.js";import"./_arrayPush-lnK5TCUO.js";import"./get-BMJXpyNq.js";import"./_overRest-DYeOVmH-.js";import"./index-CWTj0pFa.js";import"./aria-DsgnTM7o.js";import"./isUndefined-DCTLXrZ8.js";import"./el-tooltip-l0sNRNKZ.js";import"./dropdown-D4E6mAim.js";const H={style:{display:"flex","flex-direction":"column",gap:"12px",height:"320px"}},O={class:"custom-label"},I={class:"custom-group-title"},z={key:0},L={key:1},R={key:2},W={key:3},P={key:0},U={key:1},X={key:2},G={key:3,style:{background:"black",padding:"5px",borderRadius:"10px",color:"white",fontSize:"12px",display:"flex",alignItems:"center",justifyContent:"center"}},q={class:"menu-buttons"},J=["onClick"],Q={key:0},Y={key:1},F=M({__name:"CustomStyleSolt",setup(l){const d=[{key:"edit",label:"编辑",icon:"🍉",command:{self_id:"1",self_message:"编辑",self_type:"text"}},{key:"delete",label:"删除",icon:"🍎",disabled:!0,divided:!0},{key:"share",label:"分享",icon:"🍆",command:"share"}];function t(r,i){u.success(`点击了菜单项：${r} ${i.label}`)}function a(r,i){switch(r){case"edit":u.warning(`编辑: ${i.label}`);break;case"delete":u.error(`删除: ${i.label}`);break;case"share":u.success(`分享: ${i.label}`);break}}return(r,i)=>{const $=v;return n(),e("div",H,[w($,A(r.$attrs,{onMenuCommand:t}),{label:m(({item:o})=>[c("div",O,b(o.label),1)]),groupTitle:m(({group:o})=>[c("div",I,[o.title==="工作"?(n(),e("span",z,"📊 ")):o.title==="学习"?(n(),e("span",L,"📚 ")):o.title==="个人"?(n(),e("span",R,"🏠 ")):(n(),e("span",W,"📁 ")),N(" "+b(o.title),1)])]),"more-filled":m(({item:o,isHovered:s,isActive:_,isMenuOpened:D,isDisabled:E})=>[s?(n(),e("span",P,"✍️")):p("",!0),_?(n(),e("span",U,"✅")):p("",!0),D?(n(),e("span",X,"🥰")):p("",!0),E?(n(),e("span",G," 🫥是否禁用："+b(o==null?void 0:o.disabled),1)):p("",!0)]),menu:m(({item:o})=>[c("div",q,[(n(),e(T,null,j(d,s=>c("div",{key:s.key,class:"menu-self-button",onClick:K(_=>a(s.key,o),["stop"])},[s.icon?(n(),e("span",Q,b(s.icon),1)):p("",!0),s.label?(n(),e("span",Y,b(s.label),1)):p("",!0)],8,J)),64))])]),_:1},16)])}}}),Z=B(F,[["__scopeId","data-v-1dd59d79"]]);F.__docgenInfo={exportName:"default",displayName:"CustomStyleSolt",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/Conversations/CustomStyleSolt.vue"]};const ee={class:"component-container"},ne={class:"conversations-wrap"},V=M({__name:"index",setup(l){function d(t,a){u.success(`点击了菜单项：${t} ${a.label}`)}return(t,a)=>{const r=v;return n(),e("div",ee,[a[0]||(a[0]=c("div",{class:"component-title"}," 会话管理组件，高度自动会撑满父元素高度，溢出则会滚动 ",-1)),c("div",ne,[w(r,A(t.$attrs,{onMenuCommand:d}),null,16)])])}}}),oe=B(V,[["__scopeId","data-v-db726359"]]);V.__docgenInfo={exportName:"default",displayName:"Conversations",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/Conversations/index.vue"]};const Se={title:"Example/Conversations 会话管理组件 📱",component:oe,argTypes:{items:{description:"会话项数据列表，包含 label、group、disabled 等字段",control:"object",defaultValue:[]},groupable:{description:"是否启用分组功能，传入对象可自定义分组排序",defaultValue:!1},showBuiltInMenu:{description:"是否显示内置菜单（重命名、删除）",control:"boolean",defaultValue:!1},loadMore:{control:"object",description:"懒加载回调函数，滚动至底部时触发"},loadMoreLoading:{description:"加载更多状态，控制加载动画显示",control:"boolean",defaultValue:!1},showToTopBtn:{description:"是否显示返回顶部按钮",control:"boolean",defaultValue:!1},labelKey:{description:"会话项标签字段名",control:"text",defaultValue:"label"},rowKey:{description:"会话项唯一标识字段名",control:"text",defaultValue:"id"},itemsStyle:{description:"会话项默认样式",control:"object",defaultValue:{}},itemsHoverStyle:{description:"会话项悬停样式",control:"object",defaultValue:{}},itemsActiveStyle:{description:"会话项激活样式",control:"object",defaultValue:{}},itemsMenuOpenedStyle:{description:"会话项菜单打开时样式",control:"object",defaultValue:{}}}},g={args:{items:[{id:"1",label:"今天的会话111111111111111111111111111",group:"today"},{id:"2",group:"today",label:"今天的会话2",disabled:!0},{id:"3",group:"yesterday",label:"昨天的会话1"},{id:"4",label:"昨天的会话2"},{id:"5",label:"一周前的会话"},{id:"6",label:"一个月前的会话"},{id:"7",label:"很久以前的会话"},{id:"8",label:"一个星期前的会话"},{id:"9",label:"一个月前的会话"},{id:"10",label:"一个月前的会话"},{id:"11",label:"一个月前的会话"},{id:"12",label:"一个月前的会话"},{id:"13",label:"一个月前的会话"}],groupable:!0,showBuiltInMenu:!0,loadMore:()=>{u.success("加载更多")},loadMoreLoading:!0,showToTopBtn:!0,labelKey:"label",rowKey:"id",itemsStyle:{backgroundColor:"#f0f0f0",padding:"8px"},itemsHoverStyle:{backgroundColor:"#e0e0e0"},itemsActiveStyle:{backgroundColor:"#d0d0d0",fontWeight:"bold"},itemsMenuOpenedStyle:{backgroundColor:"#c0c0c0",border:"1px solid #aaa"}}},y={args:{...g.args,items:[{key:"g1",label:"工作文档1",group:"工作"},{key:"g2",label:"工作文档11111111111111111111111111111111111111111",group:"工作"},{key:"g3",label:"工作文档3",group:"工作"},{key:"g4",label:"工作文档4",group:"工作"},{key:"g5",label:"工作文档5",group:"工作"},{key:"g6",label:"工作文档6",group:"工作"},{key:"g7",label:"学习笔记1",group:"学习"},{key:"g8",label:"学习笔记2",group:"学习"},{key:"g9",label:"个人文档1",group:"个人"},{key:"g10",label:"未分组项目"}],loadMore:()=>{},rowKey:"key",groupable:{sort:(l,d)=>{const t={学习:0,工作:1,个人:2,未分组:3},a=t[l]!==void 0?t[l]:999,r=t[d]!==void 0?t[d]:999;return a-r}},itemsStyle:{padding:"10px 20px",borderRadius:"10px",fontSize:"16px",fontWeight:"bold",textAlign:"center",boxShadow:"0 2px 12px 0 rgba(0, 0, 0, 0.1)",transition:"all 0.3s",marginBottom:"20px",border:"2px dashed transparent"},itemsHoverStyle:{background:"#FAFAD2",border:"2px dashed #006400"},itemsActiveStyle:{background:"#006400",color:"#FFFAFA",border:"2px dashed transparent"},itemsMenuOpenedStyle:{border:"2px dashed transparent"},menuStyle:{backgroundColor:"red",boxShadow:"0 2px 12px 0 rgba(0, 0, 0, 0.1)",padding:"10px 20px",height:"200px"}},render:l=>({components:{CustomStyleSolt:Z},setup(){return{attrs:l}},template:'<CustomStyleSolt v-bind="attrs" />'})};var k,x,f;g.parameters={...g.parameters,docs:{...(k=g.parameters)==null?void 0:k.docs,source:{originalSource:`{
  args: {
    items: [{
      id: '1',
      label: '今天的会话111111111111111111111111111',
      group: 'today'
    }, {
      id: '2',
      group: 'today',
      label: '今天的会话2',
      disabled: true
    }, {
      id: '3',
      group: 'yesterday',
      label: '昨天的会话1'
    }, {
      id: '4',
      label: '昨天的会话2'
    }, {
      id: '5',
      label: '一周前的会话'
    }, {
      id: '6',
      label: '一个月前的会话'
    }, {
      id: '7',
      label: '很久以前的会话'
    }, {
      id: '8',
      label: '一个星期前的会话'
    }, {
      id: '9',
      label: '一个月前的会话'
    }, {
      id: '10',
      label: '一个月前的会话'
    }, {
      id: '11',
      label: '一个月前的会话'
    }, {
      id: '12',
      label: '一个月前的会话'
    }, {
      id: '13',
      label: '一个月前的会话'
    }],
    groupable: true,
    showBuiltInMenu: true,
    loadMore: () => {
      ElMessage.success(\`加载更多\`);
    },
    loadMoreLoading: true,
    showToTopBtn: true,
    labelKey: 'label',
    rowKey: 'id',
    itemsStyle: {
      backgroundColor: '#f0f0f0',
      padding: '8px'
    },
    itemsHoverStyle: {
      backgroundColor: '#e0e0e0'
    },
    itemsActiveStyle: {
      backgroundColor: '#d0d0d0',
      fontWeight: 'bold'
    },
    itemsMenuOpenedStyle: {
      backgroundColor: '#c0c0c0',
      border: '1px solid #aaa'
    }
  }
}`,...(f=(x=g.parameters)==null?void 0:x.docs)==null?void 0:f.source}}};var h,S,C;y.parameters={...y.parameters,docs:{...(h=y.parameters)==null?void 0:h.docs,source:{originalSource:`{
  args: {
    ...ConversationsDemo.args,
    items: [{
      key: 'g1',
      label: '工作文档1',
      group: '工作'
    }, {
      key: 'g2',
      label: '工作文档11111111111111111111111111111111111111111',
      group: '工作'
    }, {
      key: 'g3',
      label: '工作文档3',
      group: '工作'
    }, {
      key: 'g4',
      label: '工作文档4',
      group: '工作'
    }, {
      key: 'g5',
      label: '工作文档5',
      group: '工作'
    }, {
      key: 'g6',
      label: '工作文档6',
      group: '工作'
    }, {
      key: 'g7',
      label: '学习笔记1',
      group: '学习'
    }, {
      key: 'g8',
      label: '学习笔记2',
      group: '学习'
    }, {
      key: 'g9',
      label: '个人文档1',
      group: '个人'
    }, {
      key: 'g10',
      label: '未分组项目'
    }],
    loadMore: () => {},
    rowKey: 'key',
    groupable: {
      // 自定义分组排序，学习 > 工作 > 个人 > 未分组
      sort: (a, b) => {
        const order: Record<string, number> = {
          学习: 0,
          工作: 1,
          个人: 2,
          未分组: 3
        };
        const orderA = order[a] !== undefined ? order[a] : 999;
        const orderB = order[b] !== undefined ? order[b] : 999;
        return orderA - orderB;
      }
    },
    itemsStyle: {
      padding: '10px 20px',
      borderRadius: '10px',
      fontSize: '16px',
      fontWeight: 'bold',
      textAlign: 'center',
      boxShadow: '0 2px 12px 0 rgba(0, 0, 0, 0.1)',
      transition: 'all 0.3s',
      marginBottom: '20px',
      border: '2px dashed transparent'
    },
    itemsHoverStyle: {
      background: '#FAFAD2',
      border: '2px dashed #006400'
    },
    itemsActiveStyle: {
      background: '#006400',
      color: '#FFFAFA',
      border: '2px dashed transparent'
    },
    itemsMenuOpenedStyle: {
      border: '2px dashed transparent'
    },
    menuStyle: {
      backgroundColor: 'red',
      boxShadow: '0 2px 12px 0 rgba(0, 0, 0, 0.1)',
      padding: '10px 20px',
      height: '200px'
    }
  },
  render: (args: any) => ({
    components: {
      CustomStyleSolt
    },
    setup() {
      return {
        attrs: args
      };
    },
    template: \`<CustomStyleSolt v-bind="attrs" />\`
  })
}`,...(C=(S=y.parameters)==null?void 0:S.docs)==null?void 0:C.source}}};const Ce=["ConversationsDemo","StyleSoltDemo"];export{g as ConversationsDemo,y as StyleSoltDemo,Ce as __namedExportsOrder,Se as default};
