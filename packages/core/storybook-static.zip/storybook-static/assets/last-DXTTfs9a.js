function l(n){var e=n==null?0:n.length;return e?n[e-1]:void 0}export{l};
