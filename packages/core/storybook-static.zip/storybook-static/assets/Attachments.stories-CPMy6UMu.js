import{m as q,d as U,z as m,j as v,k as A,w as S,E as w,u as a,o as p,B as _,M as $,G as M,H as T,C as V}from"./vue.esm-bundler-CWJkwHz9.js";import{A as z}from"./index-jU8mFvCO.js";import{c as X}from"./mock-Bykb4b7U.js";import{E as f}from"./index-DppTSAR2.js";import{_ as E}from"./_plugin-vue_export-helper-C6RzJgyC.js";import"./el-button-D5jk_owF.js";import"./get-BMJXpyNq.js";import"./aria-BrQDUQ5m.js";import"./index-Bl31wyo9.js";import"./toNumber-DSBfpcGg.js";import"./index-CAWHOWdY.js";import"./curry-BXSChsWz.js";import"./cloneDeep-CCw91Nak.js";import"./_baseIsEqual-eNA4N57V.js";import"./_initCloneObject-8enN8I-i.js";import"./_arrayPush-lnK5TCUO.js";function j(n=30){const t=[],r=Object.keys(X);for(let s=0;s<n;s++)t.push({uid:s.toString(),name:`文件${s}`,fileSize:1024*2,fileType:r[Math.floor(Math.random()*r.length)],url:"https://avatars.githubusercontent.com/u/76239030?s=70&v=4",thumbUrl:"https://avatars.githubusercontent.com/u/76239030?s=70&v=4",showDelIcon:!0});return t}function N(n=[]){const t=q(n);function r(e){return e.size>1024*1024*2?(f.error("文件大小不能超过 2MB!"),!1):!0}function s(e,l){if(e.length){if(e[0].type==="")return f.error("禁止上传文件夹！"),!1;e.forEach(o=>i({file:o}))}}async function i(e){new FormData().append("file",e.file),f.info("上传中..."),setTimeout(()=>{const o={fileName:e.file.name,uid:e.file.name,fileSize:e.file.size,imgFile:e.file};t.value.push({uid:t.value.length,name:o.fileName,fileSize:o.fileSize,imgFile:o.imgFile,showDelIcon:!0}),f.success("上传成功")},1e3)}function c(e){t.value=t.value.filter(l=>l.id!==e.id),f.success("删除成功")}return{files:t,handleBeforeUpload:r,handleUploadDrop:s,handleHttpRequest:i,handleDeleteCard:c}}const H={class:"component-container"},P={class:"custom-item-name"},R=["onClick"],L=["onClick"],B=U({__name:"CustomSolt",props:{items:{default:()=>[]}},setup(n){const t=n,{files:r,handleBeforeUpload:s,handleHttpRequest:i,handleUploadDrop:c,handleDeleteCard:e}=N(t.items);return(l,o)=>(p(),m("div",H,[o[0]||(o[0]=v("div",{class:"component-title"},"附件上传组件-自定义左右按钮、列表内容",-1)),A(z,w({...l.$attrs},{items:a(r),"http-request":a(i),"before-upload":a(s),onUploadDrop:a(c),onDeleteCard:a(e)}),{"file-list":S(({items:d})=>[v("div",{class:$(["custom-list",{"custom-list-overflow-no-x":l.$attrs.overflow!=="scrollX"}])},[(p(!0),m(M,null,T(d,(u,I)=>(p(),m("div",{key:I,class:"custom-item"},[v("div",P,V(u.name),1)]))),128))],2)]),"prev-button":S(({show:d,onScrollLeft:u})=>[d?(p(),m("button",{key:0,class:"custom-prev",onClick:u}," 👈 ",8,R)):_("",!0)]),"next-button":S(({show:d,onScrollRight:u})=>[d?(p(),m("button",{key:0,class:"custom-next",onClick:u}," 👉 ",8,L)):_("",!0)]),_:1},16,["items","http-request","before-upload","onUploadDrop","onDeleteCard"])]))}}),O=E(B,[["__scopeId","data-v-2af93ed1"]]);B.__docgenInfo={exportName:"default",displayName:"CustomSolt",description:"",tags:{},props:[{name:"items",defaultValue:{func:!1,value:"() => []"}}],sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/Attachments/CustomSolt.vue"]};const G={class:"component-container"},F=U({__name:"index",props:{items:{default:()=>[]}},setup(n){const t=n,{files:r,handleBeforeUpload:s,handleHttpRequest:i,handleUploadDrop:c,handleDeleteCard:e}=N(t.items);return(l,o)=>(p(),m("div",G,[o[0]||(o[0]=v("div",{class:"component-title"}," 附件组件，内置多种文件格式样式。支持上传，删除，预览等操作，支持三种布局方式 ",-1)),A(z,w({...l.$attrs},{items:a(r),"before-upload":a(s),"http-request":a(i),onUploadDrop:a(c),onDeleteCard:a(e)}),null,16,["items","before-upload","http-request","onUploadDrop","onDeleteCard"])]))}}),Y=E(F,[["__scopeId","data-v-d4cc9c07"]]);F.__docgenInfo={exportName:"default",displayName:"Attachments",description:"",tags:{},props:[{name:"items",defaultValue:{func:!1,value:"() => []"}}],sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/Attachments/index.vue"]};const ce={title:"Example/Attachments 附件上传组件 📪️",tags:["autodocs"],component:Y,argTypes:{items:{control:"object"},overflow:{control:"radio",options:["scrollX","scrollY","wrap"]},listStyle:{control:"object"},limit:{control:"number"},hideUpload:{control:"boolean"},uploadIconSize:{control:"text"},dragTarget:{control:"text"}},args:{items:j(),overflow:"scrollX",listStyle:{padding:"0 12px",height:"320px"},limit:0,hideUpload:!1,uploadIconSize:"64px",dragTarget:""}},g={args:{}},h={name:"Solt Demo",args:{...g.args,items:[{id:1,name:"1.png"},{id:2,name:"2.png"},{id:3,name:"3.png"},{id:4,name:"4.png"},{id:5,name:"5.png"},{id:6,name:"6.png"},{id:7,name:"7.png"},{id:8,name:"8.png"},{id:9,name:"9.png"},{id:10,name:"10.png"}],listStyle:{padding:"0 12px",height:"220px"}},render:n=>({components:{CustomSolt:O},setup(){return{attrs:n}},template:'<CustomSolt v-bind="attrs" />'})};var D,C,b;g.parameters={...g.parameters,docs:{...(D=g.parameters)==null?void 0:D.docs,source:{originalSource:`{
  args: {}
}`,...(b=(C=g.parameters)==null?void 0:C.docs)==null?void 0:b.source}}};var x,y,k;h.parameters={...h.parameters,docs:{...(x=h.parameters)==null?void 0:x.docs,source:{originalSource:`{
  name: 'Solt Demo',
  args: {
    ...AttachmentsDemo.args,
    items: [{
      id: 1,
      name: '1.png'
    }, {
      id: 2,
      name: '2.png'
    }, {
      id: 3,
      name: '3.png'
    }, {
      id: 4,
      name: '4.png'
    }, {
      id: 5,
      name: '5.png'
    }, {
      id: 6,
      name: '6.png'
    }, {
      id: 7,
      name: '7.png'
    }, {
      id: 8,
      name: '8.png'
    }, {
      id: 9,
      name: '9.png'
    }, {
      id: 10,
      name: '10.png'
    }],
    listStyle: {
      padding: '0 12px',
      height: '220px'
    }
  } as Story['args'],
  render: args => ({
    components: {
      CustomSolt
    },
    setup() {
      return {
        attrs: args
      };
    },
    template: '<CustomSolt v-bind="attrs" />'
  })
}`,...(k=(y=h.parameters)==null?void 0:y.docs)==null?void 0:k.source}}};const de=["AttachmentsDemo","Solt"];export{g as AttachmentsDemo,h as Solt,de as __namedExportsOrder,ce as default};
