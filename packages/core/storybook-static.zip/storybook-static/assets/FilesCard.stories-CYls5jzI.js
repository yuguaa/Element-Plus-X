import{E as P,v as V}from"./base-D7tCU8sP.js";import{k as y,c as w,v as o,x as t,y as i,z as a,t as s,K as k,o as F,u as m,J as f,L as p}from"./vue.esm-bundler-DTnAEySg.js";import{F as n}from"./index-Bmty64m3.js";import{E}from"./index-B1aegxae.js";import{_}from"./_plugin-vue_export-helper-UBQfR8ld.js";import"./get-DecQlHrd.js";import"./el-image-viewer-C1Q-aqUn.js";import"./typescript-F_jgqlnI.js";import"./index-D_jmEDI_.js";import"./aria-BUADUvnR.js";import"./toNumber-C3ZKhb62.js";import"./index-DrVO5HE5.js";import"./scroll-6RUcSnBG.js";import"./link-DSSwps5E.js";const I={class:"component-container"},T={class:"custom-card"},N={class:"custom-card-title"},M={class:"custom-card-content"},$=y({__name:"CustomSolt",setup(u){return(r,e)=>{const D=P;return F(),w("div",I,[e[4]||(e[4]=o("div",{class:"component-title"}," 自定义样式 ",-1)),t(n,i(a(r.$attrs)),null,16),e[5]||(e[5]=o("div",{class:"component-title"},' 自定义 icon 插槽，可以通过 #icon="{ item }" 获取文件组件信息 ',-1)),t(n,i(a(r.$attrs)),{icon:s(()=>[t(D,null,{default:s(()=>[t(m(V))]),_:1})]),_:1},16),e[6]||(e[6]=o("div",{class:"component-title"},' 自定义内容，content 插槽：会覆盖原有右侧内容，同时通过 #content="{ item }" 获取当前文件组件信息 ',-1)),t(n,i(a(r.$attrs)),{content:s(({item:d})=>[o("div",T,[o("div",N,f(d.name)+" -- 自定义内容 ",1),o("div",M," 文件大小："+f(d.fileSize),1)])]),_:1},16),e[7]||(e[7]=o("div",{class:"component-title"},' 自定义图片遮罩操作，image-preview-actions 插槽：图片遮罩层自定义，同时通过 #image-preview-actions="{ item }" 获取当前文件组件信息 ',-1)),t(n,k(r.$attrs,{"file-type":"image",url:"https://avatars.githubusercontent.com/u/76239030?s=70&v=4","img-preview":!0}),{"image-preview-actions":s(()=>[o("div",{class:"image-preview-actions",onClick:e[0]||(e[0]=()=>m(E).success("自定义遮罩操作"))}," 自定义遮罩操作 ")]),_:1},16),e[8]||(e[8]=o("div",{class:"component-title"},' 自定义文件名字前缀，name-prefix 插槽：自定义文件名字前缀，同时通过 #name-prefix="{ item }" 获取当前文件组件信息 ',-1)),t(n,i(a(r.$attrs)),{"name-prefix":s(({item:d})=>[p(" 原文件名："+f(d.prefix),1)]),_:1},16),e[9]||(e[9]=o("div",{class:"component-title"},' 自定义文件名字前缀，name-prefix 插槽：自定义文件名字前缀，同时通过 #name-prefix="{ item }" 获取当前文件组件信息 ',-1)),t(n,i(a(r.$attrs)),{"name-prefix":s(()=>e[1]||(e[1]=[p(" 🤳 ",-1)])),_:1},16),e[10]||(e[10]=o("div",{class:"component-title"},' 自定义文件名字后缀，name-suffix 插槽：自定义文件名字后缀，同时通过 #name-suffix="{ item }" 获取当前文件组件信息 ',-1)),t(n,i(a(r.$attrs)),{"name-suffix":s(()=>e[2]||(e[2]=[p(" 🤳 ",-1)])),_:1},16),e[11]||(e[11]=o("div",{class:"component-title"},' 自定义删除按钮，del-icon 插槽：自定义文件名字后缀，同时通过 #del-icon="{ item }" 获取当前文件组件信息 ',-1)),t(n,i(a(r.$attrs)),{"del-icon":s(()=>e[3]||(e[3]=[p(" 🙅 ",-1)])),_:1},16)])}}}),B=_($,[["__scopeId","data-v-53d24d63"]]);$.__docgenInfo={exportName:"default",displayName:"CustomSolt",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/合并代码/Element-Plus-X/packages/core/src/stories/FilesCard/CustomSolt.vue"]};const U={class:"component-container"},z=y({__name:"index",setup(u){return(r,e)=>(F(),w("div",U,[e[0]||(e[0]=o("div",{class:"component-title"}," 文件卡片 ",-1)),t(m(n),i(a(r.$attrs)),null,16),e[1]||(e[1]=o("br",null,null,-1)),t(m(n),k(r.$attrs,{name:"FilesCardDemo.png","file-type":"image","thumb-url":"https://camo.githubusercontent.com/4ea7fdaabf101c16965c0bd3ead816c9d7726a59b06f0800eb7c9a30212d5a6a/68747470733a2f2f63646e2e656c656d656e742d706c75732d782e636f6d2f656c656d656e742d706c75732d782e706e67"}),null,16)]))}}),W=_(z,[["__scopeId","data-v-8fc6d6a4"]]);z.__docgenInfo={exportName:"default",displayName:"FilesCard",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/合并代码/Element-Plus-X/packages/core/src/stories/FilesCard/index.vue"]};const h={title:"Example/FilesCard 文件卡片 📇",component:W,parameters:{controls:{expanded:!1}},argTypes:{uid:{control:"text",description:"文件唯一标识符"},name:{control:"text",description:"文件名（支持自动解析后缀匹配图标）"},fileSize:{control:"number",description:"文件大小（单位：字节，自动转换为易读格式）"},fileType:{control:{type:"radio"},options:["word","excel","ppt","pdf","txt","mark","image","audio","video","three","code","database","link","zip","file","unknown"],description:"文件类型（优先级高于 name 后缀解析，如image、document）"},description:{control:"text",description:"描述文本（支持动态生成文件类型和大小信息）"},url:{control:"text",description:"文件访问地址（图片文件可用于预览）"},thumbUrl:{control:"text",description:"图片缩略图地址"},imgFile:{control:"file",description:"图片文件流（自动解析为预览地址，仅用于上传前临时展示）"},iconSize:{control:"text",description:"图标/图片尺寸"},iconColor:{control:"color",description:"非图片文件的图标颜色（支持自定义色值）"},showDelIcon:{control:"boolean",description:"是否显示悬停删除图标",defaultValue:!0},maxWidth:{control:"text",description:"卡片最大宽度"},style:{control:"object",description:"卡片自定义样式"},hoverStyle:{control:"object",description:"卡片悬停时的自定义样式"},imgVariant:{control:{type:"radio"},options:["rectangle","square"],description:"图片卡片形态（长方形/正方形）"},imgPreview:{control:"boolean",defaultValue:!0,description:"是否开启图片预览功能"},imgPreviewMask:{control:"boolean",description:"是否显示图片预览遮罩蒙层",defaultValue:!0},status:{control:{type:"radio"},options:["uploading","done","error"],description:"文件状态（控制进度条、错误提示等视觉反馈）"},percent:{control:"number",min:0,max:100,step:1,description:"上传进度百分比"},errorTip:{control:"text",defaultValue:"上传失败",description:"错误状态自定义提示文本"}}},l={args:{name:"自定义.zdy",fileSize:6e3,iconSize:"60px",iconColor:"",fileType:"word",maxWidth:"300px",errorTip:"上传失败",imgVariant:"rectangle",imgPreview:!0,imgPreviewMask:!0,showDelIcon:!0,status:"uploading",percent:30}},c={args:{...l.args,name:"自定义样式.doc",style:{"background-color":"#f0f9eb",border:"2px solid #67c23a","border-radius":"20px"},hoverStyle:{"box-shadow":"0 2px 12px 0 rgba(0, 0, 0, 0.1)","border-color":"red","background-color":"rgba(255, 0, 0, 0.1)"}},render:u=>({components:{CustomSolt:B},setup(){return{attrs:u}},template:'<CustomSolt v-bind="attrs" />'})};var g,x,v;l.parameters={...l.parameters,docs:{...(g=l.parameters)==null?void 0:g.docs,source:{originalSource:`{
  args: {
    name: '自定义.zdy',
    fileSize: 6000,
    iconSize: '60px',
    iconColor: '',
    fileType: 'word',
    maxWidth: '300px',
    errorTip: '上传失败',
    imgVariant: 'rectangle',
    imgPreview: true,
    imgPreviewMask: true,
    showDelIcon: true,
    status: 'uploading',
    percent: 30
  }
}`,...(v=(x=l.parameters)==null?void 0:x.docs)==null?void 0:v.source}}};var b,C,S;c.parameters={...c.parameters,docs:{...(b=c.parameters)==null?void 0:b.docs,source:{originalSource:`{
  args: {
    ...FilesCardDemo.args,
    name: '自定义样式.doc',
    style: {
      'background-color': '#f0f9eb',
      border: '2px solid #67c23a',
      'border-radius': '20px'
    },
    hoverStyle: {
      'box-shadow': '0 2px 12px 0 rgba(0, 0, 0, 0.1)',
      'border-color': 'red',
      'background-color': 'rgba(255, 0, 0, 0.1)'
    }
  },
  render: args => ({
    components: {
      CustomSolt
    },
    setup() {
      return {
        attrs: args
      };
    },
    template: \`<CustomSolt v-bind="attrs" />\`
  })
}`,...(S=(C=c.parameters)==null?void 0:C.docs)==null?void 0:S.source}}};const ee=["FilesCardDemo","StyleSoltDemo"];export{l as FilesCardDemo,c as StyleSoltDemo,ee as __namedExportsOrder,h as default};
