import{i}from"./vue.esm-bundler-DTnAEySg.js";const a=(...c)=>s=>{c.forEach(o=>{i(o)?o(s):o.value=s})};export{a as c};
