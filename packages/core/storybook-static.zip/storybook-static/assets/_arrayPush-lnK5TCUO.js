function g(e,t){for(var n=-1,h=t.length,f=e.length;++n<h;)e[f+n]=t[n];return e}export{g as a};
