import{U as a,N as n}from"./mermaid.core-CJRaG5gc.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
