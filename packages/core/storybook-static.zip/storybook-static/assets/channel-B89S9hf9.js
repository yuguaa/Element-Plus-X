import{U as a,N as n}from"./mermaid.core-CUV9Ow59.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
