import{i as a}from"./_plugin-vue_export-helper-UBQfR8ld.js";function e(){if(!arguments.length)return[];var r=arguments[0];return a(r)?r:[r]}export{e as c};
