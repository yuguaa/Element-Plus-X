function e(n){return n===void 0}export{e as i};
