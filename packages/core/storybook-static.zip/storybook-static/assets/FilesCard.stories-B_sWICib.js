import{c as P,z as V}from"./el-button-D5jk_owF.js";import{d as y,z as w,j as t,k as o,n as s,l as a,w as n,E as k,o as F,u as c,C as f,A as m}from"./vue.esm-bundler-CWJkwHz9.js";import{F as i}from"./index-jU8mFvCO.js";import{E}from"./index-DppTSAR2.js";import{_ as z}from"./_plugin-vue_export-helper-C6RzJgyC.js";import"./index-cNfuRqjS.js";import"./index-CvGOsCqS.js";import"./index-DjWSGOMW.js";import"./index-DD34QqSk.js";import"./index-BNTUvNAl.js";import"./index-CiEKwO2o.js";import"./index-BXnpXdTJ.js";import"./index-CC1hLSnN.js";import"./get-BMJXpyNq.js";import"./aria-BrQDUQ5m.js";import"./index-Bl31wyo9.js";import"./toNumber-DSBfpcGg.js";import"./index-CAWHOWdY.js";import"./curry-BXSChsWz.js";import"./cloneDeep-CCw91Nak.js";import"./_baseIsEqual-eNA4N57V.js";import"./_initCloneObject-8enN8I-i.js";import"./_arrayPush-lnK5TCUO.js";import"./index-opX51o-s.js";import"./pick-BkEcKBb1.js";import"./_basePickBy-Co_IC_Gu.js";import"./hasIn-Bi7gSSs4.js";import"./_overRest-DYeOVmH-.js";import"./event-BB_Ol6Sd.js";import"./el-tooltip-DjrQvLKJ.js";import"./el-popper-D1v00u9P.js";import"./isUndefined-DCTLXrZ8.js";import"./dropdown-hzEuDxer.js";import"./purify.es-DTUwIkWu.js";import"./mermaid.core-JEFoKH9L.js";import"./iframe-DBptVp5Y.js";import"./index-DrFu-skq.js";import"./katex-Czt20RFs.js";const I={class:"component-container"},T={class:"custom-card"},N={class:"custom-card-title"},M={class:"custom-card-content"},_=y({__name:"CustomSolt",setup(u){return(r,e)=>{const D=P;return F(),w("div",I,[e[4]||(e[4]=t("div",{class:"component-title"},"自定义样式",-1)),o(i,s(a(r.$attrs)),null,16),e[5]||(e[5]=t("div",{class:"component-title"},' 自定义 icon 插槽，可以通过 #icon="{ item }" 获取文件组件信息 ',-1)),o(i,s(a(r.$attrs)),{icon:n(()=>[o(D,null,{default:n(()=>[o(c(V))]),_:1})]),_:1},16),e[6]||(e[6]=t("div",{class:"component-title"},' 自定义内容，content 插槽：会覆盖原有右侧内容，同时通过 #content="{ item }" 获取当前文件组件信息 ',-1)),o(i,s(a(r.$attrs)),{content:n(({item:l})=>[t("div",T,[t("div",N,f(l.name)+" -- 自定义内容",1),t("div",M,"文件大小："+f(l.fileSize),1)])]),_:1},16),e[7]||(e[7]=t("div",{class:"component-title"},' 自定义图片遮罩操作，image-preview-actions 插槽：图片遮罩层自定义，同时通过 #image-preview-actions="{ item }" 获取当前文件组件信息 ',-1)),o(i,k(r.$attrs,{"file-type":"image",url:"https://avatars.githubusercontent.com/u/76239030?s=70&v=4","img-preview":!0}),{"image-preview-actions":n(()=>[t("div",{class:"image-preview-actions",onClick:e[0]||(e[0]=()=>c(E).success("自定义遮罩操作"))}," 自定义遮罩操作 ")]),_:1},16),e[8]||(e[8]=t("div",{class:"component-title"},' 自定义文件名字前缀，name-prefix 插槽：自定义文件名字前缀，同时通过 #name-prefix="{ item }" 获取当前文件组件信息 ',-1)),o(i,s(a(r.$attrs)),{"name-prefix":n(({item:l})=>[m(" 原文件名："+f(l.prefix),1)]),_:1},16),e[9]||(e[9]=t("div",{class:"component-title"},' 自定义文件名字前缀，name-prefix 插槽：自定义文件名字前缀，同时通过 #name-prefix="{ item }" 获取当前文件组件信息 ',-1)),o(i,s(a(r.$attrs)),{"name-prefix":n(()=>e[1]||(e[1]=[m(" 🤳 ")])),_:1},16),e[10]||(e[10]=t("div",{class:"component-title"},' 自定义文件名字后缀，name-suffix 插槽：自定义文件名字后缀，同时通过 #name-suffix="{ item }" 获取当前文件组件信息 ',-1)),o(i,s(a(r.$attrs)),{"name-suffix":n(()=>e[2]||(e[2]=[m(" 🤳 ")])),_:1},16),e[11]||(e[11]=t("div",{class:"component-title"},' 自定义删除按钮，del-icon 插槽：自定义文件名字后缀，同时通过 #del-icon="{ item }" 获取当前文件组件信息 ',-1)),o(i,s(a(r.$attrs)),{"del-icon":n(()=>e[3]||(e[3]=[m(" 🙅 ")])),_:1},16)])}}}),j=z(_,[["__scopeId","data-v-8d734fe3"]]);_.__docgenInfo={exportName:"default",displayName:"CustomSolt",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/FilesCard/CustomSolt.vue"]};const B={class:"component-container"},$=y({__name:"index",setup(u){return(r,e)=>(F(),w("div",B,[e[0]||(e[0]=t("div",{class:"component-title"},"文件卡片",-1)),o(c(i),s(a(r.$attrs)),null,16),e[1]||(e[1]=t("br",null,null,-1)),o(c(i),k(r.$attrs,{name:"FilesCardDemo.png","file-type":"image","thumb-url":"https://camo.githubusercontent.com/4ea7fdaabf101c16965c0bd3ead816c9d7726a59b06f0800eb7c9a30212d5a6a/68747470733a2f2f63646e2e656c656d656e742d706c75732d782e636f6d2f656c656d656e742d706c75732d782e706e67"}),null,16)]))}}),U=z($,[["__scopeId","data-v-26d6bd8b"]]);$.__docgenInfo={exportName:"default",displayName:"FilesCard",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/FilesCard/index.vue"]};const ke={title:"Example/FilesCard 文件卡片 📇",component:U,parameters:{controls:{expanded:!1}},argTypes:{uid:{control:"text",description:"文件唯一标识符"},name:{control:"text",description:"文件名（支持自动解析后缀匹配图标）"},fileSize:{control:"number",description:"文件大小（单位：字节，自动转换为易读格式）"},fileType:{control:{type:"radio"},options:["word","excel","ppt","pdf","txt","mark","image","audio","video","three","code","database","link","zip","file","unknown"],description:"文件类型（优先级高于 name 后缀解析，如image、document）"},description:{control:"text",description:"描述文本（支持动态生成文件类型和大小信息）"},url:{control:"text",description:"文件访问地址（图片文件可用于预览）"},thumbUrl:{control:"text",description:"图片缩略图地址"},imgFile:{control:"file",description:"图片文件流（自动解析为预览地址，仅用于上传前临时展示）"},iconSize:{control:"text",description:"图标/图片尺寸"},iconColor:{control:"color",description:"非图片文件的图标颜色（支持自定义色值）"},showDelIcon:{control:"boolean",description:"是否显示悬停删除图标",defaultValue:!0},maxWidth:{control:"text",description:"卡片最大宽度"},style:{control:"object",description:"卡片自定义样式"},hoverStyle:{control:"object",description:"卡片悬停时的自定义样式"},imgVariant:{control:{type:"radio"},options:["rectangle","square"],description:"图片卡片形态（长方形/正方形）"},imgPreview:{control:"boolean",defaultValue:!0,description:"是否开启图片预览功能"},imgPreviewMask:{control:"boolean",description:"是否显示图片预览遮罩蒙层",defaultValue:!0},status:{control:{type:"radio"},options:["uploading","done","error"],description:"文件状态（控制进度条、错误提示等视觉反馈）"},percent:{control:"number",min:0,max:100,step:1,description:"上传进度百分比"},errorTip:{control:"text",defaultValue:"上传失败",description:"错误状态自定义提示文本"}}},p={args:{name:"自定义.zdy",fileSize:6e3,iconSize:"60px",iconColor:"",fileType:"word",maxWidth:"300px",errorTip:"上传失败",imgVariant:"rectangle",imgPreview:!0,imgPreviewMask:!0,showDelIcon:!0,status:"uploading",percent:30}},d={args:{...p.args,name:"自定义样式.doc",style:{"background-color":"#f0f9eb",border:"2px solid #67c23a","border-radius":"20px"},hoverStyle:{"box-shadow":"0 2px 12px 0 rgba(0, 0, 0, 0.1)","border-color":"red","background-color":"rgba(255, 0, 0, 0.1)"}},render:u=>({components:{CustomSolt:j},setup(){return{attrs:u}},template:'<CustomSolt v-bind="attrs" />'})};var g,b,x;p.parameters={...p.parameters,docs:{...(g=p.parameters)==null?void 0:g.docs,source:{originalSource:`{
  args: {
    name: '自定义.zdy',
    fileSize: 6000,
    iconSize: '60px',
    iconColor: '',
    fileType: 'word',
    maxWidth: '300px',
    errorTip: '上传失败',
    imgVariant: 'rectangle',
    imgPreview: true,
    imgPreviewMask: true,
    showDelIcon: true,
    status: 'uploading',
    percent: 30
  }
}`,...(x=(b=p.parameters)==null?void 0:b.docs)==null?void 0:x.source}}};var v,C,S;d.parameters={...d.parameters,docs:{...(v=d.parameters)==null?void 0:v.docs,source:{originalSource:`{
  args: {
    ...FilesCardDemo.args,
    name: '自定义样式.doc',
    style: {
      'background-color': '#f0f9eb',
      border: '2px solid #67c23a',
      'border-radius': '20px'
    },
    hoverStyle: {
      'box-shadow': '0 2px 12px 0 rgba(0, 0, 0, 0.1)',
      'border-color': 'red',
      'background-color': 'rgba(255, 0, 0, 0.1)'
    }
  },
  render: args => ({
    components: {
      CustomSolt
    },
    setup() {
      return {
        attrs: args
      };
    },
    template: \`<CustomSolt v-bind="attrs" />\`
  })
}`,...(S=(C=d.parameters)==null?void 0:C.docs)==null?void 0:S.source}}};const Fe=["FilesCardDemo","StyleSoltDemo"];export{p as FilesCardDemo,d as StyleSoltDemo,Fe as __namedExportsOrder,ke as default};
