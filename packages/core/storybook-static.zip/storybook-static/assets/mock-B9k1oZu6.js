import{e as G,a as K,c as q,b as N,i as Z}from"./isArguments-DJsDwUOI.js";import{g as b,r as s,d as W,c as J,a as Q,b as A,f as tt,i as et,L as k,h as v,M as at,t as p}from"./_plugin-vue_export-helper-UBQfR8ld.js";var w=b(s,"WeakMap"),_=Object.create,rt=function(){function t(){}return function(a){if(!W(a))return{};if(_)return _(a);t.prototype=a;var e=new t;return t.prototype=void 0,e}}();function ue(t,a){var e=-1,n=t.length;for(a||(a=Array(n));++e<n;)a[e]=t[e];return a}function fe(t,a,e,n){var d=!e;e||(e={});for(var u=-1,h=a.length;++u<h;){var o=a[u],c=void 0;c===void 0&&(c=t[o]),d?G(e,o,c):K(e,o,c)}return e}function nt(t){return t!=null&&q(t.length)&&!J(t)}var it=Object.prototype;function C(t){var a=t&&t.constructor,e=typeof a=="function"&&a.prototype||it;return t===e}function ot(t,a){for(var e=-1,n=Array(t);++e<t;)n[e]=a(e);return n}function st(){return!1}var V=typeof exports=="object"&&exports&&!exports.nodeType&&exports,z=V&&typeof module=="object"&&module&&!module.nodeType&&module,ct=z&&z.exports===V,M=ct?s.Buffer:void 0,lt=M?M.isBuffer:void 0,pt=lt||st,dt="[object Arguments]",ut="[object Array]",ft="[object Boolean]",gt="[object Date]",ht="[object Error]",mt="[object Function]",xt="[object Map]",vt="[object Number]",bt="[object Object]",yt="[object RegExp]",wt="[object Set]",$t="[object String]",Tt="[object WeakMap]",jt="[object ArrayBuffer]",At="[object DataView]",kt="[object Float32Array]",Ct="[object Float64Array]",_t="[object Int8Array]",zt="[object Int16Array]",Mt="[object Int32Array]",St="[object Uint8Array]",Et="[object Uint8ClampedArray]",Pt="[object Uint16Array]",Bt="[object Uint32Array]",r={};r[kt]=r[Ct]=r[_t]=r[zt]=r[Mt]=r[St]=r[Et]=r[Pt]=r[Bt]=!0;r[dt]=r[ut]=r[jt]=r[ft]=r[At]=r[gt]=r[ht]=r[mt]=r[xt]=r[vt]=r[bt]=r[yt]=r[wt]=r[$t]=r[Tt]=!1;function Ot(t){return Q(t)&&q(t.length)&&!!r[A(t)]}function Ft(t){return function(a){return t(a)}}var X=typeof exports=="object"&&exports&&!exports.nodeType&&exports,f=X&&typeof module=="object"&&module&&!module.nodeType&&module,Dt=f&&f.exports===X,y=Dt&&tt.process,S=function(){try{var t=f&&f.require&&f.require("util").types;return t||y&&y.binding&&y.binding("util")}catch{}}(),E=S&&S.isTypedArray,It=E?Ft(E):Ot,Lt=Object.prototype,Ut=Lt.hasOwnProperty;function Rt(t,a){var e=et(t),n=!e&&N(t),d=!e&&!n&&pt(t),u=!e&&!n&&!d&&It(t),h=e||n||d||u,o=h?ot(t.length,String):[],c=o.length;for(var i in t)(a||Ut.call(t,i))&&!(h&&(i=="length"||d&&(i=="offset"||i=="parent")||u&&(i=="buffer"||i=="byteLength"||i=="byteOffset")||Z(i,c)))&&o.push(i);return o}function H(t,a){return function(e){return t(a(e))}}var qt=H(Object.keys,Object),Wt=Object.prototype,Vt=Wt.hasOwnProperty;function ge(t){if(!C(t))return qt(t);var a=[];for(var e in Object(t))Vt.call(t,e)&&e!="constructor"&&a.push(e);return a}function Xt(t){var a=[];if(t!=null)for(var e in Object(t))a.push(e);return a}var Ht=Object.prototype,Yt=Ht.hasOwnProperty;function Gt(t){if(!W(t))return Xt(t);var a=C(t),e=[];for(var n in t)n=="constructor"&&(a||!Yt.call(t,n))||e.push(n);return e}function he(t){return nt(t)?Rt(t,!0):Gt(t)}var Kt=H(Object.getPrototypeOf,Object);function Nt(){this.__data__=new k,this.size=0}function Zt(t){var a=this.__data__,e=a.delete(t);return this.size=a.size,e}function Jt(t){return this.__data__.get(t)}function Qt(t){return this.__data__.has(t)}var te=200;function ee(t,a){var e=this.__data__;if(e instanceof k){var n=e.__data__;if(!v||n.length<te-1)return n.push([t,a]),this.size=++e.size,this;e=this.__data__=new at(n)}return e.set(t,a),this.size=e.size,this}function g(t){var a=this.__data__=new k(t);this.size=a.size}g.prototype.clear=Nt;g.prototype.delete=Zt;g.prototype.get=Jt;g.prototype.has=Qt;g.prototype.set=ee;var Y=typeof exports=="object"&&exports&&!exports.nodeType&&exports,P=Y&&typeof module=="object"&&module&&!module.nodeType&&module,ae=P&&P.exports===Y,B=ae?s.Buffer:void 0,O=B?B.allocUnsafe:void 0;function me(t,a){if(a)return t.slice();var e=t.length,n=O?O(e):new t.constructor(e);return t.copy(n),n}var $=b(s,"DataView"),T=b(s,"Promise"),j=b(s,"Set"),F="[object Map]",re="[object Object]",D="[object Promise]",I="[object Set]",L="[object WeakMap]",U="[object DataView]",ne=p($),ie=p(v),oe=p(T),se=p(j),ce=p(w),l=A;($&&l(new $(new ArrayBuffer(1)))!=U||v&&l(new v)!=F||T&&l(T.resolve())!=D||j&&l(new j)!=I||w&&l(new w)!=L)&&(l=function(t){var a=A(t),e=a==re?t.constructor:void 0,n=e?p(e):"";if(n)switch(n){case ne:return U;case ie:return F;case oe:return D;case se:return I;case ce:return L}return a});var R=s.Uint8Array;function le(t){var a=new t.constructor(t.byteLength);return new R(a).set(new R(t)),a}function xe(t,a){var e=a?le(t.buffer):t.buffer;return new t.constructor(e,t.byteOffset,t.length)}function ve(t){return typeof t.constructor=="function"&&!C(t)?rt(Kt(t)):{}}const m="https://avatars.githubusercontent.com/u/76239030?v=4",x="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png",be=`
### 行内公式
1. 欧拉公式：$e^{i\\pi} + 1 = 0$
2. 二次方程求根公式：$x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}$
3. 向量点积：$\\vec{a} \\cdot \\vec{b} = a_x b_x + a_y b_y + a_z b_z$

### 块级公式
1. 傅里叶变换：
$$
F(\\omega) = \\int_{-\\infty}^{\\infty} f(t) e^{-i\\omega t} dt
$$

2. 矩阵乘法：
$$
\\begin{bmatrix}
a & b \\\\
c & d
\\end{bmatrix}
\\begin{bmatrix}
x \\\\
y
\\end{bmatrix}
=
\\begin{bmatrix}
ax + by \\\\
cx + dy
\\end{bmatrix}
$$

3. 泰勒级数展开：
$$
f(x) = \\sum_{n=0}^{\\infty} \\frac{f^{(n)}(a)}{n!} (x - a)^n
$$

4. 拉普拉斯方程：
$$
\\nabla^2 u = \\frac{\\partial^2 u}{\\partial x^2} + \\frac{\\partial^2 u}{\\partial y^2} + \\frac{\\partial^2 u}{\\partial z^2} = 0
$$

5. 概率密度函数（正态分布）：
$$
f(x) = \\frac{1}{\\sqrt{2\\pi\\sigma^2}} e^{-\\frac{(x-\\mu)^2}{2\\sigma^2}}
$$

# 标题
这是一个 Markdown 示例。
- 列表项 1
- 列表项 2
**粗体文本** 和 *斜体文本*

- [x] Add some task
- [ ] Do some task
`.trim(),ye=`
#### 切换右侧的secureViewCode进行安全预览或者不启用安全预览模式下 会呈现不同的网页预览效果
##### 通过enableCodeLineNumber属性开启代码行号
\`\`\`html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>炫酷文字动效</title>
    <style>
        body { margin: 0; overflow: hidden; }
        canvas { display: block; }
        .text-container {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            pointer-events: none;
        }
        h1 {
            font-family: Arial, sans-serif;
            font-size: clamp(2rem, 8vw, 5rem);
            margin: 0;
            color: white;
            text-shadow: 0 0 10px rgba(0,0,0,0.3);
            opacity: 0;
            animation: fadeIn 3s forwards 0.5s;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <canvas id="canvas"></canvas>
    <div class="text-container">
        <h1 id="main-text">AWESOME TEXT</h1>
    </div>
    <script>
        const canvas = document.getElementById('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        const text = document.getElementById('main-text');

        class Particle {
            constructor() {
                this.x = Math.random() * canvas.width;
                this.y = Math.random() * canvas.height;
                this.size = Math.random() * 3 + 1;
                this.speedX = Math.random() * 3 - 1.5;
                this.speedY = Math.random() * 3 - 1.5;
                this.color = \`hsl(\${Math.random() * 360}, 70%, 60%)\`;
            }
            update() {
                this.x += this.speedX;
                this.y += this.speedY;
                if (this.size > 0.2) this.size -= 0.01;
            }
            draw() {
                ctx.fillStyle = this.color;
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                ctx.fill();
            }
        }

        let particles = [];
        function init() {
            particles = [];
            for (let i = 0; i < 200; i++) {
                particles.push(new Particle());
            }
        }

        function animate() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            for (let i = 0; i < particles.length; i++) {
                particles[i].update();
                particles[i].draw();
                for (let j = i; j < particles.length; j++) {
                    const dx = particles[i].x - particles[j].x;
                    const dy = particles[i].y - particles[j].y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    if (distance < 100) {
                        ctx.beginPath();
                        ctx.strokeStyle = \`rgba(255,255,255,\${0.1 - distance/1000})\`;
                        ctx.lineWidth = 0.5;
                        ctx.moveTo(particles[i].x, particles[i].y);
                        ctx.lineTo(particles[j].x, particles[j].y);
                        ctx.stroke();
                    }
                }
            }
            requestAnimationFrame(animate);
        }

        init();
        animate();

        window.addEventListener('resize', () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        });

        // 自定义文字功能
        text.addEventListener('click', () => {
            const newText = prompt('输入新文字:', text.textContent);
            if (newText) {
                text.textContent = newText;
                text.style.opacity = 0;
                setTimeout(() => {
                    text.style.opacity = 1;
                }, 50);
            }
        });
    <\/script>
</body>
</html>
\`\`\`
\`\`\`html
<div class="product-card">
  <div class="badge">新品</div>
  <img src="https://picsum.photos/300/200?product" alt="产品图片">

  <div class="content">
    <h3>无线蓝牙耳机 Pro</h3>
    <p class="description">主动降噪技术，30小时续航，IPX5防水等级</p>

    <div class="rating">
      <span>★★★★☆</span>
      <span class="reviews">(124条评价)</span>
    </div>

    <div class="price-container">
      <span class="price">¥499</span>
      <span class="original-price">¥699</span>
      <span class="discount">7折</span>
    </div>

    <div class="actions">
      <button class="cart-btn">加入购物车</button>
      <button class="fav-btn">❤️</button>
    </div>

    <div class="meta">
      <span>✓ 次日达</span>
      <span>✓ 7天无理由</span>
    </div>
  </div>
</div>

<style>
  .product-card {
    width: 280px;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    position: relative;
    background: white;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }

  .badge {
    position: absolute;
    top: 12px;
    left: 12px;
    background: #ff6b6b;
    color: white;
    padding: 4px 10px;
    border-radius: 4px;
    font-weight: bold;
    font-size: 12px;
    z-index: 2;
  }

  img {
    width: 100%;
    height: 180px;
    object-fit: cover;
    display: block;
  }

  .content {
    padding: 16px;
  }

  h3 {
    margin: 8px 0;
    font-size: 18px;
    color: #333;
  }

  .description {
    color: #666;
    font-size: 14px;
    margin: 8px 0 12px;
    line-height: 1.4;
  }

  .rating {
    display: flex;
    align-items: center;
    margin: 10px 0;
    color: #ffb300;
  }

  .reviews {
    font-size: 13px;
    color: #888;
    margin-left: 8px;
  }

  .price-container {
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 12px 0;
  }

  .price {
    font-size: 22px;
    font-weight: bold;
    color: #ff4757;
  }

  .original-price {
    font-size: 14px;
    color: #999;
    text-decoration: line-through;
  }

  .discount {
    background: #fff200;
    padding: 2px 6px;
    border-radius: 4px;
    font-size: 12px;
  }

  .actions {
    display: flex;
    gap: 8px;
    margin: 16px 0 12px;
  }

  .cart-btn {
    flex: 1;
    background: #5352ed;
    color: white;
    border: none;
    padding: 10px;
    border-radius: 6px;
    font-weight: bold;
    cursor: pointer;
    transition: background 0.2s;
  }

  .cart-btn:hover {
    background: #3742fa;
  }

  .fav-btn {
    width: 42px;
    background: white;
    border: 1px solid #ddd;
    border-radius: 6px;
    font-size: 18px;
    cursor: pointer;
    transition: all 0.2s;
  }

  .fav-btn:hover {
    border-color: #ff6b6b;
    color: #ff6b6b;
  }

  .meta {
    display: flex;
    gap: 15px;
    font-size: 13px;
    color: #2ed573;
    margin-top: 8px;
  }
</style>
\`\`\`
###### 非\`commonMark\`语法，dom多个
<pre>
<code class="language-java">
public class HelloWorld {
  public static void main(String[] args) {
      System.out.println("Hello, world!");
  }
}
</code>
</pre>
\`\`\`echarts
use codeXRender for echarts render
\`\`\`
### javascript
\`\`\`javascript
console.log('Hello, world!');
\`\`\`
### java
\`\`\`java
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, world!");
    }
}
\`\`\`
\`\`\`typescript
import {
  ArrowDownBold,
  CopyDocument,
  Moon,
  Sunny
} from '@element-plus/icons-vue';
import { ElButton, ElSpace } from 'element-plus';
import { h } from 'vue';

/* ----------------------------------- 按钮组 ---------------------------------- */

/**
 * @description 描述 language标签
 * @date 2025-06-25 17:48:15
 * @author tingfeng
 *
 * @export
 * @param language
 */
export function languageEle(language: string) {
  return h(
    ElSpace,
    {},
    {}
  );
}
\`\`\`
`.trim(),we=`

### mermaid 饼状图
\`\`\`mermaid
pie
    "传媒及文化相关" : 35
    "广告与市场营销" : 8
    "游戏开发" : 15
    "影视动画与特效" : 12
    "互联网产品设计" : 10
    "VR/AR开发" : 5
    "其他" : 15
\`\`\`

`,$e=`
### mermaid 流程图
\`\`\`mermaid
graph LR
    1 --> 2
    2 --> 3
    3 --> 4
    2 --> 1
    2-3 --> 1-3
\`\`\`
\`\`\`mermaid
flowchart TD
    Start[开始] --> Check[是否通过？]
    Check -- 是 --> Pass[流程继续]
    Check -- 否 --> Reject[流程结束]
\`\`\`
\`\`\`mermaid
flowchart TD
    %% 前端专项四层结构
    A["战略层
    【提升用户体验】"]
    --> B["架构层
    【微前端方案选型】"]
    --> C["框架层
    【React+TS技术栈】"]
    --> D["实现层
    【组件库开发】"]
    style A fill:#FFD700,stroke:#FFA500
    style B fill:#87CEFA,stroke:#1E90FF
    style C fill:#9370DB,stroke:#663399
    style D fill:#FF6347,stroke:#CD5C5C

\`\`\`
### mermaid 数学公式
\`\`\`mermaid
sequenceDiagram
    autonumber
    participant 1 as $$alpha$$
    participant 2 as $$beta$$
    1->>2: Solve: $$sqrt{2+2}$$
    2-->>1: Answer: $$2$$
\`\`\`

`,Te=`
<a href="https://element-plus-x.com/">element-plus-x</a>
<h1>标题1</h1>
<h2>标题2</h2>
`,je=[{key:1,role:"ai",placement:"start",content:"欢迎使用 Element Plus X .".repeat(5),loading:!0,shape:"corner",variant:"filled",isMarkdown:!1,typing:{step:2,suffix:"💗"},avatar:x,avatarSize:"32px"},{key:2,role:"user",placement:"end",content:"这是用户的消息",loading:!0,shape:"corner",variant:"outlined",isMarkdown:!1,avatar:m,avatarSize:"32px"},{key:3,role:"ai",placement:"start",content:"欢迎使用 Element Plus X .".repeat(5),loading:!0,shape:"corner",variant:"filled",isMarkdown:!1,typing:{step:2,suffix:"💗"},avatar:x,avatarSize:"32px"},{key:4,role:"user",placement:"end",content:"这是用户的消息",loading:!0,shape:"corner",variant:"outlined",isMarkdown:!1,avatar:m,avatarSize:"32px"},{key:5,role:"ai",placement:"start",content:"欢迎使用 Element Plus X .".repeat(5),loading:!0,shape:"corner",variant:"filled",isMarkdown:!1,typing:{step:2,suffix:"💗"},avatar:x,avatarSize:"32px"},{key:6,role:"user",placement:"end",content:"这是用户的消息",loading:!0,shape:"corner",variant:"outlined",isMarkdown:!1,avatar:m,avatarSize:"32px"},{key:7,role:"ai",placement:"start",content:"欢迎使用 Element Plus X .".repeat(5),loading:!0,shape:"corner",variant:"filled",isMarkdown:!1,typing:{step:2,suffix:"💗",isRequestEnd:!0},avatar:x,avatarSize:"32px"},{key:8,role:"user",placement:"end",content:"这是用户的消息",loading:!0,shape:"corner",variant:"outlined",isMarkdown:!1,avatar:m,avatarSize:"32px"}],Ae={word:"#5E74A8",excel:"#4A6B4A",ppt:"#C27C40",pdf:"#5A6976",txt:"#D4C58C",mark:"#FFA500",image:"#8E7CC3",audio:"#A67B5B",video:"#4A5568",three:"#5F9E86",code:"#4B636E",database:"#4A5A6B",link:"#5D7CBA",zip:"#8B5E3C",file:"#AAB2BF",unknown:"#888888"};export{C as A,g as S,R as U,$e as a,m as b,x as c,je as d,l as e,It as f,Kt as g,nt as h,pt as i,ye as j,he as k,we as l,be as m,Te as n,Rt as o,ge as p,fe as q,le as r,xe as s,Ft as t,S as u,ue as v,me as w,ve as x,Ae as y,j as z};
