import{d as i,f as E,E as n,u as l,o as m,z as C,k as $}from"./vue.esm-bundler-CWJkwHz9.js";import"./index-jU8mFvCO.js";import"./index-cNfuRqjS.js";import"./index-CvGOsCqS.js";import"./index-DjWSGOMW.js";import"./index-DD34QqSk.js";import{P as c}from"./index-BNTUvNAl.js";import"./index-CiEKwO2o.js";import"./index-BXnpXdTJ.js";import"./index-CC1hLSnN.js";import"./el-button-D5jk_owF.js";/* empty css                   */import{E as p}from"./index-DppTSAR2.js";import"./_plugin-vue_export-helper-C6RzJgyC.js";import"./aria-BrQDUQ5m.js";import"./index-Bl31wyo9.js";import"./toNumber-DSBfpcGg.js";import"./get-BMJXpyNq.js";import"./index-CAWHOWdY.js";import"./curry-BXSChsWz.js";import"./cloneDeep-CCw91Nak.js";import"./_baseIsEqual-eNA4N57V.js";import"./_initCloneObject-8enN8I-i.js";import"./_arrayPush-lnK5TCUO.js";import"./index-opX51o-s.js";import"./pick-BkEcKBb1.js";import"./_basePickBy-Co_IC_Gu.js";import"./hasIn-Bi7gSSs4.js";import"./_overRest-DYeOVmH-.js";import"./event-BB_Ol6Sd.js";import"./el-tooltip-DjrQvLKJ.js";import"./el-popper-D1v00u9P.js";import"./isUndefined-DCTLXrZ8.js";import"./dropdown-hzEuDxer.js";import"./purify.es-DTUwIkWu.js";import"./mermaid.core-JEFoKH9L.js";import"./iframe-DBptVp5Y.js";import"./index-DrFu-skq.js";import"./katex-Czt20RFs.js";const P=i({__name:"CustomStyle",setup(r){function e(t){p.success(`点击了 ${t.key}`)}return(t,d)=>(m(),E(l(c),n(t.$attrs,{onItemClick:e}),null,16))}});P.__docgenInfo={exportName:"default",displayName:"CustomStyle",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/Prompts/CustomStyle.vue"]};const F={style:{width:"450px",height:"fit-content",padding:"15px"}},v=i({__name:"index",setup(r){function e(t){p.success(`点击了 ${t.key}`)}return(t,d)=>(m(),C("div",F,[$(l(c),n(t.$attrs,{onItemClick:e}),null,16)]))}});v.__docgenInfo={exportName:"default",displayName:"Prompts",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/Prompts/index.vue"]};const w=[{key:"1",label:"🐛 提示集组件标题",description:"描述信息".repeat(3)},{key:"2",label:"🐛 我是被禁用的",disabled:!0},{key:"3",label:"🐛 提示集组件标题"},{key:"4",label:"🐛 提示集组件标题"}],A=[{key:"1",label:"🐛 提示集组件标题",description:"描述信息".repeat(3),itemStyle:{width:"calc(50% - 6px)",transition:"background .3s"},itemHoverStyle:{background:"linear-gradient(to bottom right, rgba(223, 59, 61, 0.9), rgba(203, 52, 244, 0.9)"},itemActiveStyle:{background:"linear-gradient(to bottom right, rgba(58, 32, 164, 0.9), rgba(254, 166, 223, 0.9)"}},{key:"2",label:"🐛 我是被禁用的",disabled:!0,itemStyle:{width:"calc(50% - 6px)",transition:"background .3s"},itemHoverStyle:{background:"linear-gradient(to bottom right, rgba(223, 59, 61, 0.9), rgba(203, 52, 244, 0.9)"},itemActiveStyle:{background:"linear-gradient(to bottom right, rgba(58, 32, 164, 0.9), rgba(254, 166, 223, 0.9)"}},{key:"3",label:"🐛 单个禁用控制更准确",disabled:!0,itemStyle:{width:"calc(50% - 6px)",transition:"background .3s"},itemHoverStyle:{background:"linear-gradient(to bottom right, rgba(223, 59, 61, 0.9), rgba(203, 52, 244, 0.9)"},itemActiveStyle:{background:"linear-gradient(to bottom right, rgba(58, 32, 164, 0.9), rgba(254, 166, 223, 0.9)"}},{key:"4",label:"🐛 提示集组件标题",itemStyle:{width:"calc(50% - 6px)",transition:"background .3s"},itemHoverStyle:{background:"linear-gradient(to bottom right, rgba(223, 59, 61, 0.9), rgba(203, 52, 244, 0.9)"},itemActiveStyle:{background:"linear-gradient(to bottom right, rgba(58, 32, 164, 0.9), rgba(254, 166, 223, 0.9)"}}],D=Array.from({length:3}).map((r,e)=>({key:e,label:`🐠 主标题 ${e}`,description:`描述 ${e}`,disabled:!1,itemStyle:{width:"calc(100% / 3 - 43px)",backgroundImage:"linear-gradient(137deg, #e5f4ff 0%, #efe7ff 100%)"},itemHoverStyle:{cursor:"unset"},children:[{key:`${e}-1`,label:`🐛 子标题 ${e}-1`,description:`描述 ${e}`,disabled:!1,itemStyle:{backgroundImage:"linear-gradient(137deg, #e5f4ff 0%, #efe7ff 100%)",border:"1px solid #FFF"},itemHoverStyle:{cursor:"unset"},children:[{key:`${e}-1-1`,label:`🐛 孙子标题 ${e}-1-1`,description:`描述 ${e}`,disabled:!1,itemStyle:{background:"rgba(255,255,255,0.45)",border:"1px solid #FFF"}},{key:`${e}-1-2`,label:`🐛 孙子标题 ${e}-1-1`,description:`描述 ${e}`,disabled:!1,itemStyle:{background:"rgba(255,255,255,0.45)",border:"1px solid #"}},{key:`${e}-1-3`,label:`🐛 孙子标题 ${e}-1-1`,description:`描述 ${e}`,disabled:!1,itemStyle:{background:"rgba(255,255,255,0.45)",border:"1px solid #FFF"}}]},{key:`${e}-2`,label:`🐛 子标题 ${e}-2`,description:`描述 ${e}`,disabled:!1,itemStyle:{background:"rgba(255,255,255,0.45)",border:"1px solid #FFF"}},{key:`${e}-3`,label:`🐛 子标题 ${e}-3`,description:`描述 ${e}`,disabled:!1,itemStyle:{background:"rgba(255,255,255,0.45)",border:"1px solid #FFF"}}]})),X={style:{display:"flex","flex-direction":"column",gap:"12px"}},I=i({__name:"WithChildrenDemo",setup(r){function e(t){p.success(`点击了 ${t.key}`)}return(t,d)=>(m(),C("div",X,[$(l(c),n({title:"🐛 提示集组件标题"},t.$attrs,{onItemClick:e}),null,16)]))}});I.__docgenInfo={exportName:"default",displayName:"WithChildrenDemo",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/Prompts/WithChildrenDemo.vue"]};const fe={title:"Example/Prompts 提示集组件 🎁",component:v,argTypes:{title:{control:"text",defaultValue:"欢迎使用Element-Plus-X AI 助手",description:"提示集的主标题文本内容"},items:{control:"object",defaultValue:[{title:"你好",content:"你好，我是Element-Plus-X AI 助手，你可以向我提问任何问题，我将尽力回答。"},{title:"你好",content:"你好，我是Element-Plus-X AI 助手，你可以向我提问任何问题，我将尽力回答。"}],description:"提示项数组，每个元素包含标签、图标、描述等信息（具体结构见下方说明）"},wrap:{control:"boolean",default:!1,description:"是否允许提示项自动换行（仅水平排列时生效）"},vertical:{control:"boolean",default:!1,description:"是否垂直排列提示项（垂直模式下布局方向为列排列）"},style:{control:"object",description:"自定义样式"}}},o={args:{title:"欢迎使用Element-Plus-X AI 助手",items:w,wrap:!1,vertical:!1,style:{}}},a={args:{title:"欢迎使用Element-Plus-X AI 助手",wrap:!0,vertical:!1,items:D},render:r=>({components:{PromptsWithChildren:I},setup(){return{attrs:r}},template:'<PromptsWithChildren v-bind="attrs" />'})},s={args:{title:"欢迎使用Element-Plus-X AI 助手",items:A,wrap:!0,vertical:!1,style:{width:"300px",padding:"12px",borderRadius:"8px",background:"linear-gradient(to bottom right, rgba(237, 43, 114, 0.9), rgba(223, 67, 62, 0.9)"}},render:r=>({components:{CustomStyle:P},setup(){return{attrs:r}},template:'<CustomStyle v-bind="attrs" />'})};var u,g,b;o.parameters={...o.parameters,docs:{...(u=o.parameters)==null?void 0:u.docs,source:{originalSource:`{
  args: {
    title: '欢迎使用Element-Plus-X AI 助手',
    items: mockPromptsItems,
    wrap: false,
    vertical: false,
    style: {}
  }
}`,...(b=(g=o.parameters)==null?void 0:g.docs)==null?void 0:b.source}}};var y,k,f;a.parameters={...a.parameters,docs:{...(y=a.parameters)==null?void 0:y.docs,source:{originalSource:`{
  args: {
    title: '欢迎使用Element-Plus-X AI 助手',
    wrap: true,
    vertical: false,
    items: WithChildrenItems
  },
  render: (args: any) => ({
    components: {
      PromptsWithChildren
    },
    setup() {
      return {
        attrs: args
      };
    },
    template: \`<PromptsWithChildren v-bind="attrs" />\`
  })
}`,...(f=(k=a.parameters)==null?void 0:k.docs)==null?void 0:f.source}}};var h,S,_;s.parameters={...s.parameters,docs:{...(h=s.parameters)==null?void 0:h.docs,source:{originalSource:`{
  args: {
    title: '欢迎使用Element-Plus-X AI 助手',
    items: CustomStyleItems,
    wrap: true,
    vertical: false,
    style: {
      width: '300px',
      padding: '12px',
      borderRadius: '8px',
      background: 'linear-gradient(to bottom right, rgba(237, 43, 114, 0.9), rgba(223, 67, 62, 0.9)'
    }
  },
  render: (args: any) => ({
    components: {
      CustomStyle
    },
    setup() {
      return {
        attrs: args
      };
    },
    template: \`<CustomStyle v-bind="attrs" />\`
  })
}`,...(_=(S=s.parameters)==null?void 0:S.docs)==null?void 0:_.source}}};const he=["PromptsDemo","ChildrenDemo","StyleDemo"];export{a as ChildrenDemo,o as PromptsDemo,s as StyleDemo,he as __namedExportsOrder,fe as default};
