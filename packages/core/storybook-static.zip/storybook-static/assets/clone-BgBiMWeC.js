import{b as r}from"./_baseIsEqual-eNA4N57V.js";var e=4;function a(o){return r(o,e)}export{a as c};
