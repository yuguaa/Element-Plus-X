import{_ as F}from"./index-jU8mFvCO.js";import{E as L,c as X,A as q,B as G,p as J}from"./el-button-D5jk_owF.js";import{d as E,m as g,c as K,s as Q,z as R,j as l,k as o,w as r,u,E as T,o as D,A as m,I as Y,y}from"./vue.esm-bundler-CWJkwHz9.js";import"./index-cNfuRqjS.js";import"./index-CvGOsCqS.js";import"./index-DjWSGOMW.js";import"./index-DD34QqSk.js";import"./index-BNTUvNAl.js";import{_ as B}from"./index-CiEKwO2o.js";import"./index-BXnpXdTJ.js";import"./index-CC1hLSnN.js";import{E as f}from"./index-DppTSAR2.js";import{_ as H}from"./_plugin-vue_export-helper-C6RzJgyC.js";/* empty css                   */import"./aria-BrQDUQ5m.js";import"./index-Bl31wyo9.js";import"./toNumber-DSBfpcGg.js";import"./get-BMJXpyNq.js";import"./index-CAWHOWdY.js";import"./curry-BXSChsWz.js";import"./cloneDeep-CCw91Nak.js";import"./_baseIsEqual-eNA4N57V.js";import"./_initCloneObject-8enN8I-i.js";import"./_arrayPush-lnK5TCUO.js";import"./index-opX51o-s.js";import"./pick-BkEcKBb1.js";import"./_basePickBy-Co_IC_Gu.js";import"./hasIn-Bi7gSSs4.js";import"./_overRest-DYeOVmH-.js";import"./event-BB_Ol6Sd.js";import"./el-tooltip-DjrQvLKJ.js";import"./el-popper-D1v00u9P.js";import"./isUndefined-DCTLXrZ8.js";import"./dropdown-hzEuDxer.js";import"./purify.es-DTUwIkWu.js";import"./mermaid.core-JEFoKH9L.js";import"./iframe-DBptVp5Y.js";import"./index-DrFu-skq.js";import"./katex-Czt20RFs.js";const Z={class:"sender-wrapper"},ee={class:"content"},te={style:{display:"flex"}},oe={style:{display:"flex"}},re={class:"action-list-self-wrap"},ne={class:"header-self-wrap"},le={class:"header-self-title"},se={class:"header-right"},ie={class:"prefix-self-wrap"},N=E({__name:"CustomSolt",setup(s){const n=g(),i=g(!1),d=K(()=>{var t;return(t=n.value)==null?void 0:t.$props.modelValue});Q(()=>{var t;i.value=!0,(t=n.value)==null||t.openHeader()});function S(){var t;(t=n.value)==null||t.blur()}function p(t="all"){var e;(e=n.value)==null||e.focus(t)}function w(){var t,e;i.value?(e=n.value)==null||e.closeHeader():(t=n.value)==null||t.openHeader(),i.value=!i.value}function j(){var t;i.value=!1,(t=n.value)==null||t.closeHeader()}function A(t){f.success(`点击了Submit ${t}`)}function M(){f.success("点击了Cancel")}function W(t){f.success(`Trigger ${t.oldValue}, ${t.newValue}, ${t.isOpen}, `)}function z(){f.success("RecordingChange")}return(t,e)=>{const a=L,b=X,U=F;return D(),R("div",Z,[l("div",ee,[l("div",te,[o(a,{type:"primary",style:{width:"fit-content"},onClick:e[0]||(e[0]=_=>{var c;return(c=u(n))==null?void 0:c.clear()})},{default:r(()=>e[6]||(e[6]=[m(" 使用组件实例清空 ")])),_:1,__:[6]}),o(a,{type:"primary",style:{width:"fit-content"},disabled:!u(d),onClick:e[1]||(e[1]=_=>{var c;return(c=u(n))==null?void 0:c.submit()})},{default:r(()=>e[7]||(e[7]=[m(" 使用组件实例提交 ")])),_:1,__:[7]},8,["disabled"]),o(a,{type:"primary",style:{width:"fit-content"},onClick:e[2]||(e[2]=_=>{var c;return(c=u(n))==null?void 0:c.cancel()})},{default:r(()=>e[8]||(e[8]=[m(" 使用组件实例取消 ")])),_:1,__:[8]})]),e[19]||(e[19]=l("br",null,null,-1)),l("div",oe,[o(a,{dark:"",type:"success",plain:"",onClick:e[3]||(e[3]=_=>p("start"))},{default:r(()=>e[9]||(e[9]=[m(" 文本最前方 ")])),_:1,__:[9]}),o(a,{dark:"",type:"success",plain:"",onClick:e[4]||(e[4]=_=>p("end"))},{default:r(()=>e[10]||(e[10]=[m(" 文本最后方 ")])),_:1,__:[10]}),o(a,{dark:"",type:"success",plain:"",onClick:e[5]||(e[5]=_=>p("all"))},{default:r(()=>e[11]||(e[11]=[m(" 整个文本 ")])),_:1,__:[11]}),o(a,{dark:"",type:"success",plain:"",onClick:S},{default:r(()=>e[12]||(e[12]=[m(" 失去焦点 ")])),_:1,__:[12]})]),e[20]||(e[20]=l("br",null,null,-1)),o(u(B),T(t.$attrs,{ref_key:"senderRef",ref:n,onSubmit:A,onCancel:M,onTrigger:W,onRecordingChange:z}),{"action-list":r(()=>[l("div",re,[o(a,{type:"danger",circle:""},{default:r(()=>[o(b,null,{default:r(()=>[o(u(G))]),_:1})]),_:1}),o(a,{type:"primary",circle:"",style:{rotate:"-45deg"}},{default:r(()=>[o(b,null,{default:r(()=>[o(u(J))]),_:1})]),_:1})])]),header:r(()=>[l("div",ne,[l("div",le,[e[14]||(e[14]=l("div",{class:"header-left"},"💯 欢迎使用 Element Plus X",-1)),l("div",se,[o(a,{onClick:Y(j,["stop"])},{default:r(()=>[o(b,null,{default:r(()=>[o(u(q))]),_:1}),e[13]||(e[13]=l("span",null,"关闭头部",-1))]),_:1,__:[13]})])]),e[15]||(e[15]=l("div",{class:"header-self-content"},"🦜 自定义头部内容",-1))])]),prefix:r(()=>[l("div",ie,[o(a,{dark:""},{default:r(()=>[o(b,null,{default:r(()=>[o(U)]),_:1}),e[16]||(e[16]=l("span",null,"自定义前缀",-1))]),_:1,__:[16]}),o(a,{color:"#626aef",dark:!0,onClick:w},{default:r(()=>e[17]||(e[17]=[m(" 打开/关闭头部 ")])),_:1,__:[17]})])]),footer:r(()=>e[18]||(e[18]=[l("div",{style:{display:"flex","align-items":"center","justify-content":"center",padding:"12px"}}," 默认变体 自定义底部 ",-1)])),_:1},16)])])}}}),ae="_content_1g795_8",de="_spin_1g795_1",pe={"sender-wrapper":"_sender-wrapper_1g795_1",content:ae,"header-self-wrap":"_header-self-wrap_1g795_16","header-self-title":"_header-self-title_1g795_22","header-self-content":"_header-self-content_1g795_30","prefix-self-wrap":"_prefix-self-wrap_1g795_39","action-list-self-wrap":"_action-list-self-wrap_1g795_42","is-loading":"_is-loading_1g795_51",spin:de},ue={$style:pe},ce=H(N,[["__cssModules",ue]]);N.__docgenInfo={exportName:"default",displayName:"CustomSolt",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/Sender/CustomSolt.vue"]};const me={class:"sender-wrapper"},O=E({__name:"index",setup(s){function n(p){f.success(`点击了Submit ${p}`)}function i(){f.success("点击了Cancel")}function d(p){f.success(`Trigger ${p.oldValue}, ${p.newValue}, ${p.isOpen}`)}function S(){f.success("RecordingChange")}return(p,w)=>(D(),R("div",me,[o(u(B),T(p.$attrs,{onSubmit:n,onCancel:i,onTrigger:d,onRecordingChange:S}),null,16)]))}}),I=H(O,[["__scopeId","data-v-df90543b"]]);O.__docgenInfo={exportName:"default",displayName:"Sender",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/Sender/index.vue"]};const Ze={title:"Example/Sender 输入框 💭",component:I,argTypes:{modelValue:{defaultValue:"",control:"text",description:"输入框的绑定值，使用 v-model 进行双向绑定。",table:{disable:!0}},placeholder:{defaultValue:"",control:"text",description:"输入框的提示语文本。"},autoSize:{defaultValue:{minRows:1,maxRows:6},control:"object",description:"设置输入框的最小展示行数和最大展示行数。"},readOnly:{defaultValue:!1,control:"boolean",description:"输入框是否为只读状态。"},disabled:{defaultValue:!1,control:"boolean",description:"输入框是否为禁用状态。"},submitBtnDisabled:{defaultValue:!1,control:"boolean",description:"内置发送按钮禁用状态。(注意使用场景)"},loading:{defaultValue:!1,control:"boolean",description:"是否显示加载状态。为 true 时，输入框会显示加载动画。"},clearable:{defaultValue:!1,control:"boolean",description:"输入框是否可清空内容。展示默认清空按钮。"},allowSpeech:{defaultValue:!1,control:"boolean",description:"是否允许语音输入。默认展示内置语音识别按钮，内置浏览器内置语音识别 API。"},submitType:{defaultValue:"enter",control:{type:"radio"},options:["enter","shiftEnter"],description:'提交方式，支持 "shiftEnter"（按 Shift + Enter 提交）。'},headerAnimationTimer:{defaultValue:300,control:"number",description:"输入框的自定义头部显示时长，单位为 ms。"},inputWidth:{control:"text",description:"输入框的宽度。"},variant:{defaultValue:"default",control:{type:"radio"},options:["default","updown"],description:'输入框的变体类型，支持 "default"、"updown"。'},showUpdown:{defaultValue:!0,control:"boolean",description:"当变体为 updown 时，是否展示内置样式。"},inputStyle:{defaultValue:{},control:"object",description:"输入框的样式。"},triggerStrings:{defaultValue:[],control:{type:"object"},description:"触发指令的字符串数组。"},triggerPopoverVisible:{defaultValue:!1,control:"boolean",description:"触发指令的弹框是否可见。需要使用 v-model:triggerPopoverVisible 进行控制。"},triggerPopoverWidth:{defaultValue:"fit-content",control:"text",description:"触发指令的弹框的宽度。可使用百分比等 css 单位。"},triggerPopoverLeft:{defaultValue:"0px",control:"text",description:"触发指令的弹框的左边距。可使用百分比等 css 单位。"},triggerPopoverOffset:{defaultValue:8,control:"number",description:"触发指令的弹框的间距。只能是数字类型，单位 px。"},triggerPopoverPlacement:{defaultValue:"top-start",control:{type:"radio"},options:["top","top-start","top-end","bottom","bottom-start","bottom-end","left","left-start","left-end","right","right-start","right-end"],description:"触发指令的弹框的位置。"}},args:{modelValue:"",placeholder:"请输入内容",autoSize:{minRows:1,maxRows:5},readOnly:!1,disabled:!1,submitBtnDisabled:!1,loading:!1,clearable:!0,allowSpeech:!0,submitType:"enter",headerAnimationTimer:300,inputWidth:"100%",variant:"default",showUpdown:!0,inputStyle:{color:"#626aef",fontSize:"14px",fontWeight:700},triggerStrings:["@","/"],triggerPopoverWidth:"400px",triggerPopoverLeft:"0px",triggerPopoverOffset:8,triggerPopoverPlacement:"top"}},v={render:s=>({components:{Sender:I},setup(){const n=g(s.modelValue),i=g(s.triggerPopoverVisible);return y(n,d=>{s.modelValue=d}),y(i,d=>{s.triggerPopoverVisible=d}),{args:s,model:n,triggerVisible:i}},template:`
      <Sender
        v-bind="args"
        v-model:modelValue="model"
        v-model:triggerPopoverVisible="triggerVisible"
      />
    `})},V={render:s=>({components:{CustomSolt:ce},setup(){const n=g(s.modelValue),i=g(s.triggerPopoverVisible);return y(n,d=>{s.modelValue=d}),y(i,d=>{s.triggerPopoverVisible=d}),{args:s,model:n,triggerVisible:i}},template:`
      <CustomSolt
        v-bind="args"
        v-model:modelValue="model"
        v-model:triggerPopoverVisible="triggerVisible"
      />
    `})};var C,x,P;v.parameters={...v.parameters,docs:{...(C=v.parameters)==null?void 0:C.docs,source:{originalSource:`{
  render: (args: any) => ({
    components: {
      Sender
    },
    setup() {
      const model = ref(args.modelValue);
      const triggerVisible = ref(args.triggerPopoverVisible);

      // 同步回 Storybook 控制面板
      watch(model, val => {
        args.modelValue = val;
      });
      watch(triggerVisible, val => {
        args.triggerPopoverVisible = val;
      });
      return {
        args,
        model,
        triggerVisible
      };
    },
    template: \`
      <Sender
        v-bind="args"
        v-model:modelValue="model"
        v-model:triggerPopoverVisible="triggerVisible"
      />
    \`
  })
}`,...(P=(x=v.parameters)==null?void 0:x.docs)==null?void 0:P.source}}};var h,k,$;V.parameters={...V.parameters,docs:{...(h=V.parameters)==null?void 0:h.docs,source:{originalSource:`{
  render: (args: any) => ({
    components: {
      CustomSolt
    },
    setup() {
      const model = ref(args.modelValue);
      const triggerVisible = ref(args.triggerPopoverVisible);

      // 同步回 Storybook 控制面板
      watch(model, val => {
        args.modelValue = val;
      });
      watch(triggerVisible, val => {
        args.triggerPopoverVisible = val;
      });
      return {
        args,
        model,
        triggerVisible
      };
    },
    template: \`
      <CustomSolt
        v-bind="args"
        v-model:modelValue="model"
        v-model:triggerPopoverVisible="triggerVisible"
      />
    \`
  })
}`,...($=(k=V.parameters)==null?void 0:k.docs)==null?void 0:$.source}}};const et=["SenderDemo","SlotDemo"];export{v as SenderDemo,V as SlotDemo,et as __namedExportsOrder,Ze as default};
