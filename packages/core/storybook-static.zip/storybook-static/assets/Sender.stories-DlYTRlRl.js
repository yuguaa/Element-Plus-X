import{_ as L}from"./index-k1LGQ39e.js";import{E as M,a as X,y as q,z as G,p as J}from"./el-button-V1zn0bod.js";import{d as E,m as g,c as K,s as Q,z as R,j as l,k as o,w as r,u,E as T,o as D,A as c,I as Y,y}from"./vue.esm-bundler-8nJxs6wk.js";import"./index-D8RSiuho.js";import"./index-DbPiP-QO.js";import"./index-B1zG7_g7.js";import"./index-QvyJPtVs.js";import"./index-De5-8KdU.js";import{_ as H}from"./index-_QxYalDX.js";import"./index-TCvcwvrN.js";import"./index-Bkme5epT.js";import{E as f}from"./index-C554dqMN.js";import{_ as I}from"./_plugin-vue_export-helper-C6RzJgyC.js";/* empty css                   */import"./aria-DsgnTM7o.js";import"./index-CWTj0pFa.js";import"./toNumber-DSBfpcGg.js";import"./get-BMJXpyNq.js";import"./index-D_Xd24h5.js";import"./curry-B2Zq5jzi.js";import"./cloneDeep-CCw91Nak.js";import"./_baseIsEqual-eNA4N57V.js";import"./_initCloneObject-8enN8I-i.js";import"./_arrayPush-lnK5TCUO.js";import"./index-BFAKzmXR.js";import"./pick-BkEcKBb1.js";import"./_basePickBy-Co_IC_Gu.js";import"./hasIn-Bi7gSSs4.js";import"./_overRest-DYeOVmH-.js";import"./event-BB_Ol6Sd.js";import"./el-popper-B-PjlTAE.js";import"./isUndefined-DCTLXrZ8.js";import"./el-tooltip-l0sNRNKZ.js";import"./dropdown-D4E6mAim.js";import"./purify.es-DTUwIkWu.js";import"./mermaid.core-CJRaG5gc.js";import"./iframe-4Dc-s8KP.js";import"./index-DrFu-skq.js";import"./katex-Czt20RFs.js";const Z={class:"sender-wrapper"},ee={class:"content"},te={style:{display:"flex"}},oe={style:{display:"flex"}},re={class:"action-list-self-wrap"},ne={class:"header-self-wrap"},le={class:"header-self-title"},ie={class:"header-right"},se={class:"prefix-self-wrap"},N=E({__name:"CustomSolt",setup(i){const n=g(),s=g(!1),d=K(()=>{var t;return(t=n.value)==null?void 0:t.$props.modelValue});Q(()=>{var t;s.value=!0,(t=n.value)==null||t.openHeader()});function S(){var t;(t=n.value)==null||t.blur()}function p(t="all"){var e;(e=n.value)==null||e.focus(t)}function C(){var t,e;s.value?(e=n.value)==null||e.closeHeader():(t=n.value)==null||t.openHeader(),s.value=!s.value}function j(){var t;s.value=!1,(t=n.value)==null||t.closeHeader()}function z(t){f.success(`点击了Submit ${t}`)}function W(){f.success("点击了Cancel")}function A(t){f.success(`Trigger ${t.oldValue}, ${t.newValue}, ${t.isOpen}, `)}function U(){f.success("RecordingChange")}return(t,e)=>{const a=M,b=X,F=L;return D(),R("div",Z,[l("div",ee,[l("div",te,[o(a,{type:"primary",style:{width:"fit-content"},onClick:e[0]||(e[0]=v=>{var m;return(m=u(n))==null?void 0:m.clear()})},{default:r(()=>e[6]||(e[6]=[c(" 使用组件实例清空 ")])),_:1,__:[6]}),o(a,{type:"primary",style:{width:"fit-content"},disabled:!u(d),onClick:e[1]||(e[1]=v=>{var m;return(m=u(n))==null?void 0:m.submit()})},{default:r(()=>e[7]||(e[7]=[c(" 使用组件实例提交 ")])),_:1,__:[7]},8,["disabled"]),o(a,{type:"primary",style:{width:"fit-content"},onClick:e[2]||(e[2]=v=>{var m;return(m=u(n))==null?void 0:m.cancel()})},{default:r(()=>e[8]||(e[8]=[c(" 使用组件实例取消 ")])),_:1,__:[8]})]),e[19]||(e[19]=l("br",null,null,-1)),l("div",oe,[o(a,{dark:"",type:"success",plain:"",onClick:e[3]||(e[3]=v=>p("start"))},{default:r(()=>e[9]||(e[9]=[c(" 文本最前方 ")])),_:1,__:[9]}),o(a,{dark:"",type:"success",plain:"",onClick:e[4]||(e[4]=v=>p("end"))},{default:r(()=>e[10]||(e[10]=[c(" 文本最后方 ")])),_:1,__:[10]}),o(a,{dark:"",type:"success",plain:"",onClick:e[5]||(e[5]=v=>p("all"))},{default:r(()=>e[11]||(e[11]=[c(" 整个文本 ")])),_:1,__:[11]}),o(a,{dark:"",type:"success",plain:"",onClick:S},{default:r(()=>e[12]||(e[12]=[c(" 失去焦点 ")])),_:1,__:[12]})]),e[20]||(e[20]=l("br",null,null,-1)),o(u(H),T(t.$attrs,{ref_key:"senderRef",ref:n,onSubmit:z,onCancel:W,onTrigger:A,onRecordingChange:U}),{"action-list":r(()=>[l("div",re,[o(a,{type:"danger",circle:""},{default:r(()=>[o(b,null,{default:r(()=>[o(u(G))]),_:1})]),_:1}),o(a,{type:"primary",circle:"",style:{rotate:"-45deg"}},{default:r(()=>[o(b,null,{default:r(()=>[o(u(J))]),_:1})]),_:1})])]),header:r(()=>[l("div",ne,[l("div",le,[e[14]||(e[14]=l("div",{class:"header-left"},"💯 欢迎使用 Element Plus X",-1)),l("div",ie,[o(a,{onClick:Y(j,["stop"])},{default:r(()=>[o(b,null,{default:r(()=>[o(u(q))]),_:1}),e[13]||(e[13]=l("span",null,"关闭头部",-1))]),_:1,__:[13]})])]),e[15]||(e[15]=l("div",{class:"header-self-content"},"🦜 自定义头部内容",-1))])]),prefix:r(()=>[l("div",se,[o(a,{dark:""},{default:r(()=>[o(b,null,{default:r(()=>[o(F)]),_:1}),e[16]||(e[16]=l("span",null,"自定义前缀",-1))]),_:1,__:[16]}),o(a,{color:"#626aef",dark:!0,onClick:C},{default:r(()=>e[17]||(e[17]=[c(" 打开/关闭头部 ")])),_:1,__:[17]})])]),footer:r(()=>e[18]||(e[18]=[l("div",{style:{display:"flex","align-items":"center","justify-content":"center",padding:"12px"}}," 默认变体 自定义底部 ",-1)])),_:1},16)])])}}}),ae=I(N,[["__scopeId","data-v-377ffe2d"]]);N.__docgenInfo={exportName:"default",displayName:"CustomSolt",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/Sender/CustomSolt.vue"]};const de={class:"sender-wrapper"},O=E({__name:"index",setup(i){function n(p){f.success(`点击了Submit ${p}`)}function s(){f.success("点击了Cancel")}function d(p){f.success(`Trigger ${p.oldValue}, ${p.newValue}, ${p.isOpen}`)}function S(){f.success("RecordingChange")}return(p,C)=>(D(),R("div",de,[o(u(H),T(p.$attrs,{onSubmit:n,onCancel:s,onTrigger:d,onRecordingChange:S}),null,16)]))}}),B=I(O,[["__scopeId","data-v-df90543b"]]);O.__docgenInfo={exportName:"default",displayName:"Sender",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/Sender/index.vue"]};const Je={title:"Example/Sender 输入框 💭",component:B,argTypes:{modelValue:{defaultValue:"",control:"text",description:"输入框的绑定值，使用 v-model 进行双向绑定。",table:{disable:!0}},placeholder:{defaultValue:"",control:"text",description:"输入框的提示语文本。"},autoSize:{defaultValue:{minRows:1,maxRows:6},control:"object",description:"设置输入框的最小展示行数和最大展示行数。"},readOnly:{defaultValue:!1,control:"boolean",description:"输入框是否为只读状态。"},disabled:{defaultValue:!1,control:"boolean",description:"输入框是否为禁用状态。"},submitBtnDisabled:{defaultValue:!1,control:"boolean",description:"内置发送按钮禁用状态。(注意使用场景)"},loading:{defaultValue:!1,control:"boolean",description:"是否显示加载状态。为 true 时，输入框会显示加载动画。"},clearable:{defaultValue:!1,control:"boolean",description:"输入框是否可清空内容。展示默认清空按钮。"},allowSpeech:{defaultValue:!1,control:"boolean",description:"是否允许语音输入。默认展示内置语音识别按钮，内置浏览器内置语音识别 API。"},submitType:{defaultValue:"enter",control:{type:"radio"},options:["enter","shiftEnter"],description:'提交方式，支持 "shiftEnter"（按 Shift + Enter 提交）。'},headerAnimationTimer:{defaultValue:300,control:"number",description:"输入框的自定义头部显示时长，单位为 ms。"},inputWidth:{control:"text",description:"输入框的宽度。"},variant:{defaultValue:"default",control:{type:"radio"},options:["default","updown"],description:'输入框的变体类型，支持 "default"、"updown"。'},showUpdown:{defaultValue:!0,control:"boolean",description:"当变体为 updown 时，是否展示内置样式。"},inputStyle:{defaultValue:{},control:"object",description:"输入框的样式。"},triggerStrings:{defaultValue:[],control:{type:"object"},description:"触发指令的字符串数组。"},triggerPopoverVisible:{defaultValue:!1,control:"boolean",description:"触发指令的弹框是否可见。需要使用 v-model:triggerPopoverVisible 进行控制。"},triggerPopoverWidth:{defaultValue:"fit-content",control:"text",description:"触发指令的弹框的宽度。可使用百分比等 css 单位。"},triggerPopoverLeft:{defaultValue:"0px",control:"text",description:"触发指令的弹框的左边距。可使用百分比等 css 单位。"},triggerPopoverOffset:{defaultValue:8,control:"number",description:"触发指令的弹框的间距。只能是数字类型，单位 px。"},triggerPopoverPlacement:{defaultValue:"top-start",control:{type:"radio"},options:["top","top-start","top-end","bottom","bottom-start","bottom-end","left","left-start","left-end","right","right-start","right-end"],description:"触发指令的弹框的位置。"}},args:{modelValue:"",placeholder:"请输入内容",autoSize:{minRows:1,maxRows:5},readOnly:!1,disabled:!1,submitBtnDisabled:!1,loading:!1,clearable:!0,allowSpeech:!0,submitType:"enter",headerAnimationTimer:300,inputWidth:"100%",variant:"default",showUpdown:!0,inputStyle:{color:"#626aef",fontSize:"14px",fontWeight:700},triggerStrings:["@","/"],triggerPopoverWidth:"400px",triggerPopoverLeft:"0px",triggerPopoverOffset:8,triggerPopoverPlacement:"top"}},V={render:i=>({components:{Sender:B},setup(){const n=g(i.modelValue),s=g(i.triggerPopoverVisible);return y(n,d=>{i.modelValue=d}),y(s,d=>{i.triggerPopoverVisible=d}),{args:i,model:n,triggerVisible:s}},template:`
      <Sender
        v-bind="args"
        v-model:modelValue="model"
        v-model:triggerPopoverVisible="triggerVisible"
      />
    `})},_={render:i=>({components:{CustomSolt:ae},setup(){const n=g(i.modelValue),s=g(i.triggerPopoverVisible);return y(n,d=>{i.modelValue=d}),y(s,d=>{i.triggerPopoverVisible=d}),{args:i,model:n,triggerVisible:s}},template:`
      <CustomSolt
        v-bind="args"
        v-model:modelValue="model"
        v-model:triggerPopoverVisible="triggerVisible"
      />
    `})};var w,P,x;V.parameters={...V.parameters,docs:{...(w=V.parameters)==null?void 0:w.docs,source:{originalSource:`{
  render: (args: any) => ({
    components: {
      Sender
    },
    setup() {
      const model = ref(args.modelValue);
      const triggerVisible = ref(args.triggerPopoverVisible);

      // 同步回 Storybook 控制面板
      watch(model, val => {
        args.modelValue = val;
      });
      watch(triggerVisible, val => {
        args.triggerPopoverVisible = val;
      });
      return {
        args,
        model,
        triggerVisible
      };
    },
    template: \`
      <Sender
        v-bind="args"
        v-model:modelValue="model"
        v-model:triggerPopoverVisible="triggerVisible"
      />
    \`
  })
}`,...(x=(P=V.parameters)==null?void 0:P.docs)==null?void 0:x.source}}};var k,h,$;_.parameters={..._.parameters,docs:{...(k=_.parameters)==null?void 0:k.docs,source:{originalSource:`{
  render: (args: any) => ({
    components: {
      CustomSolt
    },
    setup() {
      const model = ref(args.modelValue);
      const triggerVisible = ref(args.triggerPopoverVisible);

      // 同步回 Storybook 控制面板
      watch(model, val => {
        args.modelValue = val;
      });
      watch(triggerVisible, val => {
        args.triggerPopoverVisible = val;
      });
      return {
        args,
        model,
        triggerVisible
      };
    },
    template: \`
      <CustomSolt
        v-bind="args"
        v-model:modelValue="model"
        v-model:triggerPopoverVisible="triggerVisible"
      />
    \`
  })
}`,...($=(h=_.parameters)==null?void 0:h.docs)==null?void 0:$.source}}};const Ke=["SenderDemo","SlotDemo"];export{V as SenderDemo,_ as SlotDemo,Ke as __namedExportsOrder,Je as default};
