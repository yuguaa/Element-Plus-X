import{m as d,a as u}from"./mock-B9k1oZu6.js";import{k as l,s as g,t as _,o as f,v as y,x as w,y as x,z as M}from"./vue.esm-bundler-DTnAEySg.js";import{C as k}from"./index-B7Ywq2Kg.js";import{T as C}from"./index-DL2SpORW.js";import{r as T}from"./index-CUgNUrsk.js";import{_ as h}from"./_plugin-vue_export-helper-UBQfR8ld.js";import"./isArguments-DJsDwUOI.js";import"./constants-Cu4joN5-.js";import"./mermaid.core-CUV9Ow59.js";import"./iframe-BtJ0FfGe.js";import"./_commonjsHelpers-DYJ6H3P4.js";import"./_overRest-4-f3tAV-.js";import"./index-DrFu-skq.js";const v={class:"component-container"},c=l({__name:"index",setup(F){const p=[T({forceLegacyMathML:!0,delay:100})];return(m,P)=>(f(),g(k,{"md-plugins":p},{default:_(()=>[y("div",v,[w(C,x(M(m.$attrs)),null,16)])]),_:1}))}}),D=h(c,[["__scopeId","data-v-1ee15c11"]]);c.__docgenInfo={exportName:"default",displayName:"Typewriter",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/合并代码/Element-Plus-X/packages/core/src/stories/Typewriter/index.vue"]};const O={title:"Example/Typewriter 打字器组件 ✍",component:D,tags:["autodocs"],argTypes:{content:{control:"text"},isMarkdown:{control:"boolean"},typing:{control:"object"},isFog:{control:"boolean"}},args:{typing:{step:2,interval:100,suffix:"|",isRequestEnd:!0},isFog:!0,isMarkdown:!0}},e={args:{content:d,isFog:!0,isMarkdown:!0}},r={args:{content:u}};var t,o,s;e.parameters={...e.parameters,docs:{...(t=e.parameters)==null?void 0:t.docs,source:{originalSource:`{
  args: {
    content: mdContent,
    isFog: true,
    isMarkdown: true
  } as Story['args']
}`,...(s=(o=e.parameters)==null?void 0:o.docs)==null?void 0:s.source}}};var a,n,i;r.parameters={...r.parameters,docs:{...(a=r.parameters)==null?void 0:a.docs,source:{originalSource:`{
  args: {
    content: mathMdContent
  } as Story['args']
}`,...(i=(n=r.parameters)==null?void 0:n.docs)==null?void 0:i.source}}};const U=["TypewriterDemo","MathRenderDemo"];export{r as MathRenderDemo,e as TypewriterDemo,U as __namedExportsOrder,O as default};
