import{m as d,a as u}from"./mock-Bykb4b7U.js";import{d as l,f as g,w as _,o as f,j as y,k as w,n as x,l as M}from"./vue.esm-bundler-CWJkwHz9.js";import{C as k}from"./index-DjWSGOMW.js";import{T as C}from"./index-BXnpXdTJ.js";import{r as T}from"./index-BjjtmkGe.js";import{_ as h}from"./_plugin-vue_export-helper-C6RzJgyC.js";import"./purify.es-DTUwIkWu.js";import"./mermaid.core-JEFoKH9L.js";import"./iframe-DBptVp5Y.js";import"./_initCloneObject-8enN8I-i.js";import"./_overRest-DYeOVmH-.js";import"./index-DrFu-skq.js";const v={class:"component-container"},c=l({__name:"index",setup(F){const p=[T({forceLegacyMathML:!0,delay:100})];return(m,P)=>(f(),g(k,{"md-plugins":p},{default:_(()=>[y("div",v,[w(C,x(M(m.$attrs)),null,16)])]),_:1}))}}),D=h(c,[["__scopeId","data-v-1ee15c11"]]);c.__docgenInfo={exportName:"default",displayName:"Typewriter",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/Typewriter/index.vue"]};const z={title:"Example/Typewriter 打字器组件 ✍",component:D,tags:["autodocs"],argTypes:{content:{control:"text"},isMarkdown:{control:"boolean"},typing:{control:"object"},isFog:{control:"boolean"}},args:{typing:{step:2,interval:100,suffix:"|",isRequestEnd:!0},isFog:!0,isMarkdown:!0}},e={args:{content:d,isFog:!0,isMarkdown:!0}},t={args:{content:u}};var r,o,s;e.parameters={...e.parameters,docs:{...(r=e.parameters)==null?void 0:r.docs,source:{originalSource:`{
  args: {
    content: mdContent,
    isFog: true,
    isMarkdown: true
  } as Story['args']
}`,...(s=(o=e.parameters)==null?void 0:o.docs)==null?void 0:s.source}}};var a,n,i;t.parameters={...t.parameters,docs:{...(a=t.parameters)==null?void 0:a.docs,source:{originalSource:`{
  args: {
    content: mathMdContent
  } as Story['args']
}`,...(i=(n=t.parameters)==null?void 0:n.docs)==null?void 0:i.source}}};const O=["TypewriterDemo","MathRenderDemo"];export{t as MathRenderDemo,e as TypewriterDemo,O as __namedExportsOrder,z as default};
