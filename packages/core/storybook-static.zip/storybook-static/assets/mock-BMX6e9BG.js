const a="https://avatars.githubusercontent.com/u/76239030?v=4",e="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png",t=`
### 行内公式
1. 欧拉公式：$e^{i\\pi} + 1 = 0$
2. 二次方程求根公式：$x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}$
3. 向量点积：$\\vec{a} \\cdot \\vec{b} = a_x b_x + a_y b_y + a_z b_z$

### 块级公式
1. 傅里叶变换：
$$
F(\\omega) = \\int_{-\\infty}^{\\infty} f(t) e^{-i\\omega t} dt
$$

2. 矩阵乘法：
$$
\\begin{bmatrix}
a & b \\\\
c & d
\\end{bmatrix}
\\begin{bmatrix}
x \\\\
y
\\end{bmatrix}
=
\\begin{bmatrix}
ax + by \\\\
cx + dy
\\end{bmatrix}
$$

3. 泰勒级数展开：
$$
f(x) = \\sum_{n=0}^{\\infty} \\frac{f^{(n)}(a)}{n!} (x - a)^n
$$

4. 拉普拉斯方程：
$$
\\nabla^2 u = \\frac{\\partial^2 u}{\\partial x^2} + \\frac{\\partial^2 u}{\\partial y^2} + \\frac{\\partial^2 u}{\\partial z^2} = 0
$$

5. 概率密度函数（正态分布）：
$$
f(x) = \\frac{1}{\\sqrt{2\\pi\\sigma^2}} e^{-\\frac{(x-\\mu)^2}{2\\sigma^2}}
$$

# 标题
这是一个 Markdown 示例。
- 列表项 1
- 列表项 2
**粗体文本** 和 *斜体文本*

- [x] Add some task
- [ ] Do some task
`.trim(),r=`
###### 非\`commonMark\`语法，dom多个
<pre>
<code class="language-java">
public class HelloWorld {
  public static void main(String[] args) {
      System.out.println("Hello, world!");
  }
}
</code>
<code class="language-javascript">console.log('Hello, world!');</code>
</pre>
\`\`\`echarts
use codeXRender for echarts render
\`\`\`
### javascript
\`\`\`javascript
console.log('Hello, world!');
\`\`\`
### java
\`\`\`java
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, world!");
    }
}
\`\`\`
\`\`\`typescript
import {
  ArrowDownBold,
  CopyDocument,
  Moon,
  Sunny
} from '@element-plus/icons-vue';
import { ElButton, ElSpace } from 'element-plus';
import { h } from 'vue';

/* ----------------------------------- 按钮组 ---------------------------------- */

/**
 * @description 描述 language标签
 * @date 2025-06-25 17:48:15
 * @author tingfeng
 *
 * @export
 * @param language
 */
export function languageEle(language: string) {
  return h(
    ElSpace,
    {},
    {}
  );
}
\`\`\`
`.trim(),n=`

### mermaid 饼状图
\`\`\`mermaid
pie
    "传媒及文化相关" : 35
    "广告与市场营销" : 8
    "游戏开发" : 15
    "影视动画与特效" : 12
    "互联网产品设计" : 10
    "VR/AR开发" : 5
    "其他" : 15
\`\`\`

`,o=`
### mermaid 流程图
\`\`\`mermaid
flowchart TD
    %% 前端专项四层结构
    A["战略层
    【提升用户体验】"]
    --> B["架构层
    【微前端方案选型】"]
    --> C["框架层
    【React+TS技术栈】"]
    --> D["实现层
    【组件库开发】"]
    style A fill:#FFD700,stroke:#FFA500
    style B fill:#87CEFA,stroke:#1E90FF
    style C fill:#9370DB,stroke:#663399
    style D fill:#FF6347,stroke:#CD5C5C

\`\`\`
### mermaid 数学公式
\`\`\`mermaid
sequenceDiagram
    autonumber
    participant 1 as $$alpha$$
    participant 2 as $$beta$$
    1->>2: Solve: $$sqrt{2+2}$$
    2-->>1: Answer: $$2$$
\`\`\`

`,i=`
<a href="https://element-plus-x.com/">element-plus-x</a>
<h1>标题1</h1>
<h2>标题2</h2>
`,l=[{key:1,role:"ai",placement:"start",content:"欢迎使用 Element Plus X .".repeat(5),loading:!0,shape:"corner",variant:"filled",isMarkdown:!1,typing:{step:2,suffix:"💗"},avatar:e,avatarSize:"32px"},{key:2,role:"user",placement:"end",content:"这是用户的消息",loading:!0,shape:"corner",variant:"outlined",isMarkdown:!1,avatar:a,avatarSize:"32px"},{key:3,role:"ai",placement:"start",content:"欢迎使用 Element Plus X .".repeat(5),loading:!0,shape:"corner",variant:"filled",isMarkdown:!1,typing:{step:2,suffix:"💗"},avatar:e,avatarSize:"32px"},{key:4,role:"user",placement:"end",content:"这是用户的消息",loading:!0,shape:"corner",variant:"outlined",isMarkdown:!1,avatar:a,avatarSize:"32px"},{key:5,role:"ai",placement:"start",content:"欢迎使用 Element Plus X .".repeat(5),loading:!0,shape:"corner",variant:"filled",isMarkdown:!1,typing:{step:2,suffix:"💗"},avatar:e,avatarSize:"32px"},{key:6,role:"user",placement:"end",content:"这是用户的消息",loading:!0,shape:"corner",variant:"outlined",isMarkdown:!1,avatar:a,avatarSize:"32px"},{key:7,role:"ai",placement:"start",content:"欢迎使用 Element Plus X .".repeat(5),loading:!0,shape:"corner",variant:"filled",isMarkdown:!1,typing:{step:2,suffix:"💗",isRequestEnd:!0},avatar:e,avatarSize:"32px"},{key:8,role:"user",placement:"end",content:"这是用户的消息",loading:!0,shape:"corner",variant:"outlined",isMarkdown:!1,avatar:a,avatarSize:"32px"}],s={word:"#5E74A8",excel:"#4A6B4A",ppt:"#C27C40",pdf:"#5A6976",txt:"#D4C58C",mark:"#FFA500",image:"#8E7CC3",audio:"#A67B5B",video:"#4A5568",three:"#5F9E86",code:"#4B636E",database:"#4A5A6B",link:"#5D7CBA",zip:"#8B5E3C",file:"#AAB2BF",unknown:"#888888"};export{o as a,a as b,s as c,e as d,l as e,n as f,i as g,r as h,t as m};
