import{m as re,h as pe,f as ae,a as ge,g as fe}from"./mock-BMX6e9BG.js";import{M as H,_ as A,E as ke,s as R}from"./index-Bkme5epT.js";import{E as k}from"./el-button-V1zn0bod.js";import{d as h,m as _,c as M,s as N,z as y,k as t,j as c,w as a,E as S,u as w,G as T,o as x,A as p,h as s,x as we,C as P}from"./vue.esm-bundler-8nJxs6wk.js";import{_ as F}from"./_plugin-vue_export-helper-C6RzJgyC.js";import{E as v}from"./el-popper-B-PjlTAE.js";import"./el-tooltip-l0sNRNKZ.js";import{E as se}from"./index-C554dqMN.js";import"./mermaid.core-CJRaG5gc.js";import"./iframe-4Dc-s8KP.js";import"./purify.es-DTUwIkWu.js";import"./_initCloneObject-8enN8I-i.js";import"./_overRest-DYeOVmH-.js";import"./index-DrFu-skq.js";import"./aria-DsgnTM7o.js";import"./event-BB_Ol6Sd.js";import"./curry-B2Zq5jzi.js";import"./katex-Czt20RFs.js";import"./get-BMJXpyNq.js";import"./index-BFAKzmXR.js";import"./pick-BkEcKBb1.js";import"./_basePickBy-Co_IC_Gu.js";import"./hasIn-Bi7gSSs4.js";import"./_arrayPush-lnK5TCUO.js";import"./index-CWTj0pFa.js";import"./isUndefined-DCTLXrZ8.js";const Ce={class:"component-container"},le=h({__name:"customAttrs",props:{markdown:{}},setup(g){const i=g,o=_(),e=_(0);function n(){o.value=setInterval(()=>{e.value+=5,e.value>i.markdown.length&&(clearInterval(o.value),e.value=i.markdown.length)},100)}function l(){o.value&&(clearInterval(o.value),o.value=null)}const m=M(()=>i.markdown.slice(0,e.value));function C(){e.value=0,o.value&&(clearInterval(o.value),o.value=null),n()}return N(()=>{n()}),(b,d)=>{const u=k;return x(),y(T,null,[t(u,{onClick:n},{default:a(()=>d[0]||(d[0]=[p(" 开始 ")])),_:1,__:[0]}),t(u,{onClick:l},{default:a(()=>d[1]||(d[1]=[p(" 暂停 ")])),_:1,__:[1]}),t(u,{onClick:C},{default:a(()=>d[2]||(d[2]=[p(" 重新开始 ")])),_:1,__:[2]}),c("div",Ce,[d[3]||(d[3]=c("h4",null,"自定义属性",-1)),t(w(H),S(b.$attrs,{markdown:w(m)}),null,16,["markdown"])])],64)}}}),ve=F(le,[["__scopeId","data-v-fb69b44e"]]);le.__docgenInfo={exportName:"default",displayName:"customAttrs",description:"",tags:{},props:[{name:"markdown",required:!0,type:{name:"string"}}],sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/XMarkdown/customAttrs.vue"]};const de=h({__name:"CodeHeader",props:{toggleExpand:{type:Function}},setup(g){const i=g;return(o,e)=>(x(),y("div",{onClick:e[0]||(e[0]=n=>i.toggleExpand(n))},"组件插槽"))}});de.__docgenInfo={exportName:"default",displayName:"CodeHeader",description:"",tags:{},props:[{name:"toggleExpand",required:!0,type:{name:"TSFunctionType"}}],sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/XMarkdown/CodeHeader.vue"]};const _e={class:"component-container"},ie=h({__name:"highlight-code",props:{markdown:{}},setup(g){const i=g,o=_(),e=_(0);function n(){o.value=setInterval(()=>{e.value+=10,e.value>i.markdown.length&&(clearInterval(o.value),e.value=i.markdown.length)},100)}function l(){o.value&&(clearInterval(o.value),o.value=null)}const m=M(()=>i.markdown.slice(0,e.value)),C={codeHeaderLanguage:u=>s("span",{onClick:r=>u.toggleExpand(r)},{default:()=>"点击切换折叠状态"}),codeHeaderControl:u=>s(ke,{class:"markdown-language-header-space",direction:"horizontal"},{default:()=>[s(v,{content:"切换主题",placement:"top"},{default:()=>s(k,{class:"shiki-header-button",onClick:()=>{u.toggleTheme()}},{default:()=>u.isDark.value?"🌞":"🌙"})}),s(v,{content:"复制代码",placement:"top"},{default:()=>s(k,{class:"shiki-header-button",onClick:()=>{u.copyCode(u.renderLines)}},{default:()=>"🥢"})})]})},b={codeHeaderLanguage:de};function d(){e.value=0,o.value&&(clearInterval(o.value),o.value=null),n()}return N(()=>{n()}),(u,r)=>(x(),y(T,null,[t(w(k),{onClick:n},{default:a(()=>r[0]||(r[0]=[p(" 开始 ")])),_:1,__:[0]}),t(w(k),{onClick:l},{default:a(()=>r[1]||(r[1]=[p(" 暂停 ")])),_:1,__:[1]}),t(w(k),{onClick:d},{default:a(()=>r[2]||(r[2]=[p(" 重新开始 ")])),_:1,__:[2]}),c("div",_e,[r[3]||(r[3]=c("h4",null,"默认插槽",-1)),t(A,S(u.$attrs,{markdown:w(m),"custom-attrs":{code:()=>({name:"code",class:"inline-code"}),a:f=>({target:"_blank",rel:"noopener noreferrer"})}}),null,16,["markdown"]),r[4]||(r[4]=c("h4",null,"函数自定义插槽以及使用暴露出来的方法",-1)),t(A,S(u.$attrs,{markdown:w(m),"code-x-slot":C}),null,16,["markdown"]),r[5]||(r[5]=c("h4",null,"组件插槽",-1)),t(A,S(u.$attrs,{markdown:w(m),"code-x-slot":b}),null,16,["markdown"])])],64))}}),be=F(ie,[["__scopeId","data-v-245e1c89"]]);ie.__docgenInfo={exportName:"default",displayName:"highlight-code",description:"",tags:{},props:[{name:"markdown",required:!0,type:{name:"string"}}],sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/XMarkdown/highlight-code.vue"]};const he={class:"component-container"},me=h({__name:"index",props:{markdown:{}},setup(g){const i=g,o=_(),e=_(0);function n(){o.value=setInterval(()=>{e.value+=5,e.value>i.markdown.length&&(clearInterval(o.value),e.value=i.markdown.length)},100)}function l(){o.value&&(clearInterval(o.value),o.value=null)}const m=M(()=>i.markdown.slice(0,e.value));function C(){e.value=0,o.value&&(clearInterval(o.value),o.value=null),n()}return N(()=>{n()}),(b,d)=>{const u=k;return x(),y(T,null,[t(u,{onClick:n},{default:a(()=>d[0]||(d[0]=[p(" 开始 ")])),_:1,__:[0]}),t(u,{onClick:l},{default:a(()=>d[1]||(d[1]=[p(" 暂停 ")])),_:1,__:[1]}),t(u,{onClick:C},{default:a(()=>d[2]||(d[2]=[p(" 重新开始 ")])),_:1,__:[2]}),c("div",he,[t(A,S(b.$attrs,{markdown:w(m)}),null,16,["markdown"])])],64)}}}),ye=F(me,[["__scopeId","data-v-864e12ca"]]);me.__docgenInfo={exportName:"default",displayName:"XMarkdown",description:"",tags:{},props:[{name:"markdown",required:!0,type:{name:"string"}}],sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/XMarkdown/index.vue"]};const xe={class:"mermaid-header"},Se={class:"header-left"},Me={class:"mode-badge"},Fe={class:"header-right"},ue=h({__name:"MermaidHeader",setup(g){const i=we();async function o(){try{const e=`🧩 组件插槽自定义：

${i.rawContent}

✨ 使用 Element Plus X 组件`;await navigator.clipboard.writeText(e),se.success("🎉 组件插槽自定义复制成功！")}catch{}}return(e,n)=>{const l=k,m=v;return x(),y("div",xe,[c("div",Se,[n[0]||(n[0]=c("span",{class:"icon"},"🧩",-1)),n[1]||(n[1]=c("span",{class:"title"},"组件插槽",-1)),c("span",Me,P(e.$attrs.showSourceCode?"📝 源码":"📊 图表"),1)]),c("div",Fe,[t(m,{content:"放大图表",placement:"top"},{default:a(()=>[t(l,{class:"header-btn zoom-btn",size:"small",type:"primary",onClick:e.$attrs.zoomIn},{default:a(()=>n[2]||(n[2]=[p(" 🔍 ")])),_:1,__:[2]},8,["onClick"])]),_:1}),t(m,{content:"缩小图表",placement:"top"},{default:a(()=>[t(l,{class:"header-btn zoom-btn",size:"small",type:"primary",onClick:e.$attrs.zoomOut},{default:a(()=>n[3]||(n[3]=[p(" 🔍- ")])),_:1,__:[3]},8,["onClick"])]),_:1}),t(m,{content:"重置视图",placement:"top"},{default:a(()=>[t(l,{class:"header-btn reset-btn",size:"small",type:"warning",onClick:e.$attrs.reset},{default:a(()=>n[4]||(n[4]=[p(" 🔄 ")])),_:1,__:[4]},8,["onClick"])]),_:1}),t(m,{content:"切换视图",placement:"top"},{default:a(()=>[t(l,{class:"header-btn toggle-btn",size:"small",type:"info",onClick:e.$attrs.toggleCode},{default:a(()=>[p(P(e.$attrs.showSourceCode?"👁️":"📝"),1)]),_:1},8,["onClick"])]),_:1}),t(m,{content:"自定义复制逻辑",placement:"top"},{default:a(()=>[t(l,{class:"header-btn copy-btn",size:"small",type:"success",onClick:o},{default:a(()=>n[5]||(n[5]=[p(" 📋 ")])),_:1,__:[5]})]),_:1}),t(m,{content:"下载图片",placement:"top"},{default:a(()=>[t(l,{class:"header-btn download-btn",size:"small",type:"success",onClick:e.$attrs.download},{default:a(()=>n[6]||(n[6]=[p(" 💾 ")])),_:1,__:[6]},8,["onClick"])]),_:1})])])}}}),Ie=F(ue,[["__scopeId","data-v-0c45001a"]]);ue.__docgenInfo={exportName:"default",displayName:"MermaidHeader",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/XMarkdown/MermaidHeader.vue"]};const De={class:"component-container"},$e={class:"demo-section"},ze={class:"demo-section"},Ee={class:"demo-section"},ce=h({__name:"mermaid-slot",props:{markdown:{},mermaidConfig:{},themes:{}},setup(g){const i=g,o=M(()=>i.mermaidConfig),e={codeMermaidHeaderControl:r=>s("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"12px 16px",background:"linear-gradient(135deg, #667eea 0%, #764ba2 100%)",color:"white",borderRadius:"8px",boxShadow:"0 4px 12px rgba(102, 126, 234, 0.3)"}},[s("div",{style:{display:"flex",alignItems:"center",gap:"12px"}},[s("span",{style:{fontSize:"16px"}},"🎨"),s("span",{style:{fontWeight:"600"}},"Custom Mermaid"),s("span",{style:{fontSize:"12px",background:"rgba(255,255,255,0.25)",padding:"4px 8px",borderRadius:"12px"}},r.showSourceCode?"📝 源码":"📊 图表")]),s("div",{style:{display:"flex"}},[s(v,{content:"放大",placement:"top"},{default:()=>s(k,{size:"small",type:"primary",text:!0,bg:!0,style:{background:"rgba(255,255,255,0.2)",color:"white",border:"none"},onClick:r.zoomIn},()=>"🔍")}),s(v,{content:"重置缩放",placement:"top"},{default:()=>s(k,{size:"small",type:"primary",text:!0,bg:!0,style:{background:"rgba(255,255,255,0.2)",color:"white",border:"none"},onClick:r.reset},()=>"🔄")}),s(v,{content:r.showSourceCode?"查看图表":"查看源码",placement:"top"},{default:()=>s(k,{size:"small",type:"primary",text:!0,bg:!0,style:{background:"rgba(255,255,255,0.2)",color:"white",border:"none"},onClick:r.toggleCode},()=>r.showSourceCode?"👁️":"📝")}),s(v,{content:"自定义复制",placement:"top"},{default:()=>s(k,{size:"small",type:"primary",text:!0,bg:!0,style:{background:"rgba(255,255,255,0.2)",color:"white",border:"none"},onClick:async()=>{try{const f=`🎨 自定义前缀：

${r.rawContent}

📝 来自：Element-Plus-X`;await navigator.clipboard.writeText(f),se.success("🎉 组件插槽自定义复制成功！")}catch{}}},()=>"📋")}),s(v,{content:"下载图片",placement:"top"},{default:()=>s(k,{size:"small",type:"primary",text:!0,bg:!0,style:{background:"rgba(255,255,255,0.2)",color:"white",border:"none"},onClick:r.download},()=>"💾")})])])},n={codeMermaidHeaderControl:Ie},l=_(),m=_(0);function C(){l.value=setInterval(()=>{m.value+=5,m.value>i.markdown.length&&(clearInterval(l.value),m.value=i.markdown.length)},100)}function b(){l.value&&(clearInterval(l.value),l.value=null)}const d=M(()=>i.markdown.slice(0,m.value));function u(){m.value=0,l.value&&(clearInterval(l.value),l.value=null),C()}return N(()=>{C()}),(r,f)=>(x(),y(T,null,[t(w(k),{onClick:C},{default:a(()=>f[0]||(f[0]=[p(" 开始 ")])),_:1,__:[0]}),t(w(k),{onClick:b},{default:a(()=>f[1]||(f[1]=[p(" 暂停 ")])),_:1,__:[1]}),t(w(k),{onClick:u},{default:a(()=>f[2]||(f[2]=[p(" 重新开始 ")])),_:1,__:[2]}),c("div",De,[c("div",$e,[f[3]||(f[3]=c("h4",null,"1. 📋 通过mermaidConfig 配置",-1)),t(w(H),{markdown:d.value,"mermaid-config":o.value,themes:r.themes},null,8,["markdown","mermaid-config","themes"])]),c("div",ze,[f[4]||(f[4]=c("h4",null,"2. 🔧 函数式插槽",-1)),t(w(H),{markdown:d.value,"code-x-slot":e,themes:r.themes},null,8,["markdown","themes"])]),c("div",Ee,[f[5]||(f[5]=c("h4",null,"3. 🧩 组件插槽",-1)),t(w(H),{markdown:d.value,"code-x-slot":n,themes:r.themes},null,8,["markdown","themes"])])])],64))}}),Xe=F(ce,[["__scopeId","data-v-ff4bf8f5"]]);ce.__docgenInfo={exportName:"default",displayName:"mermaid-slot",description:"",tags:{},props:[{name:"markdown",required:!0,type:{name:"string"}},{name:"mermaidConfig",required:!1,type:{name:"MermaidToolbarConfig"}},{name:"themes",required:!1,type:{name:`{\r
  light: string;\r
  dark: string;\r
}`}}],sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/XMarkdown/mermaid-slot.vue"]};const st={title:"Example/XMarkdown 渲染组件 📜",component:ye,tags:["autodocs"],argTypes:{markdown:{control:"text"},themes:{control:"object",defaultValue:{...R}},mermaidConfig:{control:"object"}},args:{markdown:re,themes:{...R},mermaidConfig:{showToolbar:!0,showFullscreen:!0,showZoomIn:!0,showZoomOut:!0,showReset:!0,showDownload:!0,toolbarStyle:{},toolbarClass:"mermaid-config-toolbar"}}},I={args:{markdown:re}},D={args:{markdown:pe},render:g=>({components:{HighlightCodeDemo:be},setup(){return{attrs:g}},template:'<HighlightCodeDemo v-bind="attrs"  />'})},$={args:{markdown:ae}},z={args:{markdown:ge}},E={args:{markdown:ae,mermaidConfig:{showToolbar:!0,showFullscreen:!0,showZoomIn:!0,showZoomOut:!0,showReset:!0,showDownload:!0,toolbarStyle:{background:"linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%)",boxShadow:"0 4px 16px rgba(139, 92, 246, 0.3)",borderRadius:"8px"},iconColor:"#FFFFFF",tabTextColor:"#FFFFFF"}},render:g=>({components:{MermaidSlot:Xe},setup(){return{attrs:g}},template:'<MermaidSlot v-bind="attrs"  />'})},X={args:{markdown:fe,customAttrs:{a:()=>({target:"_blank",rel:"noopener noreferrer"}),h1:{style:{color:"red",fontSize:"24px"}},h2:{style:{color:"blue",fontSize:"20px"}}}},render:g=>({components:{CustomAttrs:ve},setup(){return{attrs:g}},template:'<CustomAttrs v-bind="attrs" />'})};var q,U,Z;I.parameters={...I.parameters,docs:{...(q=I.parameters)==null?void 0:q.docs,source:{originalSource:`{
  args: {
    markdown: mdContent
  } as Story['args']
}`,...(Z=(U=I.parameters)==null?void 0:U.docs)==null?void 0:Z.source}}};var O,j,B;D.parameters={...D.parameters,docs:{...(O=D.parameters)==null?void 0:O.docs,source:{originalSource:`{
  args: {
    markdown: highlightMdContent
  },
  render: args => ({
    components: {
      HighlightCodeDemo
    },
    setup() {
      return {
        attrs: args
      };
    },
    template: \`<HighlightCodeDemo v-bind="attrs"  />\`
  })
}`,...(B=(j=D.parameters)==null?void 0:j.docs)==null?void 0:B.source}}};var V,L,G;$.parameters={...$.parameters,docs:{...(V=$.parameters)==null?void 0:V.docs,source:{originalSource:`{
  args: {
    markdown: mermaidMdContent
  } as Story['args']
}`,...(G=(L=$.parameters)==null?void 0:L.docs)==null?void 0:G.source}}};var W,J,K;z.parameters={...z.parameters,docs:{...(W=z.parameters)==null?void 0:W.docs,source:{originalSource:`{
  args: {
    markdown: mathMdContent
  } as Story['args']
}`,...(K=(J=z.parameters)==null?void 0:J.docs)==null?void 0:K.source}}};var Q,Y,ee;E.parameters={...E.parameters,docs:{...(Q=E.parameters)==null?void 0:Q.docs,source:{originalSource:`{
  args: {
    markdown: mermaidMdContent,
    mermaidConfig: {
      showToolbar: true,
      showFullscreen: true,
      showZoomIn: true,
      showZoomOut: true,
      showReset: true,
      showDownload: true,
      toolbarStyle: {
        background: 'linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%)',
        boxShadow: '0 4px 16px rgba(139, 92, 246, 0.3)',
        borderRadius: '8px'
      },
      iconColor: '#FFFFFF',
      tabTextColor: '#FFFFFF'
    }
  } as Story['args'],
  render: args => ({
    components: {
      MermaidSlot
    },
    setup() {
      return {
        attrs: args
      };
    },
    template: \`<MermaidSlot v-bind="attrs"  />\`
  })
  // render: () => MermaidSlot
}`,...(ee=(Y=E.parameters)==null?void 0:Y.docs)==null?void 0:ee.source}}};var te,oe,ne;X.parameters={...X.parameters,docs:{...(te=X.parameters)==null?void 0:te.docs,source:{originalSource:`{
  args: {
    markdown: customAttrContent,
    customAttrs: {
      a: () => ({
        target: '_blank',
        rel: 'noopener noreferrer'
      }),
      h1: {
        style: {
          color: 'red',
          fontSize: '24px'
        }
      },
      h2: {
        style: {
          color: 'blue',
          fontSize: '20px'
        }
      }
    }
  } as Story['args'],
  render: args => ({
    components: {
      CustomAttrs
    },
    setup() {
      return {
        attrs: args
      };
    },
    template: \`<CustomAttrs v-bind="attrs" />\`
  })
}`,...(ne=(oe=X.parameters)==null?void 0:oe.docs)==null?void 0:ne.source}}};const lt=["MarkdownDemo","highlightMdContentDemo","PieRenderDemo","MathRenderDemo","MermaidSlotDemo","CustomAttrsDemo"];export{X as CustomAttrsDemo,I as MarkdownDemo,z as MathRenderDemo,E as MermaidSlotDemo,$ as PieRenderDemo,lt as __namedExportsOrder,st as default,D as highlightMdContentDemo};
