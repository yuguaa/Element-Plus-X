import{_ as K}from"./link-DSSwps5E.js";import{E as X,w as J,x as q,y as G}from"./base-D7tCU8sP.js";import{E as Q}from"./el-button-C-YQqSO2.js";import{k as T,j as v,b as Y,n as Z,B as ee,c as D,v as l,x as o,t as r,u as m,K as I,o as L,L as c,J as te,M as oe,w as y}from"./vue.esm-bundler-DTnAEySg.js";import{E as d}from"./index-B1aegxae.js";import{_ as O}from"./index-DnZJW47t.js";import{_ as B}from"./_plugin-vue_export-helper-UBQfR8ld.js";import"./get-DecQlHrd.js";import"./typescript-F_jgqlnI.js";import"./aria-BUADUvnR.js";import"./el-popper-Don6kwc5.js";import"./index-Dd4Za6Df.js";import"./pick-DvrFlX69.js";import"./_basePickBy-B_60Sftk.js";import"./hasIn-CdKFcgYV.js";import"./_arrayPush-lnK5TCUO.js";import"./isArguments-DJsDwUOI.js";import"./_overRest-4-f3tAV-.js";import"./index-D_jmEDI_.js";import"./isUndefined-DCTLXrZ8.js";import"./el-input-DOE7ksmk.js";import"./event-BB_Ol6Sd.js";import"./index-DrVO5HE5.js";import"./error-Cq9Fpw4b.js";import"./dropdown-OPH3RILi.js";const ne={class:"sender-wrapper"},re={class:"content"},le={style:{display:"flex"}},se={style:{display:"flex"}},ie={class:"action-list-self-wrap"},ae={class:"header-self-wrap"},de={class:"header-self-title"},ue={class:"header-right"},pe={class:"prefix-self-wrap"},H=T({__name:"CustomSolt",setup(s){const n=v(),i=v(!1),u=Y(()=>{var t;return(t=n.value)==null?void 0:t.$props.modelValue});Z(()=>{var t,e;i.value=!0,(t=n.value)==null||t.openHeader(),window.addEventListener("keydown",k),(e=n.value)==null||e.inputInstance.addEventListener("keydown",C)}),ee(()=>{var t;window.removeEventListener("keydown",k),(t=n.value)==null||t.inputInstance.removeEventListener("keydown",C)});function w(){var t;(t=n.value)==null||t.blur()}function p(t="all"){var e;(e=n.value)==null||e.focus(t)}function S(){var t,e;i.value?(e=n.value)==null||e.closeHeader():(t=n.value)==null||t.openHeader(),i.value=!i.value}function j(){var t;i.value=!1,(t=n.value)==null||t.closeHeader()}function U(t){d.success(`点击了Submit ${t}`)}function M(){d.success("点击了Cancel")}function z(t){d.success(`Trigger 旧值：${t.oldValue}, 新值：${t.newValue}, 弹框是否打开：${t.isOpen}`)}function A(){d.success("RecordingChange")}function k(t){switch(t.key){case"w":d.success("w 被按下，输入框不受影响");break;case"a":d.success("a 被按下，输入框不受影响");break;case"s":d.success("s 被按下，输入框不受影响");break;case"d":d.success("d 被按下，输入框不受影响");break}}function C(t){["w","a","s","d"].includes(t.key)&&t.preventDefault()}return(t,e)=>{const a=Q,b=X,F=K;return L(),D("div",ne,[l("div",re,[l("div",le,[o(a,{type:"primary",style:{width:"fit-content"},onClick:e[0]||(e[0]=g=>{var f;return(f=m(n))==null?void 0:f.clear()})},{default:r(()=>e[6]||(e[6]=[c(" 使用组件实例清空 ",-1)])),_:1,__:[6]}),o(a,{type:"primary",style:{width:"fit-content"},disabled:!m(u),onClick:e[1]||(e[1]=g=>{var f;return(f=m(n))==null?void 0:f.submit()})},{default:r(()=>e[7]||(e[7]=[c(" 使用组件实例提交 ",-1)])),_:1,__:[7]},8,["disabled"]),o(a,{type:"primary",style:{width:"fit-content"},onClick:e[2]||(e[2]=g=>{var f;return(f=m(n))==null?void 0:f.cancel()})},{default:r(()=>e[8]||(e[8]=[c(" 使用组件实例取消 ",-1)])),_:1,__:[8]})]),e[19]||(e[19]=l("br",null,null,-1)),l("div",se,[o(a,{dark:"",type:"success",plain:"",onClick:e[3]||(e[3]=g=>p("start"))},{default:r(()=>e[9]||(e[9]=[c(" 文本最前方 ",-1)])),_:1,__:[9]}),o(a,{dark:"",type:"success",plain:"",onClick:e[4]||(e[4]=g=>p("end"))},{default:r(()=>e[10]||(e[10]=[c(" 文本最后方 ",-1)])),_:1,__:[10]}),o(a,{dark:"",type:"success",plain:"",onClick:e[5]||(e[5]=g=>p("all"))},{default:r(()=>e[11]||(e[11]=[c(" 整个文本 ",-1)])),_:1,__:[11]}),o(a,{dark:"",type:"success",plain:"",onClick:w},{default:r(()=>e[12]||(e[12]=[c(" 失去焦点 ",-1)])),_:1,__:[12]})]),e[20]||(e[20]=l("br",null,null,-1)),o(m(O),I(t.$attrs,{ref_key:"senderRef",ref:n,onSubmit:U,onCancel:M,onTrigger:z,onRecordingChange:A}),{"action-list":r(()=>[l("div",ie,[o(a,{type:"danger",circle:""},{default:r(()=>[o(b,null,{default:r(()=>[o(m(q))]),_:1})]),_:1}),o(a,{type:"primary",circle:"",style:{rotate:"-45deg"}},{default:r(()=>[o(b,null,{default:r(()=>[o(m(G))]),_:1})]),_:1})])]),header:r(()=>[l("div",ae,[l("div",de,[e[14]||(e[14]=l("div",{class:"header-left"}," 💯 欢迎使用 Element Plus X ",-1)),l("div",ue,[o(a,{onClick:oe(j,["stop"])},{default:r(()=>[o(b,null,{default:r(()=>[o(m(J))]),_:1}),e[13]||(e[13]=l("span",null,"关闭头部",-1))]),_:1,__:[13]})])]),e[15]||(e[15]=l("div",{class:"header-self-content"}," 🦜 自定义头部内容 ",-1))])]),prefix:r(()=>[l("div",pe,[o(a,{dark:""},{default:r(()=>[o(b,null,{default:r(()=>[o(F)]),_:1}),e[16]||(e[16]=l("span",null,"自定义前缀",-1))]),_:1,__:[16]}),o(a,{color:"#626aef",dark:!0,onClick:S},{default:r(()=>e[17]||(e[17]=[c(" 打开/关闭头部 ",-1)])),_:1,__:[17]})])]),footer:r(()=>e[18]||(e[18]=[l("div",{style:{display:"flex","align-items":"center","justify-content":"center",padding:"12px"}}," 默认变体 自定义底部 ",-1)])),"trigger-popover":r(({triggerString:g})=>[c(" 当前触发的字符为："+te(`${g}`)+" 这是我自定义的弹框，在这里你可以自定义弹框内容。包括对弹框做一些按键控制的自定义操作。请尝试控制方向 w/a/s/d 这几个按键。 ",1)]),_:1},16)])])}}}),ce=B(H,[["__scopeId","data-v-ca109f04"]]);H.__docgenInfo={exportName:"default",displayName:"CustomSolt",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/合并代码/Element-Plus-X/packages/core/src/stories/Sender/CustomSolt.vue"]};const me={class:"sender-wrapper"},N=T({__name:"index",setup(s){function n(p){d.success(`点击了Submit ${p}`)}function i(){d.success("点击了Cancel")}function u(p){d.success(`Trigger ${p.oldValue}, ${p.newValue}, ${p.isOpen}`)}function w(){d.success("RecordingChange")}return(p,S)=>(L(),D("div",me,[o(m(O),I(p.$attrs,{onSubmit:n,onCancel:i,onTrigger:u,onRecordingChange:w}),null,16)]))}}),W=B(N,[["__scopeId","data-v-7de255d9"]]);N.__docgenInfo={exportName:"default",displayName:"Sender",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/合并代码/Element-Plus-X/packages/core/src/stories/Sender/index.vue"]};const We={title:"Example/Sender 输入框 💭",component:W,argTypes:{modelValue:{defaultValue:"",control:"text",description:"输入框的绑定值，使用 v-model 进行双向绑定。",table:{disable:!0}},placeholder:{defaultValue:"",control:"text",description:"输入框的提示语文本。"},autoSize:{defaultValue:{minRows:1,maxRows:6},control:"object",description:"设置输入框的最小展示行数和最大展示行数。"},readOnly:{defaultValue:!1,control:"boolean",description:"输入框是否为只读状态。"},disabled:{defaultValue:!1,control:"boolean",description:"输入框是否为禁用状态。"},submitBtnDisabled:{defaultValue:!1,control:"boolean",description:"内置发送按钮禁用状态。(注意使用场景)"},loading:{defaultValue:!1,control:"boolean",description:"是否显示加载状态。为 true 时，输入框会显示加载动画。"},clearable:{defaultValue:!1,control:"boolean",description:"输入框是否可清空内容。展示默认清空按钮。"},allowSpeech:{defaultValue:!1,control:"boolean",description:"是否允许语音输入。默认展示内置语音识别按钮，内置浏览器内置语音识别 API。"},submitType:{defaultValue:"enter",control:{type:"radio"},options:["enter","shiftEnter","cmdOrCtrlEnter","altEnter"],description:'提交方式，支持 "shiftEnter"（按 Shift + Enter 提交）。'},headerAnimationTimer:{defaultValue:300,control:"number",description:"输入框的自定义头部显示时长，单位为 ms。"},inputWidth:{control:"text",description:"输入框的宽度。"},variant:{defaultValue:"default",control:{type:"radio"},options:["default","updown"],description:'输入框的变体类型，支持 "default"、"updown"。'},showUpdown:{defaultValue:!0,control:"boolean",description:"当变体为 updown 时，是否展示内置样式。"},inputStyle:{defaultValue:{},control:"object",description:"输入框的样式。"},triggerStrings:{defaultValue:[],control:{type:"object"},description:"触发指令的字符串数组。"},triggerPopoverVisible:{defaultValue:!1,control:"boolean",description:"触发指令的弹框是否可见。需要使用 v-model:triggerPopoverVisible 进行控制。"},triggerPopoverWidth:{defaultValue:"fit-content",control:"text",description:"触发指令的弹框的宽度。可使用百分比等 css 单位。"},triggerPopoverLeft:{defaultValue:"0px",control:"text",description:"触发指令的弹框的左边距。可使用百分比等 css 单位。"},triggerPopoverOffset:{defaultValue:8,control:"number",description:"触发指令的弹框的间距。只能是数字类型，单位 px。"},triggerPopoverPlacement:{defaultValue:"top-start",control:{type:"radio"},options:["top","top-start","top-end","bottom","bottom-start","bottom-end","left","left-start","left-end","right","right-start","right-end"],description:"触发指令的弹框的位置。"}},args:{modelValue:"",placeholder:"请输入内容",autoSize:{minRows:1,maxRows:5},readOnly:!1,disabled:!1,submitBtnDisabled:!1,loading:!1,clearable:!0,allowSpeech:!0,submitType:"enter",headerAnimationTimer:300,inputWidth:"100%",variant:"default",showUpdown:!0,inputStyle:{color:"#626aef",fontSize:"14px",fontWeight:700},triggerStrings:["@","/"],triggerPopoverWidth:"400px",triggerPopoverLeft:"0px",triggerPopoverOffset:8,triggerPopoverPlacement:"top"}},V={render:s=>({components:{Sender:W},setup(){const n=v(s.modelValue),i=v(s.triggerPopoverVisible);return y(n,u=>{s.modelValue=u}),y(i,u=>{s.triggerPopoverVisible=u}),{args:s,model:n,triggerVisible:i}},template:`
      <Sender
        v-bind="args"
        v-model:modelValue="model"
        v-model:triggerPopoverVisible="triggerVisible"
      />
    `})},_={render:s=>({components:{CustomSolt:ce},setup(){const n=v(s.modelValue),i=v(s.triggerPopoverVisible);return y(n,u=>{s.modelValue=u}),y(i,u=>{s.triggerPopoverVisible=u}),{args:s,model:n,triggerVisible:i}},template:`
      <CustomSolt
        v-bind="args"
        v-model:modelValue="model"
        v-model:triggerPopoverVisible="triggerVisible"
      />
    `})};var x,P,h;V.parameters={...V.parameters,docs:{...(x=V.parameters)==null?void 0:x.docs,source:{originalSource:`{
  render: (args: any) => ({
    components: {
      Sender
    },
    setup() {
      const model = ref(args.modelValue);
      const triggerVisible = ref(args.triggerPopoverVisible);

      // 同步回 Storybook 控制面板
      watch(model, val => {
        args.modelValue = val;
      });
      watch(triggerVisible, val => {
        args.triggerPopoverVisible = val;
      });
      return {
        args,
        model,
        triggerVisible
      };
    },
    template: \`
      <Sender
        v-bind="args"
        v-model:modelValue="model"
        v-model:triggerPopoverVisible="triggerVisible"
      />
    \`
  })
}`,...(h=(P=V.parameters)==null?void 0:P.docs)==null?void 0:h.source}}};var E,$,R;_.parameters={..._.parameters,docs:{...(E=_.parameters)==null?void 0:E.docs,source:{originalSource:`{
  render: (args: any) => ({
    components: {
      CustomSolt
    },
    setup() {
      const model = ref(args.modelValue);
      const triggerVisible = ref(args.triggerPopoverVisible);

      // 同步回 Storybook 控制面板
      watch(model, val => {
        args.modelValue = val;
      });
      watch(triggerVisible, val => {
        args.triggerPopoverVisible = val;
      });
      return {
        args,
        model,
        triggerVisible
      };
    },
    template: \`
      <CustomSolt
        v-bind="args"
        v-model:modelValue="model"
        v-model:triggerPopoverVisible="triggerVisible"
      />
    \`
  })
}`,...(R=($=_.parameters)==null?void 0:$.docs)==null?void 0:R.source}}};const je=["SenderDemo","SlotDemo"];export{V as SenderDemo,_ as SlotDemo,je as __namedExportsOrder,We as default};
