import{_ as X}from"./index-k1LGQ39e.js";import{E as J,a as L,y as q,z as G,p as K}from"./el-button-V1zn0bod.js";import{d as M,m as y,c as Q,s as Y,z as R,j as s,k as o,w as n,u as p,E as P,o as N,A as m,I as Z,y as D}from"./vue.esm-bundler-8nJxs6wk.js";import"./index-D8RSiuho.js";import"./index-DbPiP-QO.js";import"./index-B1zG7_g7.js";import"./index-QvyJPtVs.js";import{M as H}from"./index-De5-8KdU.js";import"./index-_QxYalDX.js";import"./index-TCvcwvrN.js";import"./index-Bkme5epT.js";/* empty css                   */import{E as i}from"./index-C554dqMN.js";import{_ as I}from"./_plugin-vue_export-helper-C6RzJgyC.js";import"./aria-DsgnTM7o.js";import"./index-CWTj0pFa.js";import"./toNumber-DSBfpcGg.js";import"./get-BMJXpyNq.js";import"./index-D_Xd24h5.js";import"./curry-B2Zq5jzi.js";import"./cloneDeep-CCw91Nak.js";import"./_baseIsEqual-eNA4N57V.js";import"./_initCloneObject-8enN8I-i.js";import"./_arrayPush-lnK5TCUO.js";import"./index-BFAKzmXR.js";import"./pick-BkEcKBb1.js";import"./_basePickBy-Co_IC_Gu.js";import"./hasIn-Bi7gSSs4.js";import"./_overRest-DYeOVmH-.js";import"./event-BB_Ol6Sd.js";import"./el-popper-B-PjlTAE.js";import"./isUndefined-DCTLXrZ8.js";import"./el-tooltip-l0sNRNKZ.js";import"./dropdown-D4E6mAim.js";import"./purify.es-DTUwIkWu.js";import"./mermaid.core-CJRaG5gc.js";import"./iframe-4Dc-s8KP.js";import"./index-DrFu-skq.js";import"./katex-Czt20RFs.js";const ee={class:"sender-wrapper"},te={class:"content"},oe={style:{display:"flex"}},ne={style:{display:"flex"}},le={class:"action-list-self-wrap"},se={class:"header-self-wrap"},re={class:"header-self-title"},ae={class:"header-right"},ie={class:"prefix-self-wrap"},O=M({__name:"CustomSolt",setup(d){const l=y(),a=y(!1),V=Q(()=>{var t;return(t=l.value)==null?void 0:t.$props.modelValue});Y(()=>{var t;a.value=!0,(t=l.value)==null||t.openHeader()});function C(){var t;(t=l.value)==null||t.blur()}function g(t="all"){var e;(e=l.value)==null||e.focus(t)}function u(){var t,e;a.value?(e=l.value)==null||e.closeHeader():(t=l.value)==null||t.openHeader(),a.value=!a.value}function f(){var t;a.value=!1,(t=l.value)==null||t.closeHeader()}function T(t){i.success(`点击了Submit ${t}`)}function z(){i.success("点击了Cancel")}function A(t,e){i.success(`handleSearch ${t}, ${e}`)}function U(t,e){i.success(`handleSelect  ${JSON.stringify(t)}, ${e}`)}function F(){i.success("RecordingChange")}return(t,e)=>{const r=J,_=L,W=X;return N(),R("div",ee,[s("div",te,[s("div",oe,[o(r,{type:"primary",style:{width:"fit-content"},onClick:e[0]||(e[0]=v=>{var c;return(c=p(l))==null?void 0:c.clear()})},{default:n(()=>e[6]||(e[6]=[m(" 使用组件实例清空 ")])),_:1,__:[6]}),o(r,{type:"primary",style:{width:"fit-content"},disabled:!p(V),onClick:e[1]||(e[1]=v=>{var c;return(c=p(l))==null?void 0:c.submit()})},{default:n(()=>e[7]||(e[7]=[m(" 使用组件实例提交 ")])),_:1,__:[7]},8,["disabled"]),o(r,{type:"primary",style:{width:"fit-content"},onClick:e[2]||(e[2]=v=>{var c;return(c=p(l))==null?void 0:c.cancel()})},{default:n(()=>e[8]||(e[8]=[m(" 使用组件实例取消 ")])),_:1,__:[8]})]),e[19]||(e[19]=s("br",null,null,-1)),s("div",ne,[o(r,{dark:"",type:"success",plain:"",onClick:e[3]||(e[3]=v=>g("start"))},{default:n(()=>e[9]||(e[9]=[m(" 文本最前方 ")])),_:1,__:[9]}),o(r,{dark:"",type:"success",plain:"",onClick:e[4]||(e[4]=v=>g("end"))},{default:n(()=>e[10]||(e[10]=[m(" 文本最后方 ")])),_:1,__:[10]}),o(r,{dark:"",type:"success",plain:"",onClick:e[5]||(e[5]=v=>g("all"))},{default:n(()=>e[11]||(e[11]=[m(" 整个文本 ")])),_:1,__:[11]}),o(r,{dark:"",type:"success",plain:"",onClick:C},{default:n(()=>e[12]||(e[12]=[m(" 失去焦点 ")])),_:1,__:[12]})]),e[20]||(e[20]=s("br",null,null,-1)),o(p(H),P(t.$attrs,{ref_key:"senderRef",ref:l,onSubmit:T,onCancel:z,onSearch:A,onSelect:U,onRecordingChange:F}),{"action-list":n(()=>[s("div",le,[o(r,{type:"danger",circle:""},{default:n(()=>[o(_,null,{default:n(()=>[o(p(G))]),_:1})]),_:1}),o(r,{type:"primary",circle:"",style:{rotate:"-45deg"}},{default:n(()=>[o(_,null,{default:n(()=>[o(p(K))]),_:1})]),_:1})])]),header:n(()=>[s("div",se,[s("div",re,[e[14]||(e[14]=s("div",{class:"header-left"},"💯 欢迎使用 Element Plus X",-1)),s("div",ae,[o(r,{onClick:Z(f,["stop"])},{default:n(()=>[o(_,null,{default:n(()=>[o(p(q))]),_:1}),e[13]||(e[13]=s("span",null,"关闭头部",-1))]),_:1,__:[13]})])]),e[15]||(e[15]=s("div",{class:"header-self-content"},"🦜 自定义头部内容",-1))])]),prefix:n(()=>[s("div",ie,[o(r,{dark:""},{default:n(()=>[o(_,null,{default:n(()=>[o(W)]),_:1}),e[16]||(e[16]=s("span",null,"自定义前缀",-1))]),_:1,__:[16]}),o(r,{color:"#626aef",dark:!0,onClick:u},{default:n(()=>e[17]||(e[17]=[m(" 打开/关闭头部 ")])),_:1,__:[17]})])]),footer:n(()=>e[18]||(e[18]=[s("div",{style:{display:"flex","align-items":"center","justify-content":"center",padding:"12px"}}," 默认变体 自定义底部 ",-1)])),_:1},16)])])}}}),de=I(O,[["__scopeId","data-v-40d0b3e5"]]);O.__docgenInfo={exportName:"default",displayName:"CustomSolt",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/MentionSender/CustomSolt.vue"]};const ue={class:"sender-wrapper"},j=M({__name:"index",setup(d){function l(u){i.success(`点击了Submit ${u}`)}function a(){i.success("点击了Cancel")}function V(u,f){i.success(`handleSearch ${u}, ${f}`)}function C(u,f){i.success(`handleSelect  ${JSON.stringify(u)}, ${f}`)}function g(){i.success("RecordingChange")}return(u,f)=>(N(),R("div",ue,[o(p(H),P(u.$attrs,{onSubmit:l,onCancel:a,onSearch:V,onSelect:C,onRecordingChange:g}),null,16)]))}}),B=I(j,[["__scopeId","data-v-ea9224d5"]]);j.__docgenInfo={exportName:"default",displayName:"MentionSender",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/MentionSender/index.vue"]};const Ke={title:"Example/MentionSender 提及输入框 🦥",component:B,argTypes:{modelValue:{defaultValue:"",control:"text",description:"输入框的绑定值，使用 v-model 进行双向绑定。",table:{disable:!0}},placeholder:{defaultValue:"",control:"text",description:"输入框的提示语文本。"},autoSize:{defaultValue:{minRows:1,maxRows:6},control:"object",description:"设置输入框的最小展示行数和最大展示行数。"},readOnly:{defaultValue:!1,control:"boolean",description:"输入框是否为只读状态。"},disabled:{defaultValue:!1,control:"boolean",description:"输入框是否为禁用状态。"},submitBtnDisabled:{defaultValue:!1,control:"boolean",description:"内置发送按钮禁用状态。(注意使用场景)"},loading:{defaultValue:!1,control:"boolean",description:"是否显示加载状态。为 true 时，输入框会显示加载动画。"},clearable:{defaultValue:!1,control:"boolean",description:"输入框是否可清空内容。展示默认清空按钮。"},allowSpeech:{defaultValue:!1,control:"boolean",description:"是否允许语音输入。默认展示内置语音识别按钮，内置浏览器内置语音识别 API。"},submitType:{defaultValue:"enter",control:{type:"select"},options:["enter","shiftEnter"],description:'提交方式，支持 "shiftEnter"（按 Shift + Enter 提交）。'},headerAnimationTimer:{defaultValue:300,control:"number",description:"输入框的自定义头部显示时长，单位为 ms。"},inputWidth:{control:"text",description:"输入框的宽度。"},variant:{defaultValue:"default",control:{type:"select"},options:["default","updown"],description:'输入框的变体类型，支持 "default"、"updown"。'},showUpdown:{defaultValue:!0,control:"boolean",description:"当变体为 updown 时，是否展示内置样式。"},inputStyle:{defaultValue:{},control:"object",description:"输入框的样式。"},options:{defaultValue:[],control:{type:"object"},description:"可以传入一个数组，用于定义提及选项列表。"},triggerStrings:{defaultValue:[],control:{type:"object"},description:"触发指令的字符串数组。"},triggerPopoverOffset:{defaultValue:8,control:"number",description:"触发指令的弹框的间距。只能是数字类型，单位 px。"},triggerPopoverPlacement:{defaultValue:"top-start",control:{type:"select"},options:["top","top-start","top-end","bottom","bottom-start","bottom-end","left","left-start","left-end","right","right-start","right-end"],description:"触发指令的弹框的位置。"}},args:{modelValue:"",placeholder:"请输入内容",autoSize:{minRows:1,maxRows:5},readOnly:!1,disabled:!1,submitBtnDisabled:!1,loading:!1,clearable:!0,allowSpeech:!0,submitType:"enter",headerAnimationTimer:300,inputWidth:"100%",variant:"default",showUpdown:!0,inputStyle:{color:"#626aef",fontSize:"14px",fontWeight:700},triggerStrings:["@","/"],options:[{value:"value1",label:"选项1"},{value:"value2",label:"选项2",disabled:!0},{value:"value3",label:"选项3"}],triggerPopoverOffset:8,triggerPopoverPlacement:"top"}},S={render:d=>({components:{MentionSender:B},setup(){const l=y(d.modelValue);return D(l,a=>{d.modelValue=a}),{args:d,model:l}},template:`
      <MentionSender
        v-bind="args"
        v-model:modelValue="model"
      />
    `})},b={render:d=>({components:{CustomSolt:de},setup(){const l=y(d.modelValue);return D(l,a=>{d.modelValue=a}),{args:d,model:l}},template:`
      <CustomSolt
        v-bind="args"
        v-model:modelValue="model"
      />
    `})};var h,w,k;S.parameters={...S.parameters,docs:{...(h=S.parameters)==null?void 0:h.docs,source:{originalSource:`{
  render: (args: any) => ({
    components: {
      MentionSender
    },
    setup() {
      const model = ref(args.modelValue);

      // 同步回 Storybook 控制面板
      watch(model, val => {
        args.modelValue = val;
      });
      return {
        args,
        model
      };
    },
    template: \`
      <MentionSender
        v-bind="args"
        v-model:modelValue="model"
      />
    \`
  })
}`,...(k=(w=S.parameters)==null?void 0:w.docs)==null?void 0:k.source}}};var x,$,E;b.parameters={...b.parameters,docs:{...(x=b.parameters)==null?void 0:x.docs,source:{originalSource:`{
  render: (args: any) => ({
    components: {
      CustomSolt
    },
    setup() {
      const model = ref(args.modelValue);

      // 同步回 Storybook 控制面板
      watch(model, val => {
        args.modelValue = val;
      });
      return {
        args,
        model
      };
    },
    template: \`
      <CustomSolt
        v-bind="args"
        v-model:modelValue="model"
      />
    \`
  })
}`,...(E=($=b.parameters)==null?void 0:$.docs)==null?void 0:E.source}}};const Qe=["MentionSenderDemo","SlotDemo"];export{S as MentionSenderDemo,b as SlotDemo,Qe as __namedExportsOrder,Ke as default};
