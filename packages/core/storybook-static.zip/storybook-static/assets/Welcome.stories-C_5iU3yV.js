import{E}from"./el-button-D5jk_owF.js";import{d as u,z as f,k as i,F as N,w as a,n as x,l as y,u as g,o as _,A as w,j as V}from"./vue.esm-bundler-CWJkwHz9.js";import"./index-jU8mFvCO.js";import"./index-cNfuRqjS.js";import"./index-CvGOsCqS.js";import"./index-DjWSGOMW.js";import"./index-DD34QqSk.js";import{W as b}from"./index-BNTUvNAl.js";import"./index-CiEKwO2o.js";import"./index-BXnpXdTJ.js";import"./index-CC1hLSnN.js";import"./get-BMJXpyNq.js";import"./_plugin-vue_export-helper-C6RzJgyC.js";import"./aria-BrQDUQ5m.js";import"./index-Bl31wyo9.js";import"./toNumber-DSBfpcGg.js";import"./index-CAWHOWdY.js";import"./curry-BXSChsWz.js";import"./cloneDeep-CCw91Nak.js";import"./_baseIsEqual-eNA4N57V.js";import"./_initCloneObject-8enN8I-i.js";import"./_arrayPush-lnK5TCUO.js";import"./index-opX51o-s.js";import"./pick-BkEcKBb1.js";import"./_basePickBy-Co_IC_Gu.js";import"./hasIn-Bi7gSSs4.js";import"./_overRest-DYeOVmH-.js";import"./event-BB_Ol6Sd.js";import"./el-tooltip-DjrQvLKJ.js";import"./el-popper-D1v00u9P.js";import"./isUndefined-DCTLXrZ8.js";import"./dropdown-hzEuDxer.js";import"./purify.es-DTUwIkWu.js";import"./mermaid.core-JEFoKH9L.js";import"./iframe-DBptVp5Y.js";import"./index-DrFu-skq.js";import"./index-DppTSAR2.js";import"./katex-Czt20RFs.js";const k={class:"Welcome-demo-box"},S=u({__name:"CustomSolt",props:{prefixCls:{},rootClassName:{},className:{},style:{},variant:{},classNames:{},styles:{},icon:{},title:{},description:{},extra:{},direction:{},showExtraSlot:{type:Boolean},showImageSlot:{type:Boolean}},setup(e){const t=e;return(v,o)=>{const C=E;return _(),f("div",k,[i(g(b),x(y(t)),N({_:2},[t.showExtraSlot?{name:"extra",fn:a(()=>[i(C,{link:"",type:"primary"},{default:a(()=>o[0]||(o[0]=[w(" 关于我 ")])),_:1,__:[0]})]),key:"0"}:void 0,t.showImageSlot?{name:"image",fn:a(()=>[o[1]||(o[1]=V("img",{src:"https://element-plus-x.com/logo.png",style:{width:"80px"}},null,-1))]),key:"1"}:void 0]),1040)])}}});S.__docgenInfo={exportName:"default",displayName:"CustomSolt",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/Welcome/CustomSolt.vue"]};const I={class:"Welcome-demo-box"},h=u({__name:"index",setup(e){return(t,v)=>(_(),f("div",I,[i(g(b),x(y(t.$attrs)),null,16)]))}});h.__docgenInfo={exportName:"default",displayName:"Welcome",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/Welcome/index.vue"]};const ft={title:"Example/Welcome 欢迎 🌹",component:h,argTypes:{variant:{control:{type:"radio"},defaultValue:"filled",options:["filled","borderless"],description:"组件样式变体（filled/borderless）"},direction:{control:{type:"radio"},defaultValue:"ltr",options:["ltr","rtl"],description:"组件语言方向（ltr/rtl）"},icon:{control:{type:"text"},defaultValue:"",description:"图标URL地址"},title:{control:{type:"text"},defaultValue:"标题",description:"标题"},extra:{control:{type:"text"},defaultValue:"额外信息",description:"额外信息"},description:{control:{type:"text"},defaultValue:"描述",description:"描述文本内容"},className:{control:{type:"text"},defaultValue:"",description:"容器外层自定义类名"},rootClassName:{control:{type:"text"},defaultValue:"",description:"根节点自定义类名"},classNames:{control:{type:"object"},defaultValue:{icon:"",title:"",extra:"",description:""},description:"各部分自定义类名({ icon, title, extra, description })"},style:{control:{type:"object"},description:"容器外层自定义样式"},styles:{control:{type:"object"},description:"各部分自定义样式({ icon, title, extra, description })"},prefixCls:{control:{type:"text"},default:"welcome",description:"组件类名前缀"}}},r={args:{title:"欢迎使用Element-Plus-X AI 助手",description:"一起玩耍吧",icon:"https://camo.githubusercontent.com/4ea7fdaabf101c16965c0bd3ead816c9d7726a59b06f0800eb7c9a30212d5a6a/68747470733a2f2f63646e2e656c656d656e742d706c75732d782e636f6d2f656c656d656e742d706c75732d782e706e67",direction:"ltr",variant:"filled"}},s={args:{title:"欢迎使用Element-Plus-X AI 助手",description:"一起玩耍吧",direction:"ltr",variant:"filled",showExtraSlot:!0,showImageSlot:!0},render:e=>({components:{CustomSolt:S},setup(){return{attrs:e}},template:'<CustomSolt v-bind="attrs" />'})};var n,l,c;r.parameters={...r.parameters,docs:{...(n=r.parameters)==null?void 0:n.docs,source:{originalSource:`{
  args: {
    title: '欢迎使用Element-Plus-X AI 助手',
    description: '一起玩耍吧',
    icon: 'https://camo.githubusercontent.com/4ea7fdaabf101c16965c0bd3ead816c9d7726a59b06f0800eb7c9a30212d5a6a/68747470733a2f2f63646e2e656c656d656e742d706c75732d782e636f6d2f656c656d656e742d706c75732d782e706e67',
    direction: 'ltr',
    variant: 'filled'
  }
}`,...(c=(l=r.parameters)==null?void 0:l.docs)==null?void 0:c.source}}};var p,m,d;s.parameters={...s.parameters,docs:{...(p=s.parameters)==null?void 0:p.docs,source:{originalSource:`{
  args: {
    title: '欢迎使用Element-Plus-X AI 助手',
    description: '一起玩耍吧',
    direction: 'ltr',
    variant: 'filled',
    showExtraSlot: true,
    showImageSlot: true
  } as any,
  render: (args: any) => ({
    components: {
      CustomSolt
    },
    setup() {
      return {
        attrs: args
      };
    },
    template: \`<CustomSolt v-bind="attrs" />\`
  })
}`,...(d=(m=s.parameters)==null?void 0:m.docs)==null?void 0:d.source}}};const xt=["WelcomeDemo","SlotDemo"];export{s as SlotDemo,r as WelcomeDemo,xt as __namedExportsOrder,ft as default};
