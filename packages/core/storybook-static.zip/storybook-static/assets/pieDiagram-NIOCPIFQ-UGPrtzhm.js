import{p as V}from"./chunk-353BL4L5-dVcxfBKA.js";import{S as y,W as z,aF as U,_ as p,g as j,s as q,a as Z,b as H,t as J,q as K,l as F,c as Q,E as X,I as Y,a5 as tt,e as et,z as rt,G as at}from"./mermaid.core-CUV9Ow59.js";import{p as nt}from"./treemap-75Q7IDZK-sEU3x7RB.js";import{d as O}from"./arc-B4s0L44H.js";import{o as it}from"./ordinal-Cboi1Yqb.js";import"./iframe-BtJ0FfGe.js";import"./_commonjsHelpers-DYJ6H3P4.js";import"./_plugin-vue_export-helper-UBQfR8ld.js";import"./mock-B9k1oZu6.js";import"./isArguments-DJsDwUOI.js";import"./constants-Cu4joN5-.js";import"./_overRest-4-f3tAV-.js";import"./index-DrFu-skq.js";import"./_baseClone-hrWwZHzz.js";import"./_arrayPush-lnK5TCUO.js";import"./get-DecQlHrd.js";import"./_baseUniq-C207O-I7.js";import"./_baseIsEqual-BHCuNw15.js";import"./hasIn-CdKFcgYV.js";import"./_basePickBy-B_60Sftk.js";import"./min-DMj9rk3U.js";import"./toNumber-C3ZKhb62.js";import"./_baseSlice-F8doVSIJ.js";import"./isUndefined-DCTLXrZ8.js";import"./clone-Df1_by9x.js";import"./last-DXTTfs9a.js";import"./init-Gi6I4Gst.js";function ot(t,r){return r<t?-1:r>t?1:r>=t?0:NaN}function st(t){return t}function lt(){var t=st,r=ot,f=null,s=y(0),u=y(z),x=y(0);function i(e){var a,l=(e=U(e)).length,g,A,h=0,c=new Array(l),n=new Array(l),v=+s.apply(this,arguments),w=Math.min(z,Math.max(-z,u.apply(this,arguments)-v)),m,T=Math.min(Math.abs(w)/l,x.apply(this,arguments)),$=T*(w<0?-1:1),d;for(a=0;a<l;++a)(d=n[c[a]=a]=+t(e[a],a,e))>0&&(h+=d);for(r!=null?c.sort(function(S,C){return r(n[S],n[C])}):f!=null&&c.sort(function(S,C){return f(e[S],e[C])}),a=0,A=h?(w-l*$)/h:0;a<l;++a,v=m)g=c[a],d=n[g],m=v+(d>0?d*A:0)+$,n[g]={data:e[g],index:a,value:d,startAngle:v,endAngle:m,padAngle:T};return n}return i.value=function(e){return arguments.length?(t=typeof e=="function"?e:y(+e),i):t},i.sortValues=function(e){return arguments.length?(r=e,f=null,i):r},i.sort=function(e){return arguments.length?(f=e,r=null,i):f},i.startAngle=function(e){return arguments.length?(s=typeof e=="function"?e:y(+e),i):s},i.endAngle=function(e){return arguments.length?(u=typeof e=="function"?e:y(+e),i):u},i.padAngle=function(e){return arguments.length?(x=typeof e=="function"?e:y(+e),i):x},i}var ct=at.pie,G={sections:new Map,showData:!1},b=G.sections,W=G.showData,pt=structuredClone(ct),ut=p(()=>structuredClone(pt),"getConfig"),gt=p(()=>{b=new Map,W=G.showData,rt()},"clear"),dt=p(({label:t,value:r})=>{b.has(t)||(b.set(t,r),F.debug(`added new section: ${t}, with value: ${r}`))},"addSection"),mt=p(()=>b,"getSections"),ft=p(t=>{W=t},"setShowData"),ht=p(()=>W,"getShowData"),P={getConfig:ut,clear:gt,setDiagramTitle:K,getDiagramTitle:J,setAccTitle:H,getAccTitle:Z,setAccDescription:q,getAccDescription:j,addSection:dt,getSections:mt,setShowData:ft,getShowData:ht},vt=p((t,r)=>{V(t,r),r.setShowData(t.showData),t.sections.map(r.addSection)},"populateDb"),St={parse:p(async t=>{const r=await nt("pie",t);F.debug(r),vt(r,P)},"parse")},yt=p(t=>`
  .pieCircle{
    stroke: ${t.pieStrokeColor};
    stroke-width : ${t.pieStrokeWidth};
    opacity : ${t.pieOpacity};
  }
  .pieOuterCircle{
    stroke: ${t.pieOuterStrokeColor};
    stroke-width: ${t.pieOuterStrokeWidth};
    fill: none;
  }
  .pieTitleText {
    text-anchor: middle;
    font-size: ${t.pieTitleTextSize};
    fill: ${t.pieTitleTextColor};
    font-family: ${t.fontFamily};
  }
  .slice {
    font-family: ${t.fontFamily};
    fill: ${t.pieSectionTextColor};
    font-size:${t.pieSectionTextSize};
    // fill: white;
  }
  .legend text {
    fill: ${t.pieLegendTextColor};
    font-family: ${t.fontFamily};
    font-size: ${t.pieLegendTextSize};
  }
`,"getStyles"),xt=yt,At=p(t=>{const r=[...t.entries()].map(s=>({label:s[0],value:s[1]})).sort((s,u)=>u.value-s.value);return lt().value(s=>s.value)(r)},"createPieArcs"),wt=p((t,r,f,s)=>{F.debug(`rendering pie chart
`+t);const u=s.db,x=Q(),i=X(u.getConfig(),x.pie),e=40,a=18,l=4,g=450,A=g,h=Y(r),c=h.append("g");c.attr("transform","translate("+A/2+","+g/2+")");const{themeVariables:n}=x;let[v]=tt(n.pieOuterStrokeWidth);v??(v=2);const w=i.textPosition,m=Math.min(A,g)/2-e,T=O().innerRadius(0).outerRadius(m),$=O().innerRadius(m*w).outerRadius(m*w);c.append("circle").attr("cx",0).attr("cy",0).attr("r",m+v/2).attr("class","pieOuterCircle");const d=u.getSections(),S=At(d),C=[n.pie1,n.pie2,n.pie3,n.pie4,n.pie5,n.pie6,n.pie7,n.pie8,n.pie9,n.pie10,n.pie11,n.pie12],D=it(C);c.selectAll("mySlices").data(S).enter().append("path").attr("d",T).attr("fill",o=>D(o.data.label)).attr("class","pieCircle");let I=0;d.forEach(o=>{I+=o}),c.selectAll("mySlices").data(S).enter().append("text").text(o=>(o.data.value/I*100).toFixed(0)+"%").attr("transform",o=>"translate("+$.centroid(o)+")").style("text-anchor","middle").attr("class","slice"),c.append("text").text(u.getDiagramTitle()).attr("x",0).attr("y",-400/2).attr("class","pieTitleText");const M=c.selectAll(".legend").data(D.domain()).enter().append("g").attr("class","legend").attr("transform",(o,E)=>{const k=a+l,L=k*D.domain().length/2,_=12*a,B=E*k-L;return"translate("+_+","+B+")"});M.append("rect").attr("width",a).attr("height",a).style("fill",D).style("stroke",D),M.data(S).append("text").attr("x",a+l).attr("y",a-l).text(o=>{const{label:E,value:k}=o.data;return u.getShowData()?`${E} [${k}]`:E});const R=Math.max(...M.selectAll("text").nodes().map(o=>(o==null?void 0:o.getBoundingClientRect().width)??0)),N=A+e+a+l+R;h.attr("viewBox",`0 0 ${N} ${g}`),et(h,g,N,i.useMaxWidth)},"draw"),Ct={draw:wt},Qt={parser:St,db:P,renderer:Ct,styles:xt};export{Qt as diagram};
