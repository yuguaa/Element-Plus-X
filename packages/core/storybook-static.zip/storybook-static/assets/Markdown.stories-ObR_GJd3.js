import{m as ae,h as pe,f as se,a as ge,g as fe}from"./mock-Bykb4b7U.js";import{_ as b,S as O,E as ke,s as P}from"./index-CC1hLSnN.js";import{E as g}from"./el-button-D5jk_owF.js";import{d as y,m as h,c as F,s as H,z as x,k as o,j as c,w as l,E as M,u as w,G as N,o as S,A as p,C as V,h as s,x as we}from"./vue.esm-bundler-CWJkwHz9.js";import{_ as I}from"./_plugin-vue_export-helper-C6RzJgyC.js";/* empty css                   */import{E as v}from"./el-popper-D1v00u9P.js";import{E as A}from"./index-DppTSAR2.js";import"./el-tooltip-DjrQvLKJ.js";import"./mermaid.core-JEFoKH9L.js";import"./iframe-DBptVp5Y.js";import"./purify.es-DTUwIkWu.js";import"./_initCloneObject-8enN8I-i.js";import"./_overRest-DYeOVmH-.js";import"./index-DrFu-skq.js";import"./aria-BrQDUQ5m.js";import"./index-opX51o-s.js";import"./pick-BkEcKBb1.js";import"./_basePickBy-Co_IC_Gu.js";import"./hasIn-Bi7gSSs4.js";import"./_arrayPush-lnK5TCUO.js";import"./get-BMJXpyNq.js";import"./event-BB_Ol6Sd.js";import"./index-Bl31wyo9.js";import"./curry-BXSChsWz.js";import"./katex-Czt20RFs.js";import"./isUndefined-DCTLXrZ8.js";const Ce={class:"component-container"},le=y({__name:"customAttrs",props:{markdown:{}},setup(f){const d=f,n=h(),t=h(0);function r(){n.value=setInterval(()=>{t.value+=5,t.value>d.markdown.length&&(clearInterval(n.value),t.value=d.markdown.length)},100)}function i(){n.value&&(clearInterval(n.value),n.value=null)}const m=F(()=>d.markdown.slice(0,t.value));function C(){t.value=0,n.value&&(clearInterval(n.value),n.value=null),r()}return H(()=>{r()}),(_,u)=>{const e=g;return S(),x(N,null,[o(e,{onClick:r},{default:l(()=>u[0]||(u[0]=[p(" 开始 ")])),_:1,__:[0]}),o(e,{onClick:i},{default:l(()=>u[1]||(u[1]=[p(" 暂停 ")])),_:1,__:[1]}),o(e,{onClick:C},{default:l(()=>u[2]||(u[2]=[p(" 重新开始 ")])),_:1,__:[2]}),c("div",Ce,[u[3]||(u[3]=c("h4",null,"自定义属性",-1)),o(b,M(_.$attrs,{markdown:w(m)}),null,16,["markdown"])])],64)}}}),ve=I(le,[["__scopeId","data-v-7fa97b70"]]);le.__docgenInfo={exportName:"default",displayName:"customAttrs",description:"",tags:{},props:[{name:"markdown",required:!0,type:{name:"string"}}],sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/XMarkdown/customAttrs.vue"]};const de=y({__name:"CodeHeader",props:{raw:{},renderLines:{},isDark:{},isExpand:{},nowViewBtnShow:{type:Boolean},toggleExpand:{type:Function},toggleTheme:{type:Function},copyCode:{type:Function},viewCode:{type:Function}},setup(f){const d=f;return(n,t)=>(S(),x("div",{onClick:t[0]||(t[0]=r=>d.toggleExpand(r))}," 组件插槽--"+V(d.isExpand.value),1))}});de.__docgenInfo={exportName:"default",displayName:"CodeHeader",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/XMarkdown/CodeHeader.vue"]};const be={class:"component-container"},ie=y({__name:"highlight-code",props:{markdown:{}},setup(f){const d=f,n=h(),t=h(0);function r(){n.value=setInterval(()=>{t.value+=50,t.value>d.markdown.length&&(clearInterval(n.value),t.value=d.markdown.length)},100)}function i(){n.value&&(clearInterval(n.value),n.value=null)}const m=F(()=>d.markdown.slice(0,t.value)),C={codeHeaderLanguage:e=>s("span",{onClick:a=>{e.toggleExpand(a)}},{default:()=>`点击切换折叠状态--${e.raw.language}-${e.isExpand.value}`}),codeHeaderControl:e=>s(ke,{class:"markdown-language-header-space",direction:"horizontal"},{default:()=>[e.nowViewBtnShow&&s(v,{content:"预览代码",placement:"top"},{default:()=>s(g,{class:"shiki-header-button",onClick:()=>{if(e.raw.language!=="html"){A.warning("当前语言不支持预览代码");return}e.viewCode(e.renderLines)}},{default:()=>"👀"})}),s(v,{content:"切换主题",placement:"top"},{default:()=>s(g,{class:"shiki-header-button",onClick:()=>{e.toggleTheme()}},{default:()=>e.isDark.value?"🍪":"🌙"})}),s(v,{content:"复制代码",placement:"top"},{default:()=>s(g,{class:"shiki-header-button",onClick:()=>{e.copyCode(e.renderLines)}},{default:()=>"🥢"})})]}),viewCodeHeader:e=>s("div",{onClick:()=>{e.value===O.VIEW?e.changeSelectValue(O.CODE):e.changeSelectValue(O.VIEW)}},{default:()=>`自定义切换 ${e.value}`}),viewCodeContent:e=>s("div",{},{default:()=>`自定义内容区域 渲染代码长度 ${e.content.length} 当前视图 ${e.value}`}),viewCodeCloseBtn:e=>s("span",{onClick:()=>e.close()},{default:()=>"❎"})},_={codeHeaderLanguage:de};function u(){t.value=0,n.value&&(clearInterval(n.value),n.value=null),r()}return H(()=>{r()}),(e,a)=>(S(),x(N,null,[o(w(g),{onClick:r},{default:l(()=>a[0]||(a[0]=[p(" 开始 ")])),_:1,__:[0]}),o(w(g),{onClick:i},{default:l(()=>a[1]||(a[1]=[p(" 暂停 ")])),_:1,__:[1]}),o(w(g),{onClick:u},{default:l(()=>a[2]||(a[2]=[p(" 重新开始 ")])),_:1,__:[2]}),c("div",be,[a[3]||(a[3]=c("h4",null,"默认插槽",-1)),o(b,M(e.$attrs,{markdown:w(m),"color-replacements":{"vitesse-light":{"#ab5959":"#ab5959","#1e754f":"#1e754f"},"vitesse-dark":{"#cb7676":"#cb7676","#4d9375":"#4d9375"}},"custom-attrs":{code:()=>({name:"code",class:"inline-code"}),a:k=>({target:"_blank",rel:"noopener noreferrer"})}}),null,16,["markdown"]),a[4]||(a[4]=c("h4",null,"函数插槽以及使用暴露出来的方法 和 自定义当前主题的颜色",-1)),o(b,M(e.$attrs,{markdown:w(m),"code-x-slot":C}),null,16,["markdown"]),a[5]||(a[5]=c("h4",null,"组件插槽",-1)),o(b,M(e.$attrs,{markdown:w(m),"code-x-slot":_}),null,16,["markdown"])])],64))}}),he=I(ie,[["__scopeId","data-v-a4c443cf"]]);ie.__docgenInfo={exportName:"default",displayName:"highlight-code",description:"",tags:{},props:[{name:"markdown",required:!0,type:{name:"string"}}],sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/XMarkdown/highlight-code.vue"]};const _e={class:"component-container"},ue=y({__name:"index",props:{markdown:{}},setup(f){const d=f,n=h(),t=h(0);function r(){n.value=setInterval(()=>{t.value+=5,t.value>d.markdown.length&&(clearInterval(n.value),t.value=d.markdown.length)},80)}function i(){n.value&&(clearInterval(n.value),n.value=null)}const m=F(()=>d.markdown.slice(0,t.value));function C(){t.value=0,n.value&&(clearInterval(n.value),n.value=null),r()}return H(()=>{r()}),(_,u)=>{const e=g;return S(),x(N,null,[o(e,{onClick:r},{default:l(()=>u[0]||(u[0]=[p(" 开始 ")])),_:1,__:[0]}),o(e,{onClick:i},{default:l(()=>u[1]||(u[1]=[p(" 暂停 ")])),_:1,__:[1]}),o(e,{onClick:C},{default:l(()=>u[2]||(u[2]=[p(" 重新开始 ")])),_:1,__:[2]}),c("div",_e,[o(b,M(_.$attrs,{markdown:w(m)}),null,16,["markdown"])])],64)}}}),ye=I(ue,[["__scopeId","data-v-d790aa6f"]]);ue.__docgenInfo={exportName:"default",displayName:"XMarkdown",description:"",tags:{},props:[{name:"markdown",required:!0,type:{name:"string"}}],sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/XMarkdown/index.vue"]};const xe={class:"mermaid-header"},Se={class:"header-left"},Me={class:"mode-badge"},Fe={class:"header-right"},me=y({__name:"MermaidHeader",setup(f){const d=we();async function n(){try{const t=`🧩 组件插槽自定义：

${d.rawContent}

✨ 使用 Element Plus X 组件`;await navigator.clipboard.writeText(t),A.success("🎉 组件插槽自定义复制成功！")}catch{}}return(t,r)=>{const i=g,m=v;return S(),x("div",xe,[c("div",Se,[r[0]||(r[0]=c("span",{class:"icon"},"🧩",-1)),r[1]||(r[1]=c("span",{class:"title"},"组件插槽",-1)),c("span",Me,V(t.$attrs.showSourceCode?"📝 源码":"📊 图表"),1)]),c("div",Fe,[o(m,{content:"放大图表",placement:"top"},{default:l(()=>[o(i,{class:"header-btn zoom-btn",size:"small",type:"primary",onClick:t.$attrs.zoomIn},{default:l(()=>r[2]||(r[2]=[p(" 🔍 ")])),_:1,__:[2]},8,["onClick"])]),_:1}),o(m,{content:"缩小图表",placement:"top"},{default:l(()=>[o(i,{class:"header-btn zoom-btn",size:"small",type:"primary",onClick:t.$attrs.zoomOut},{default:l(()=>r[3]||(r[3]=[p(" 🔍- ")])),_:1,__:[3]},8,["onClick"])]),_:1}),o(m,{content:"重置视图",placement:"top"},{default:l(()=>[o(i,{class:"header-btn reset-btn",size:"small",type:"warning",onClick:t.$attrs.reset},{default:l(()=>r[4]||(r[4]=[p(" 🔄 ")])),_:1,__:[4]},8,["onClick"])]),_:1}),o(m,{content:"切换视图",placement:"top"},{default:l(()=>[o(i,{class:"header-btn toggle-btn",size:"small",type:"info",onClick:t.$attrs.toggleCode},{default:l(()=>[p(V(t.$attrs.showSourceCode?"👁️":"📝"),1)]),_:1},8,["onClick"])]),_:1}),o(m,{content:"自定义复制逻辑",placement:"top"},{default:l(()=>[o(i,{class:"header-btn copy-btn",size:"small",type:"success",onClick:n},{default:l(()=>r[5]||(r[5]=[p(" 📋 ")])),_:1,__:[5]})]),_:1}),o(m,{content:"下载图片",placement:"top"},{default:l(()=>[o(i,{class:"header-btn download-btn",size:"small",type:"success",onClick:t.$attrs.download},{default:l(()=>r[6]||(r[6]=[p(" 💾 ")])),_:1,__:[6]},8,["onClick"])]),_:1})])])}}}),Ie=I(me,[["__scopeId","data-v-0c45001a"]]);me.__docgenInfo={exportName:"default",displayName:"MermaidHeader",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/XMarkdown/MermaidHeader.vue"]};const Ee={class:"component-container"},$e={class:"demo-section"},De={class:"demo-section"},ze={class:"demo-section"},ce=y({__name:"mermaid-slot",props:{markdown:{},mermaidConfig:{},themes:{}},setup(f){const d=f,n=F(()=>d.mermaidConfig),t={codeMermaidHeaderControl:a=>s("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"12px 16px",background:"linear-gradient(135deg, #667eea 0%, #764ba2 100%)",color:"white",borderRadius:"8px",boxShadow:"0 4px 12px rgba(102, 126, 234, 0.3)"}},[s("div",{style:{display:"flex",alignItems:"center",gap:"12px"}},[s("span",{style:{fontSize:"16px"}},"🎨"),s("span",{style:{fontWeight:"600"}},"Custom Mermaid"),s("span",{style:{fontSize:"12px",background:"rgba(255,255,255,0.25)",padding:"4px 8px",borderRadius:"12px"}},a.showSourceCode?"📝 源码":"📊 图表")]),s("div",{style:{display:"flex"}},[s(v,{content:"放大",placement:"top"},{default:()=>s(g,{size:"small",type:"primary",text:!0,bg:!0,style:{background:"rgba(255,255,255,0.2)",color:"white",border:"none"},onClick:a.zoomIn},()=>"🔍")}),s(v,{content:"重置缩放",placement:"top"},{default:()=>s(g,{size:"small",type:"primary",text:!0,bg:!0,style:{background:"rgba(255,255,255,0.2)",color:"white",border:"none"},onClick:a.reset},()=>"🔄")}),s(v,{content:a.showSourceCode?"查看图表":"查看源码",placement:"top"},{default:()=>s(g,{size:"small",type:"primary",text:!0,bg:!0,style:{background:"rgba(255,255,255,0.2)",color:"white",border:"none"},onClick:a.toggleCode},()=>a.showSourceCode?"👁️":"📝")}),s(v,{content:"自定义复制",placement:"top"},{default:()=>s(g,{size:"small",type:"primary",text:!0,bg:!0,style:{background:"rgba(255,255,255,0.2)",color:"white",border:"none"},onClick:async()=>{try{const k=`🎨 自定义前缀：

${a.rawContent}

📝 来自：Element-Plus-X`;await navigator.clipboard.writeText(k),A.success("🎉 组件插槽自定义复制成功！")}catch{}}},()=>"📋")}),s(v,{content:"下载图片",placement:"top"},{default:()=>s(g,{size:"small",type:"primary",text:!0,bg:!0,style:{background:"rgba(255,255,255,0.2)",color:"white",border:"none"},onClick:a.download},()=>"💾")})])])},r={codeMermaidHeaderControl:Ie},i=h(),m=h(0);function C(){i.value=setInterval(()=>{m.value+=5,m.value>d.markdown.length&&(clearInterval(i.value),m.value=d.markdown.length)},100)}function _(){i.value&&(clearInterval(i.value),i.value=null)}const u=F(()=>d.markdown.slice(0,m.value));function e(){m.value=0,i.value&&(clearInterval(i.value),i.value=null),C()}return H(()=>{C()}),(a,k)=>(S(),x(N,null,[o(w(g),{onClick:C},{default:l(()=>k[0]||(k[0]=[p(" 开始 ")])),_:1,__:[0]}),o(w(g),{onClick:_},{default:l(()=>k[1]||(k[1]=[p(" 暂停 ")])),_:1,__:[1]}),o(w(g),{onClick:e},{default:l(()=>k[2]||(k[2]=[p(" 重新开始 ")])),_:1,__:[2]}),c("div",Ee,[c("div",$e,[k[3]||(k[3]=c("h4",null,"1. 📋 通过mermaidConfig 配置",-1)),o(b,{markdown:u.value,"mermaid-config":n.value,themes:a.themes},null,8,["markdown","mermaid-config","themes"])]),c("div",De,[k[4]||(k[4]=c("h4",null,"2. 🔧 函数式插槽",-1)),o(b,{markdown:u.value,"code-x-slot":t,themes:a.themes},null,8,["markdown","themes"])]),c("div",ze,[k[5]||(k[5]=c("h4",null,"3. 🧩 组件插槽",-1)),o(b,{markdown:u.value,"code-x-slot":r,themes:a.themes},null,8,["markdown","themes"])])])],64))}}),Xe=I(ce,[["__scopeId","data-v-b6d47914"]]);ce.__docgenInfo={exportName:"default",displayName:"mermaid-slot",description:"",tags:{},props:[{name:"markdown",required:!0,type:{name:"string"}},{name:"mermaidConfig",required:!1,type:{name:"MermaidToolbarConfig"}},{name:"themes",required:!1,type:{name:`{\r
  light: string;\r
  dark: string;\r
}`}}],sourceFiles:["C:/Users/anbi/Desktop/tsStudy/Element-Plus-X/packages/core/src/stories/XMarkdown/mermaid-slot.vue"]};const lt={title:"Example/XMarkdown 渲染组件 📜",component:ye,tags:["autodocs"],argTypes:{markdown:{control:"text"},themes:{control:"object",defaultValue:{...P}},needViewCodeBtn:{control:"boolean",defaultValue:!0},secureViewCode:{control:"boolean",defaultValue:!1},defaultThemeMode:{control:"select",options:["light","dark"]},viewCodeModalOptions:{control:"object"},colorReplacements:{control:"object"},mermaidConfig:{control:"object"}},args:{markdown:ae,themes:{...P},needViewCodeBtn:!0,secureViewCode:!1,viewCodeModalOptions:{mode:"drawer",customClass:"",dialogOptions:{closeOnClickModal:!0,closeOnPressEscape:!0},drawerOptions:{closeOnClickModal:!0,closeOnPressEscape:!0}},defaultThemeMode:"light",colorReplacements:{"vitesse-light":{"#ab5959":"#ff66ff","#1e754f":"#029c99"},"vitesse-dark":{"#cb7676":"#ff0066","#4d9375":"#952189"}},mermaidConfig:{showToolbar:!0,showFullscreen:!0,showZoomIn:!0,showZoomOut:!0,showReset:!0,showDownload:!0,toolbarStyle:{},toolbarClass:"mermaid-config-toolbar"}}},E={args:{markdown:ae}},$={args:{markdown:pe},render:f=>({components:{HighlightCodeDemo:he},setup(){return{attrs:f}},template:'<HighlightCodeDemo v-bind="attrs"  />'})},D={args:{markdown:se}},z={args:{markdown:ge}},X={args:{markdown:se,mermaidConfig:{showToolbar:!0,showFullscreen:!0,showZoomIn:!0,showZoomOut:!0,showReset:!0,showDownload:!0,toolbarStyle:{background:"linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%)",boxShadow:"0 4px 16px rgba(139, 92, 246, 0.3)",borderRadius:"8px"},iconColor:"#FFFFFF",tabTextColor:"#FFFFFF"}},render:f=>({components:{MermaidSlot:Xe},setup(){return{attrs:f}},template:'<MermaidSlot v-bind="attrs"  />'})},T={args:{markdown:fe,customAttrs:{a:()=>({target:"_blank",rel:"noopener noreferrer"}),h1:{style:{color:"red",fontSize:"24px"}},h2:{style:{color:"blue",fontSize:"20px"}}}},render:f=>({components:{CustomAttrs:ve},setup(){return{attrs:f}},template:'<CustomAttrs v-bind="attrs" />'})};var R,B,U;E.parameters={...E.parameters,docs:{...(R=E.parameters)==null?void 0:R.docs,source:{originalSource:`{
  args: {
    markdown: mdContent
  } as Story['args']
}`,...(U=(B=E.parameters)==null?void 0:B.docs)==null?void 0:U.source}}};var j,q,L;$.parameters={...$.parameters,docs:{...(j=$.parameters)==null?void 0:j.docs,source:{originalSource:`{
  args: {
    markdown: highlightMdContent
  },
  render: args => ({
    components: {
      HighlightCodeDemo
    },
    setup() {
      return {
        attrs: args
      };
    },
    template: \`<HighlightCodeDemo v-bind="attrs"  />\`
  })
}`,...(L=(q=$.parameters)==null?void 0:q.docs)==null?void 0:L.source}}};var Z,W,G;D.parameters={...D.parameters,docs:{...(Z=D.parameters)==null?void 0:Z.docs,source:{originalSource:`{
  args: {
    markdown: mermaidMdContent
  } as Story['args']
}`,...(G=(W=D.parameters)==null?void 0:W.docs)==null?void 0:G.source}}};var J,K,Q;z.parameters={...z.parameters,docs:{...(J=z.parameters)==null?void 0:J.docs,source:{originalSource:`{
  args: {
    markdown: mathMdContent
  } as Story['args']
}`,...(Q=(K=z.parameters)==null?void 0:K.docs)==null?void 0:Q.source}}};var Y,ee,te;X.parameters={...X.parameters,docs:{...(Y=X.parameters)==null?void 0:Y.docs,source:{originalSource:`{
  args: {
    markdown: mermaidMdContent,
    mermaidConfig: {
      showToolbar: true,
      showFullscreen: true,
      showZoomIn: true,
      showZoomOut: true,
      showReset: true,
      showDownload: true,
      toolbarStyle: {
        background: 'linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%)',
        boxShadow: '0 4px 16px rgba(139, 92, 246, 0.3)',
        borderRadius: '8px'
      },
      iconColor: '#FFFFFF',
      tabTextColor: '#FFFFFF'
    }
  } as Story['args'],
  render: args => ({
    components: {
      MermaidSlot
    },
    setup() {
      return {
        attrs: args
      };
    },
    template: \`<MermaidSlot v-bind="attrs"  />\`
  })
  // render: () => MermaidSlot
}`,...(te=(ee=X.parameters)==null?void 0:ee.docs)==null?void 0:te.source}}};var oe,ne,re;T.parameters={...T.parameters,docs:{...(oe=T.parameters)==null?void 0:oe.docs,source:{originalSource:`{
  args: {
    markdown: customAttrContent,
    customAttrs: {
      a: () => ({
        target: '_blank',
        rel: 'noopener noreferrer'
      }),
      h1: {
        style: {
          color: 'red',
          fontSize: '24px'
        }
      },
      h2: {
        style: {
          color: 'blue',
          fontSize: '20px'
        }
      }
    }
  } as Story['args'],
  render: args => ({
    components: {
      CustomAttrs
    },
    setup() {
      return {
        attrs: args
      };
    },
    template: \`<CustomAttrs v-bind="attrs" />\`
  })
}`,...(re=(ne=T.parameters)==null?void 0:ne.docs)==null?void 0:re.source}}};const dt=["MarkdownDemo","highlightMdContentDemo","PieRenderDemo","MathRenderDemo","MermaidSlotDemo","CustomAttrsDemo"];export{T as CustomAttrsDemo,E as MarkdownDemo,z as MathRenderDemo,X as MermaidSlotDemo,D as PieRenderDemo,dt as __namedExportsOrder,lt as default,$ as highlightMdContentDemo};
