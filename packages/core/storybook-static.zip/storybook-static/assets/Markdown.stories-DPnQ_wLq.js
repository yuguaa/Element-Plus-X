import{m as ae,j as pe,l as se,a as ge,n as fe}from"./mock-B9k1oZu6.js";import{_ as b,S as O,E as we,s as R}from"./index-0anCHD10.js";import"./base-D7tCU8sP.js";import{E as f}from"./el-button-C-YQqSO2.js";import{k as y,j as _,b as F,n as H,c as x,x as t,v as c,t as d,K as S,u as k,F as N,o as M,L as p,J as V,h as s}from"./vue.esm-bundler-DTnAEySg.js";import{_ as I}from"./_plugin-vue_export-helper-UBQfR8ld.js";import{E as v}from"./el-popper-Don6kwc5.js";import{E as P}from"./index-B1aegxae.js";import{C as ke}from"./index-B7Ywq2Kg.js";import"./el-tooltip-l0sNRNKZ.js";import"./isArguments-DJsDwUOI.js";import"./iframe-BtJ0FfGe.js";import"./_commonjsHelpers-DYJ6H3P4.js";import"./el-dialog-Bu0WQrtm.js";import"./index-D_jmEDI_.js";import"./aria-BUADUvnR.js";import"./refs-KaSJ3aZ6.js";import"./event-BB_Ol6Sd.js";import"./error-Cq9Fpw4b.js";import"./scroll-6RUcSnBG.js";import"./katex-Czt20RFs.js";import"./el-scrollbar-BCMwOZlL.js";import"./typescript-F_jgqlnI.js";import"./index-Dd4Za6Df.js";import"./pick-DvrFlX69.js";import"./_basePickBy-B_60Sftk.js";import"./hasIn-CdKFcgYV.js";import"./_arrayPush-lnK5TCUO.js";import"./get-DecQlHrd.js";import"./_overRest-4-f3tAV-.js";import"./constants-Cu4joN5-.js";import"./_baseClone-hrWwZHzz.js";import"./last-DXTTfs9a.js";import"./_baseSlice-F8doVSIJ.js";import"./curry-DW-wVgF4.js";import"./isUndefined-DCTLXrZ8.js";const Ce={class:"component-container"},le=y({__name:"customAttrs",props:{markdown:{}},setup(g){const a=g,o=_(),l=_(0);function n(){o.value=setInterval(()=>{l.value+=5,l.value>a.markdown.length&&(clearInterval(o.value),l.value=a.markdown.length)},100)}function i(){o.value&&(clearInterval(o.value),o.value=null)}const m=F(()=>a.markdown.slice(0,l.value));function C(){l.value=0,o.value&&(clearInterval(o.value),o.value=null),n()}return H(()=>{n()}),(h,u)=>{const e=f;return M(),x(N,null,[t(e,{onClick:n},{default:d(()=>u[0]||(u[0]=[p(" 开始 ",-1)])),_:1,__:[0]}),t(e,{onClick:i},{default:d(()=>u[1]||(u[1]=[p(" 暂停 ",-1)])),_:1,__:[1]}),t(e,{onClick:C},{default:d(()=>u[2]||(u[2]=[p(" 重新开始 ",-1)])),_:1,__:[2]}),c("div",Ce,[u[3]||(u[3]=c("h4",null,"自定义属性",-1)),t(b,S(h.$attrs,{markdown:k(m),"allow-html":!0}),null,16,["markdown"])])],64)}}}),ve=I(le,[["__scopeId","data-v-a32fa7f7"]]);le.__docgenInfo={exportName:"default",displayName:"customAttrs",description:"",tags:{},props:[{name:"markdown",required:!0,type:{name:"string"}}],sourceFiles:["C:/Users/anbi/Desktop/合并代码/Element-Plus-X/packages/core/src/stories/XMarkdown/customAttrs.vue"]};const de=y({__name:"CodeHeader",props:{raw:{},renderLines:{},isDark:{},isExpand:{},nowViewBtnShow:{type:Boolean},toggleExpand:{type:Function},toggleTheme:{type:Function},copyCode:{type:Function},viewCode:{type:Function}},setup(g){const a=g;return(o,l)=>(M(),x("div",{onClick:l[0]||(l[0]=n=>a.toggleExpand(n))}," 组件插槽--"+V(a.isExpand.value),1))}});de.__docgenInfo={exportName:"default",displayName:"CodeHeader",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/合并代码/Element-Plus-X/packages/core/src/stories/XMarkdown/CodeHeader.vue"]};const be={class:"component-container"},ie=y({__name:"highlight-code-demo",props:{markdown:{}},setup(g){const a=g,o=_(),l=_(0);function n(){o.value=setInterval(()=>{l.value+=25,l.value>a.markdown.length&&(clearInterval(o.value),l.value=a.markdown.length)},100)}function i(){o.value&&(clearInterval(o.value),o.value=null)}const m=F(()=>a.markdown.slice(0,l.value)),C={codeHeaderLanguage:e=>s("span",{onClick:r=>{e.toggleExpand(r)}},{default:()=>`点击切换折叠状态--${e.raw.language}-${e.isExpand.value}`}),codeHeaderControl:e=>s(we,{class:"markdown-elxLanguage-header-space",direction:"horizontal"},{default:()=>[e.nowViewBtnShow&&s(v,{content:"预览代码",placement:"top"},{default:()=>s(f,{class:"shiki-header-button",onClick:()=>{if(e.raw.language!=="html"){P.warning("当前语言不支持预览代码");return}e.viewCode(e.renderLines)}},{default:()=>"👀"})}),s(v,{content:"切换主题",placement:"top"},{default:()=>s(f,{class:"shiki-header-button",onClick:()=>{e.toggleTheme()}},{default:()=>e.isDark.value?"🍪":"🌙"})}),s(v,{content:"复制代码",placement:"top"},{default:()=>s(f,{class:"shiki-header-button",onClick:()=>{e.copyCode(e.renderLines)}},{default:()=>"🥢"})})]}),viewCodeHeader:e=>s("div",{onClick:()=>{e.value===O.VIEW?e.changeSelectValue(O.CODE):e.changeSelectValue(O.VIEW)}},{default:()=>`自定义切换 ${e.value}`}),viewCodeContent:e=>s("div",{},{default:()=>`自定义内容区域 渲染代码长度 ${e.content.length} 当前视图 ${e.value}`}),viewCodeCloseBtn:e=>s("span",{onClick:()=>e.close()},{default:()=>"❎"})},h={codeHeaderLanguage:de};function u(){l.value=0,o.value&&(clearInterval(o.value),o.value=null),n()}return H(()=>{n()}),(e,r)=>(M(),x(N,null,[t(k(f),{onClick:n},{default:d(()=>r[0]||(r[0]=[p(" 开始 ",-1)])),_:1,__:[0]}),t(k(f),{onClick:i},{default:d(()=>r[1]||(r[1]=[p(" 暂停 ",-1)])),_:1,__:[1]}),t(k(f),{onClick:u},{default:d(()=>r[2]||(r[2]=[p(" 重新开始 ",-1)])),_:1,__:[2]}),c("div",be,[r[3]||(r[3]=c("h4",null,"默认插槽",-1)),t(b,S(e.$attrs,{"enable-code-line-number":!0,markdown:k(m),"color-replacements":{"vitesse-light":{"#ab5959":"#ab5959","#1e754f":"#1e754f"},"vitesse-dark":{"#cb7676":"#cb7676","#4d9375":"#4d9375"}},"custom-attrs":{code:()=>({name:"code",class:"inline-code"}),a:w=>({target:"_blank",rel:"noopener noreferrer"})}}),null,16,["markdown"]),r[4]||(r[4]=c("h4",null,"函数插槽以及使用暴露出来的方法 和 自定义当前主题的颜色",-1)),t(b,S(e.$attrs,{markdown:k(m),"code-x-slot":C}),null,16,["markdown"]),r[5]||(r[5]=c("h4",null,"组件插槽",-1)),t(b,S(e.$attrs,{markdown:k(m),"code-x-slot":h}),null,16,["markdown"])])],64))}}),_e=I(ie,[["__scopeId","data-v-8f36b775"]]);ie.__docgenInfo={exportName:"default",displayName:"highlight-code-demo",description:"",tags:{},props:[{name:"markdown",required:!0,type:{name:"string"}}],sourceFiles:["C:/Users/anbi/Desktop/合并代码/Element-Plus-X/packages/core/src/stories/XMarkdown/highlight-code-demo.vue"]};const he={class:"component-container"},ue=y({__name:"index",props:{markdown:{}},setup(g){const a=g,o=_(),l=_(0);function n(){o.value=setInterval(()=>{l.value+=5,l.value>a.markdown.length&&(clearInterval(o.value),l.value=a.markdown.length)},80)}function i(){o.value&&(clearInterval(o.value),o.value=null)}const m=F(()=>a.markdown.slice(0,l.value));function C(){l.value=0,o.value&&(clearInterval(o.value),o.value=null),n()}return H(()=>{n()}),(h,u)=>{const e=f,r=b;return M(),x(N,null,[t(e,{onClick:n},{default:d(()=>u[0]||(u[0]=[p(" 开始 ",-1)])),_:1,__:[0]}),t(e,{onClick:i},{default:d(()=>u[1]||(u[1]=[p(" 暂停 ",-1)])),_:1,__:[1]}),t(e,{onClick:C},{default:d(()=>u[2]||(u[2]=[p(" 重新开始 ",-1)])),_:1,__:[2]}),c("div",he,[t(k(ke),null,{default:d(()=>[t(r,S(h.$attrs,{markdown:k(m)}),null,16,["markdown"])]),_:1})])],64)}}}),ye=I(ue,[["__scopeId","data-v-631adc9c"]]);ue.__docgenInfo={exportName:"default",displayName:"XMarkdown",description:"",tags:{},props:[{name:"markdown",required:!0,type:{name:"string"}}],sourceFiles:["C:/Users/anbi/Desktop/合并代码/Element-Plus-X/packages/core/src/stories/XMarkdown/index.vue"]};const xe={class:"mermaid-header"},Me={class:"header-left"},Se={class:"mode-badge"},Fe={class:"header-right"},me=y({__name:"MermaidHeader",props:{showSourceCode:{type:Boolean},svg:{},rawContent:{},toolbarConfig:{},isLoading:{type:Boolean},zoomIn:{type:Function},zoomOut:{type:Function},reset:{type:Function},fullscreen:{type:Function},toggleCode:{type:Function},copyCode:{type:Function},download:{type:Function},raw:{}},setup(g){const a=g;async function o(){try{const l=`🧩 组件插槽自定义：

${a.rawContent}

✨ 使用 Element Plus X 组件`;await navigator.clipboard.writeText(l),P.success("🎉 组件插槽自定义复制成功！")}catch{}}return(l,n)=>{const i=f,m=v;return M(),x("div",xe,[c("div",Me,[n[0]||(n[0]=c("span",{class:"icon"},"🧩",-1)),n[1]||(n[1]=c("span",{class:"title"},"组件插槽",-1)),c("span",Se,V(a.showSourceCode?"📝 源码":"📊 图表"),1)]),c("div",Fe,[t(m,{content:"放大图表",placement:"top"},{default:d(()=>[t(i,{class:"header-btn zoom-btn",size:"small",type:"primary",onClick:a.zoomIn},{default:d(()=>n[2]||(n[2]=[p(" 🔍 ",-1)])),_:1,__:[2]},8,["onClick"])]),_:1}),t(m,{content:"缩小图表",placement:"top"},{default:d(()=>[t(i,{class:"header-btn zoom-btn",size:"small",type:"primary",onClick:a.zoomOut},{default:d(()=>n[3]||(n[3]=[p(" 🔍- ",-1)])),_:1,__:[3]},8,["onClick"])]),_:1}),t(m,{content:"重置视图",placement:"top"},{default:d(()=>[t(i,{class:"header-btn reset-btn",size:"small",type:"warning",onClick:a.reset},{default:d(()=>n[4]||(n[4]=[p(" 🔄 ",-1)])),_:1,__:[4]},8,["onClick"])]),_:1}),t(m,{content:"切换视图",placement:"top"},{default:d(()=>[t(i,{class:"header-btn toggle-btn",size:"small",type:"info",onClick:a.toggleCode},{default:d(()=>[p(V(a.showSourceCode?"👁️":"📝"),1)]),_:1},8,["onClick"])]),_:1}),t(m,{content:"自定义复制逻辑",placement:"top"},{default:d(()=>[t(i,{class:"header-btn copy-btn",size:"small",type:"success",onClick:o},{default:d(()=>n[5]||(n[5]=[p(" 📋 ",-1)])),_:1,__:[5]})]),_:1}),t(m,{content:"下载图片",placement:"top"},{default:d(()=>[t(i,{class:"header-btn download-btn",size:"small",type:"success",onClick:a.download},{default:d(()=>n[6]||(n[6]=[p(" 💾 ",-1)])),_:1,__:[6]},8,["onClick"])]),_:1})])])}}}),Ie=I(me,[["__scopeId","data-v-eeaa7da8"]]);me.__docgenInfo={exportName:"default",displayName:"MermaidHeader",description:"",tags:{},sourceFiles:["C:/Users/anbi/Desktop/合并代码/Element-Plus-X/packages/core/src/stories/XMarkdown/MermaidHeader.vue"]};const Ee={class:"component-container"},De={class:"demo-section"},ze={class:"demo-section"},$e={class:"demo-section"},ce=y({__name:"mermaid-slot",props:{markdown:{},mermaidConfig:{},themes:{}},setup(g){const a=g,o=F(()=>a.mermaidConfig),l={codeMermaidHeaderControl:r=>s("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"12px 16px",background:"linear-gradient(135deg, #667eea 0%, #764ba2 100%)",color:"white",borderRadius:"8px",boxShadow:"0 4px 12px rgba(102, 126, 234, 0.3)"}},[s("div",{style:{display:"flex",alignItems:"center",gap:"12px"}},[s("span",{style:{fontSize:"16px"}},"🎨"),s("span",{style:{fontWeight:"600"}},"Custom Mermaid"),s("span",{style:{fontSize:"12px",background:"rgba(255,255,255,0.25)",padding:"4px 8px",borderRadius:"12px"}},r.showSourceCode?"📝 源码":"📊 图表")]),s("div",{style:{display:"flex"}},[s(v,{content:"放大",placement:"top"},{default:()=>s(f,{size:"small",type:"primary",text:!0,bg:!0,style:{background:"rgba(255,255,255,0.2)",color:"white",border:"none"},onClick:r.zoomIn},()=>"🔍")}),s(v,{content:"重置缩放",placement:"top"},{default:()=>s(f,{size:"small",type:"primary",text:!0,bg:!0,style:{background:"rgba(255,255,255,0.2)",color:"white",border:"none"},onClick:r.reset},()=>"🔄")}),s(v,{content:r.showSourceCode?"查看图表":"查看源码",placement:"top"},{default:()=>s(f,{size:"small",type:"primary",text:!0,bg:!0,style:{background:"rgba(255,255,255,0.2)",color:"white",border:"none"},onClick:r.toggleCode},()=>r.showSourceCode?"👁️":"📝")}),s(v,{content:"自定义复制",placement:"top"},{default:()=>s(f,{size:"small",type:"primary",text:!0,bg:!0,style:{background:"rgba(255,255,255,0.2)",color:"white",border:"none"},onClick:async()=>{try{const w=`🎨 自定义前缀：

${r.rawContent}

📝 来自：Element-Plus-X`;await navigator.clipboard.writeText(w),P.success("🎉 组件插槽自定义复制成功！")}catch{}}},()=>"📋")}),s(v,{content:"下载图片",placement:"top"},{default:()=>s(f,{size:"small",type:"primary",text:!0,bg:!0,style:{background:"rgba(255,255,255,0.2)",color:"white",border:"none"},onClick:r.download},()=>"💾")})])])},n={codeMermaidHeaderControl:Ie},i=_(),m=_(0);function C(){i.value=setInterval(()=>{m.value+=5,m.value>a.markdown.length&&(clearInterval(i.value),m.value=a.markdown.length)},100)}function h(){i.value&&(clearInterval(i.value),i.value=null)}const u=F(()=>a.markdown.slice(0,m.value));function e(){m.value=0,i.value&&(clearInterval(i.value),i.value=null),C()}return H(()=>{C()}),(r,w)=>(M(),x(N,null,[t(k(f),{onClick:C},{default:d(()=>w[0]||(w[0]=[p(" 开始 ",-1)])),_:1,__:[0]}),t(k(f),{onClick:h},{default:d(()=>w[1]||(w[1]=[p(" 暂停 ",-1)])),_:1,__:[1]}),t(k(f),{onClick:e},{default:d(()=>w[2]||(w[2]=[p(" 重新开始 ",-1)])),_:1,__:[2]}),c("div",Ee,[c("div",De,[w[3]||(w[3]=c("h4",null,"1. 📋 通过mermaidConfig 配置",-1)),t(b,{markdown:u.value,"mermaid-config":o.value,themes:r.themes},null,8,["markdown","mermaid-config","themes"])]),c("div",ze,[w[4]||(w[4]=c("h4",null,"2. 🔧 函数式插槽",-1)),t(b,{markdown:u.value,"code-x-slot":l,themes:r.themes},null,8,["markdown","themes"])]),c("div",$e,[w[5]||(w[5]=c("h4",null,"3. 🧩 组件插槽",-1)),t(b,{markdown:u.value,"code-x-slot":n,themes:r.themes},null,8,["markdown","themes"])])])],64))}}),Xe=I(ce,[["__scopeId","data-v-2052bd30"]]);ce.__docgenInfo={exportName:"default",displayName:"mermaid-slot",description:"",tags:{},props:[{name:"markdown",required:!0,type:{name:"string"}},{name:"mermaidConfig",required:!1,type:{name:"MermaidToolbarConfig"}},{name:"themes",required:!1,type:{name:`{\r
  light: string;\r
  dark: string;\r
}`}}],sourceFiles:["C:/Users/anbi/Desktop/合并代码/Element-Plus-X/packages/core/src/stories/XMarkdown/mermaid-slot.vue"]};const wt={title:"Example/XMarkdown 渲染组件 📜",component:ye,tags:["autodocs"],argTypes:{markdown:{control:"text"},themes:{control:"object",defaultValue:{...R}},needViewCodeBtn:{control:"boolean",defaultValue:!0},secureViewCode:{control:"boolean",defaultValue:!1},defaultThemeMode:{control:"select",options:["light","dark"]},viewCodeModalOptions:{control:"object"},colorReplacements:{control:"object"},mermaidConfig:{control:"object"}},args:{markdown:ae,themes:{...R},needViewCodeBtn:!0,secureViewCode:!1,viewCodeModalOptions:{mode:"drawer",customClass:"",dialogOptions:{closeOnClickModal:!0,closeOnPressEscape:!0},drawerOptions:{closeOnClickModal:!0,closeOnPressEscape:!0}},defaultThemeMode:"light",colorReplacements:{"vitesse-light":{"#ab5959":"#ff66ff","#1e754f":"#029c99"},"vitesse-dark":{"#cb7676":"#ff0066","#4d9375":"#952189"}},mermaidConfig:{showToolbar:!0,showFullscreen:!0,showZoomIn:!0,showZoomOut:!0,showReset:!0,showDownload:!0,toolbarStyle:{},toolbarClass:"mermaid-config-toolbar"}}},E={args:{markdown:ae}},D={args:{markdown:pe},render:g=>({components:{HighlightCodeDemo:_e},setup(){return{attrs:g}},template:'<HighlightCodeDemo v-bind="attrs"  />'})},z={args:{markdown:se}},$={args:{markdown:ge}},X={args:{markdown:se,mermaidConfig:{showToolbar:!0,showFullscreen:!0,showZoomIn:!0,showZoomOut:!0,showReset:!0,showDownload:!0,toolbarStyle:{background:"linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%)",boxShadow:"0 4px 16px rgba(139, 92, 246, 0.3)",borderRadius:"8px"},iconColor:"#FFFFFF",tabTextColor:"#FFFFFF"}},render:g=>({components:{MermaidSlot:Xe},setup(){return{attrs:g}},template:'<MermaidSlot v-bind="attrs"  />'})},T={args:{markdown:fe,customAttrs:{a:()=>({target:"_blank",rel:"noopener noreferrer"}),h1:{style:{color:"red",fontSize:"24px"}},h2:{style:{color:"blue",fontSize:"20px"}}}},render:g=>({components:{CustomAttrs:ve},setup(){return{attrs:g}},template:'<CustomAttrs v-bind="attrs" />'})};var A,B,L;E.parameters={...E.parameters,docs:{...(A=E.parameters)==null?void 0:A.docs,source:{originalSource:`{
  args: {
    markdown: mdContent
  } as Story['args']
}`,...(L=(B=E.parameters)==null?void 0:B.docs)==null?void 0:L.source}}};var j,U,q;D.parameters={...D.parameters,docs:{...(j=D.parameters)==null?void 0:j.docs,source:{originalSource:`{
  args: {
    markdown: highlightMdContent
  },
  render: args => ({
    components: {
      HighlightCodeDemo
    },
    setup() {
      return {
        attrs: args
      };
    },
    template: \`<HighlightCodeDemo v-bind="attrs"  />\`
  })
}`,...(q=(U=D.parameters)==null?void 0:U.docs)==null?void 0:q.source}}};var Z,W,J;z.parameters={...z.parameters,docs:{...(Z=z.parameters)==null?void 0:Z.docs,source:{originalSource:`{
  args: {
    markdown: mermaidMdContent
  } as Story['args']
}`,...(J=(W=z.parameters)==null?void 0:W.docs)==null?void 0:J.source}}};var K,G,Q;$.parameters={...$.parameters,docs:{...(K=$.parameters)==null?void 0:K.docs,source:{originalSource:`{
  args: {
    markdown: mathMdContent
  } as Story['args']
}`,...(Q=(G=$.parameters)==null?void 0:G.docs)==null?void 0:Q.source}}};var Y,ee,te;X.parameters={...X.parameters,docs:{...(Y=X.parameters)==null?void 0:Y.docs,source:{originalSource:`{
  args: {
    markdown: mermaidMdContent,
    mermaidConfig: {
      showToolbar: true,
      showFullscreen: true,
      showZoomIn: true,
      showZoomOut: true,
      showReset: true,
      showDownload: true,
      toolbarStyle: {
        background: 'linear-gradient(135deg, #8b5cf6 0%, #a855f7 100%)',
        boxShadow: '0 4px 16px rgba(139, 92, 246, 0.3)',
        borderRadius: '8px'
      },
      iconColor: '#FFFFFF',
      tabTextColor: '#FFFFFF'
    }
  } as Story['args'],
  render: args => ({
    components: {
      MermaidSlot
    },
    setup() {
      return {
        attrs: args
      };
    },
    template: \`<MermaidSlot v-bind="attrs"  />\`
  })
  // render: () => MermaidSlot
}`,...(te=(ee=X.parameters)==null?void 0:ee.docs)==null?void 0:te.source}}};var oe,ne,re;T.parameters={...T.parameters,docs:{...(oe=T.parameters)==null?void 0:oe.docs,source:{originalSource:`{
  args: {
    markdown: customAttrContent,
    customAttrs: {
      a: () => ({
        target: '_blank',
        rel: 'noopener noreferrer'
      }),
      h1: {
        style: {
          color: 'red',
          fontSize: '24px'
        }
      },
      h2: {
        style: {
          color: 'blue',
          fontSize: '20px'
        }
      }
    }
  } as Story['args'],
  render: args => ({
    components: {
      CustomAttrs
    },
    setup() {
      return {
        attrs: args
      };
    },
    template: \`<CustomAttrs v-bind="attrs" />\`
  })
}`,...(re=(ne=T.parameters)==null?void 0:ne.docs)==null?void 0:re.source}}};const kt=["MarkdownDemo","highlightMdContentDemo","PieRenderDemo","MathRenderDemo","MermaidSlotDemo","CustomAttrsDemo"];export{T as CustomAttrsDemo,E as MarkdownDemo,$ as MathRenderDemo,X as MermaidSlotDemo,z as PieRenderDemo,kt as __namedExportsOrder,wt as default,D as highlightMdContentDemo};
